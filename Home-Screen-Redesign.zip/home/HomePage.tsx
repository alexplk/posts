import styles from './HomePage.module.css';
import { TryAction } from './components';
import defaultHeroImage from './assets/hero-band.webp';
import defaultNavigatorImage from './assets/navigator-tile.webp';
import {
  ActionButton,
  ClosingStrip,
  ExternalLink,
  FeatureCard,
  FeatureCardFooter,
  FeatureCardMeta,
  FeatureCardTags,
  HeroBanner,
  HeroEmphasis,
  PromoLinkTile,
  PromoTileFooter,
  PromoTileHeader,
  SearchPanel,
  SectionHeader,
  Stat,
  StatRow,
  SuggestionChip,
  Tag,
} from './components';

export interface HomePageProps {
  /** Wide landscape or architecture shot behind the masthead band. */
  heroImageSrc?: string;
  /** Narrow strip image on the Navigator tile. */
  navigatorImageSrc?: string;
  onSearch?: (query: string) => void;
  /** Hands a prompt to the assistant and opens it. */
  onAskNavigator?: (prompt: string) => void;
}

const SUGGESTIONS = [
  'What is Claves and what can I do with it?',
  'Which model is cheapest for summarising?',
  'Extract tables from this PDF',
  'Token cost for my org this month',
];

export function HomePage({
  heroImageSrc = defaultHeroImage,
  navigatorImageSrc = defaultNavigatorImage,
  onSearch,
  onAskNavigator,
}: HomePageProps) {
  const ask = (prompt: string) => (onAskNavigator ?? onSearch)?.(prompt);

  return (
    <div className={styles.page}>
      <HeroBanner
        eyebrow="Claves · AI & Data Portal"
        title={<>The <HeroEmphasis>keys</HeroEmphasis> to unlock AI &amp; Data at UBS</>}
        subtitle="Every agent, tool and dataset in one governed place, compliant by design."
        imageSrc={heroImageSrc}
        imageAlt=""
        focal="right"
      />

      <div className={styles.rail}>
        <div className={styles.panelLift}>
          <SearchPanel
            placeholder="Ask anything, or describe what you need to do…"
            submitLabel="Ask Navigator"
            onSubmit={(query) => onSearch?.(query)}
          >
            {SUGGESTIONS.map((suggestion) => (
              <SuggestionChip key={suggestion} onClick={() => ask(suggestion)}>
                {suggestion}
              </SuggestionChip>
            ))}
          </SearchPanel>
        </div>

        <section className={styles.section}>
          <SectionHeader description="What we're shipping and promoting right now.">For you</SectionHeader>
          <div className={styles.promoGrid}>
            <PromoLinkTile feature imageSrc={navigatorImageSrc}>
              <PromoTileHeader onFeature>The assistant</PromoTileHeader>
              <h3>Claves Navigator</h3>
              <p>
                Ask for anything in the platform and it does it — search the registry, compare models, walk you
                through onboarding.
              </p>
              <PromoTileFooter>
                <ActionButton variant="onDark" onClick={() => ask('')}>Open Navigator</ActionButton>
              </PromoTileFooter>
            </PromoLinkTile>

            <PromoLinkTile>
              <PromoTileHeader>Where we're going</PromoTileHeader>
              <h3>Claves Microsite</h3>
              <p>Roadmap, delivery status and announcements for every capability — tools, skills, models, governance.</p>
              <PromoTileFooter>
                <ExternalLink href="#microsite">Visit the microsite</ExternalLink>
              </PromoTileFooter>
            </PromoLinkTile>

            <PromoLinkTile>
              <PromoTileHeader>Same agent, in Microsoft</PromoTileHeader>
              <h3>Claves in M365 Copilot</h3>
              <p>Prefer to stay in Teams or Word? Reach the same assistant from inside Copilot.</p>
              <PromoTileFooter>
                <ExternalLink href="#m365">Open in Copilot</ExternalLink>
              </PromoTileFooter>
            </PromoLinkTile>
          </div>
        </section>

        <section className={styles.section}>
          <SectionHeader description="A skill, a tool and a model you can use in the next minute.">
            Featured
          </SectionHeader>
          <div className={styles.featureGrid}>
            <FeatureCard>
              <FeatureCardTags>
                <Tag tone="kind">Skill</Tag>
                <Tag>ubs-wide-shared</Tag>
              </FeatureCardTags>
              <h3>skill-builder</h3>
              <p>The skill that builds skills — creation, validation and audit of agent skills, ready to attach.</p>
              <FeatureCardMeta>
                Custodian · Shared skills registry maintainers
                <br />
                Eval · N/A
              </FeatureCardMeta>
              <FeatureCardFooter>
                <TryActionSkill onAsk={ask} />
              </FeatureCardFooter>
            </FeatureCard>

            <FeatureCard>
              <FeatureCardTags>
                <Tag tone="kind">Tool</Tag>
                <Tag tone="pending">Live, with limits</Tag>
              </FeatureCardTags>
              <h3>Document Extraction</h3>
              <p>
                OCR and text extraction over any document — Azure Doc Intelligence plus UBS extensions, exposed as an
                MCP server.
              </p>
              <FeatureCardMeta>
                doc-processor-mcp · v1.0.0 · INHOUSE
                <br />
                Global Markets onboarding Sep-26 · GA end-Oct 2026
              </FeatureCardMeta>
              <FeatureCardFooter>
                <TryActionTool onAsk={ask} />
              </FeatureCardFooter>
            </FeatureCard>

            <FeatureCard>
              <FeatureCardTags>
                <Tag tone="kind">Model</Tag>
                <Tag tone="ready">UBS-hosted</Tag>
              </FeatureCardTags>
              <h3>Qwen3.6-27B</h3>
              <p>Most-used model on Claves. Advanced reasoning, tool calling and multimodal input, on H100s.</p>
              <StatRow>
                <Stat label="context">262.1k</Stat>
                <Stat label="blended / 1M">$0.247</Stat>
                <Stat label="tokens · 30d">2.4B</Stat>
              </StatRow>
              <FeatureCardFooter>
                <TryActionModel />
              </FeatureCardFooter>
            </FeatureCard>
          </div>
        </section>

        <ClosingStrip action={<ActionButton variant="solid" onClick={() => ask('')}>Start a conversation</ActionButton>}>
          <h2>Not sure where to start?</h2>
          <p>Navigator can explain what Claves gives your team, and set up your first agent with you.</p>
        </ClosingStrip>
      </div>
    </div>
  );
}

export default HomePage;

interface AskProps {
  onAsk: (prompt: string) => void;
}

function TryActionSkill({ onAsk }: AskProps) {
  return <TryAction prompt="/skill-builder" label="Try in Navigator →" onClick={() => onAsk('/skill-builder')} />;
}

function TryActionTool({ onAsk }: AskProps) {
  return (
    <TryAction
      prompt="extract the tables from…"
      label="Try in Navigator →"
      onClick={() => onAsk('extract the tables from ')}
    />
  );
}

function TryActionModel() {
  return <TryAction prompt="Set as model in Navigator" label="selector coming" disabled />;
}
