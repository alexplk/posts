import type { ReactNode } from 'react';
import styles from './SectionHeader.module.css';

export interface SectionHeaderProps {
  /** Supporting line set beside the title. */
  description?: ReactNode;
  children: ReactNode;
}

export function SectionHeader({ description, children }: SectionHeaderProps) {
  return (
    <div className={styles.header}>
      <h2 className={styles.title}>{children}</h2>
      {description ? <span className={styles.description}>{description}</span> : null}
    </div>
  );
}
