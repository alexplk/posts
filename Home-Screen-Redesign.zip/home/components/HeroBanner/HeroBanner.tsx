import type { ReactNode } from 'react';
import styles from './HeroBanner.module.css';

export type HeroFocal = 'left' | 'center' | 'right' | 'top' | 'bottom';

const FOCAL_CLASS: Record<HeroFocal, string> = {
  left: 'focalLeft',
  center: 'focalCenter',
  right: 'focalRight',
  top: 'focalTop',
  bottom: 'focalBottom',
};

export interface HeroBannerProps {
  /** Small uppercase line above the title. */
  eyebrow?: ReactNode;
  /** Headline. Pass markup for mixed weights. */
  title: ReactNode;
  /** One or two sentences under the headline. */
  subtitle?: ReactNode;
  imageSrc?: string;
  imageAlt?: string;
  /** Which part of the photo to protect when the band crops. */
  focal?: HeroFocal;
  /**
   * 'auto' (default) bleeds edge to edge and snaps into the 1440 rail once the
   * surrounding container passes 1800px. true/false force one treatment.
   */
  inset?: boolean | 'auto';
}

export function HeroBanner({
  eyebrow,
  title,
  subtitle,
  imageSrc,
  imageAlt = '',
  focal = 'center',
  inset = 'auto',
}: HeroBannerProps) {
  const variant = inset === 'auto' ? styles.autoInset : inset ? styles.inset : '';
  const className = variant ? styles.banner + ' ' + variant : styles.banner;

  return (
    <section className={className}>
      {imageSrc ? (
        <img className={styles.image + ' ' + styles[FOCAL_CLASS[focal]]} src={imageSrc} alt={imageAlt} />
      ) : (
        <div className={styles.imageFallback} />
      )}
      <div className={styles.scrim} />
      <div className={styles.rail}>
        <div className={styles.railInner}>
          {eyebrow ? <div className={styles.eyebrow}>{eyebrow}</div> : null}
          <h1 className={styles.title}>{title}</h1>
          {subtitle ? <p className={styles.subtitle}>{subtitle}</p> : null}
        </div>
      </div>
    </section>
  );
}

export interface HeroEmphasisProps {
  children: ReactNode;
}

/** Accent word inside a HeroBanner title. */
export function HeroEmphasis({ children }: HeroEmphasisProps) {
  return <strong className={styles.emphasis}>{children}</strong>;
}
