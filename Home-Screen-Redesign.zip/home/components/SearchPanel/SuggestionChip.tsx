import type { ReactNode } from 'react';
import styles from './SuggestionChip.module.css';

export interface SuggestionChipProps {
  onClick?: () => void;
  children: ReactNode;
}

export function SuggestionChip({ onClick, children }: SuggestionChipProps) {
  return (
    <button className={styles.chip} type="button" onClick={onClick}>
      {children}
    </button>
  );
}
