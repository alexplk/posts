import type { FormEvent, ReactNode } from 'react';
import { useState } from 'react';
import styles from './SearchPanel.module.css';

export interface SearchPanelProps {
  placeholder?: string;
  submitLabel?: string;
  defaultValue?: string;
  onSubmit?: (query: string) => void;
  /** SuggestionChip elements. */
  children?: ReactNode;
}

export function SearchPanel({
  placeholder = 'Ask anything…',
  submitLabel = 'Ask',
  defaultValue = '',
  onSubmit,
  children,
}: SearchPanelProps) {
  const [value, setValue] = useState(defaultValue);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    onSubmit?.(value);
  }

  return (
    <form className={styles.panel} onSubmit={handleSubmit}>
      <div className={styles.row}>
        <input
          className={styles.field}
          value={value}
          placeholder={placeholder}
          aria-label={placeholder}
          onChange={(event) => setValue(event.target.value)}
        />
        <button className={styles.submit} type="submit">{submitLabel}</button>
      </div>
      {children ? <div className={styles.suggestions}>{children}</div> : null}
    </form>
  );
}
