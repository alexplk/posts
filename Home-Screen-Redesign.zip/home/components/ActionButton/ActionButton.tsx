import type { ReactNode } from 'react';
import styles from './ActionButton.module.css';

export type ActionButtonVariant = 'primary' | 'onDark' | 'outline' | 'solid';

export interface ActionButtonProps {
  variant?: ActionButtonVariant;
  /** Renders an anchor instead of a button. */
  href?: string;
  onClick?: () => void;
  children: ReactNode;
}

export function ActionButton({ variant = 'primary', href, onClick, children }: ActionButtonProps) {
  const className = styles.button + ' ' + styles[variant];

  if (href) {
    return <a className={className} href={href}>{children}</a>;
  }

  return (
    <button className={className} type="button" onClick={onClick}>
      {children}
    </button>
  );
}
