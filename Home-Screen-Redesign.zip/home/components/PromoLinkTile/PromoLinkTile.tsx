import type { ReactNode } from 'react';
import styles from './PromoLinkTile.module.css';

export interface PromoLinkTileProps {
  /** Dark, image-topped treatment for the one tile that should dominate. */
  feature?: boolean;
  imageSrc?: string;
  imageAlt?: string;
  children: ReactNode;
}

export function PromoLinkTile({ feature = false, imageSrc, imageAlt = '', children }: PromoLinkTileProps) {
  const className = feature ? styles.tile + ' ' + styles.feature : styles.tile;

  return (
    <article className={className}>
      {feature ? (
        <div className={styles.media}>
          {imageSrc ? <img className={styles.mediaImage} src={imageSrc} alt={imageAlt} /> : null}
          <div className={styles.mediaScrim} />
        </div>
      ) : null}
      <div className={styles.body}>{children}</div>
    </article>
  );
}
