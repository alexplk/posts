import type { ReactNode } from 'react';
import styles from './PromoTileFooter.module.css';

export interface PromoTileFooterProps {
  children: ReactNode;
}

export function PromoTileFooter({ children }: PromoTileFooterProps) {
  return <div className={styles.footer}>{children}</div>;
}
