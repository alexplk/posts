import type { ReactNode } from 'react';
import styles from './PromoTileHeader.module.css';

export interface PromoTileHeaderProps {
  /** Use inside a feature (dark) tile. */
  onFeature?: boolean;
  children: ReactNode;
}

export function PromoTileHeader({ onFeature = false, children }: PromoTileHeaderProps) {
  const className = onFeature ? styles.header + ' ' + styles.onFeature : styles.header;
  return <div className={className}>{children}</div>;
}
