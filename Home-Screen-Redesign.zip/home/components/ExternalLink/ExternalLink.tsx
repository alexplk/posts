import type { ReactNode } from 'react';
import styles from './ExternalLink.module.css';

export interface ExternalLinkProps {
  href: string;
  children: ReactNode;
}

export function ExternalLink({ href, children }: ExternalLinkProps) {
  return (
    <a className={styles.link} href={href} target="_blank" rel="noreferrer">
      {children}
      <span className={styles.glyph} aria-hidden="true">↗</span>
    </a>
  );
}
