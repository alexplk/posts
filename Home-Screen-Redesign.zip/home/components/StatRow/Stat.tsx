import type { ReactNode } from 'react';
import styles from './Stat.module.css';

export interface StatProps {
  label: ReactNode;
  children: ReactNode;
}

export function Stat({ label, children }: StatProps) {
  return (
    <div>
      <div className={styles.value}>{children}</div>
      <div className={styles.label}>{label}</div>
    </div>
  );
}
