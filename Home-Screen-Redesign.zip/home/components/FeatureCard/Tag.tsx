import type { ReactNode } from 'react';
import styles from './Tag.module.css';

export type TagTone = 'neutral' | 'kind' | 'pending' | 'ready';

export interface TagProps {
  tone?: TagTone;
  children: ReactNode;
}

export function Tag({ tone = 'neutral', children }: TagProps) {
  const className = tone === 'neutral' ? styles.tag : styles.tag + ' ' + styles[tone];
  return <span className={className}>{children}</span>;
}
