import type { ReactNode } from 'react';
import styles from './FeatureCard.module.css';

export interface FeatureCardProps {
  children: ReactNode;
}

export function FeatureCard({ children }: FeatureCardProps) {
  return <article className={styles.card}>{children}</article>;
}
