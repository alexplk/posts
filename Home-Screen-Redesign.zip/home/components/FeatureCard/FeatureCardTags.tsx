import type { ReactNode } from 'react';
import styles from './FeatureCardTags.module.css';

export interface FeatureCardTagsProps {
  children: ReactNode;
}

export function FeatureCardTags({ children }: FeatureCardTagsProps) {
  return <div className={styles.tags}>{children}</div>;
}
