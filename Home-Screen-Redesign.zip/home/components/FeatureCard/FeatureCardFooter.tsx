import type { ReactNode } from 'react';
import styles from './FeatureCardFooter.module.css';

export interface FeatureCardFooterProps {
  children: ReactNode;
}

export function FeatureCardFooter({ children }: FeatureCardFooterProps) {
  return <div className={styles.footer}>{children}</div>;
}
