import type { ReactNode } from 'react';
import styles from './FeatureCardMeta.module.css';

export interface FeatureCardMetaProps {
  children: ReactNode;
}

export function FeatureCardMeta({ children }: FeatureCardMetaProps) {
  return <div className={styles.meta}>{children}</div>;
}
