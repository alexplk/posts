import type { ReactNode } from 'react';
import styles from './ClosingStrip.module.css';

export interface ClosingStripProps {
  /** Button or link closing the page. */
  action?: ReactNode;
  children: ReactNode;
}

export function ClosingStrip({ action, children }: ClosingStripProps) {
  return (
    <section className={styles.strip}>
      <div className={styles.body}>{children}</div>
      {action ? <div className={styles.action}>{action}</div> : null}
    </section>
  );
}
