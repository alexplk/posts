import type { ReactNode } from 'react';
import styles from './TryAction.module.css';

export interface TryActionProps {
  /** The prompt or capability this action hands to the assistant. */
  prompt: ReactNode;
  /** Right-aligned call to action, or a status note when disabled. */
  label: ReactNode;
  /** Renders the muted, non-clickable state for capabilities that are not live yet. */
  disabled?: boolean;
  onClick?: () => void;
}

export function TryAction({ prompt, label, disabled = false, onClick }: TryActionProps) {
  const className = disabled ? styles.action + ' ' + styles.disabled : styles.action;

  return (
    <button className={className} type="button" disabled={disabled} onClick={onClick}>
      <span className={styles.prompt}>{prompt}</span>
      <span className={styles.label}>{label}</span>
    </button>
  );
}
