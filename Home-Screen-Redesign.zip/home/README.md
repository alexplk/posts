# Claves home

Drop-in replacement for the portal home screen. `HomePage.tsx` is the only file
that knows about Claves — everything in `components/` is generic and content-free.

    home/
      HomePage.tsx            composition + copy + data
      HomePage.module.css     page rail, grids, section rhythm
      index.ts
      components/
        HeroBanner/           full-bleed photo band, snaps to the rail when wide
        SearchPanel/          search field + SuggestionChip
        SectionHeader/        34px light title + supporting line
        PromoLinkTile/        PromoTileHeader / PromoTileFooter slots
        FeatureCard/          FeatureCardTags / Tag / FeatureCardMeta / FeatureCardFooter
        TryAction/            prompt chip that hands work to the assistant
        StatRow/              StatRow / Stat
        ActionButton/         primary · onDark · outline · solid
        ExternalLink/         outline link with the ↗ glyph
        ClosingStrip/         trailing call to action

## Using it

    import HomePage from './home';

    <HomePage
      heroImageSrc={heroPhoto}
      navigatorImageSrc={navigatorPhoto}
      onSearch={(query) => navigate('/navigator?q=' + encodeURIComponent(query))}
      onAskNavigator={(prompt) => openNavigator(prompt)}
    />

The page paints its own light-gray ground and expects to sit inside your existing
masthead + sidenav. It has no fixed width: give it a normal block container.

## Responsive band

`HomePage.module.css` declares `container-type: inline-size` on the page root, so
`HeroBanner` can decide for itself: wall-to-wall while the content area is under
1800px, snapped into the 1440px rail above it. Force either treatment with
`inset={true}` / `inset={false}`. Change the snap point in
`HeroBanner.module.css` (`@container (min-width: 1800px)`).

## Conventions

- One `.module.css` per component, no shared stylesheet, no inline styles.
- Composition over configuration: tiles take `children` and slot components
  rather than `title`/`body`/`ctaLabel` props.
- Values live in `HomePage.tsx`. Nothing under `components/` mentions Claves,
  Navigator, models or any copy.

## Prototype harness

`/preview` (outside `home/`) fakes the masthead and side nav so the page can be
run standalone, with a width switcher to check the band snap.

    npm install && npm run dev

## Images

    home/assets/
      hero-band.webp        1200 x 795   band behind the headline
      navigator-tile.webp    952 x 628   strip on the Navigator tile

Both are wired as defaults in `HomePage.tsx` and overridable via
`heroImageSrc` / `navigatorImageSrc`.

### Sizing

The band is a fixed 420px tall and as wide as the content area, so on a 3000px
screen it is roughly **2700 x 420 — a 6.4:1 slice**. `object-fit: cover` keeps
the aspect ratio and crops the rest, which means a normal 3:2 photo shows only
its middle ~23% vertically. That is what decapitates people in a stock shot.

Source images should be:

| Slot | Minimum | Comfortable | Aspect |
|---|---|---|---|
| Hero band | 2200 x 900 | **2560 x 1000** | wide, 2.5:1 or wider |
| Navigator tile | 900 x 400 | 1200 x 500 | wide, ~2.4:1 |

The current files are smaller than that, so they upscale on very wide monitors.
They look right up to about 1800px and soften past it — replace with a 2560px
export when you have one. Keep them under ~300KB as WebP.

### Focal point

`HeroBanner` takes `focal="left | center | right | top | bottom"`, which sets
`object-position` in CSS — no inline styles. Pick the side the subject is on;
the headline occupies the left of the band, so a subject on the right reads
best. The current photo uses `focal="right"`.

The vertical anchor is 40% for left/center/right, which keeps faces in frame on
a shallow crop. Use `focal="top"` if heads still clip in a taller photo.

### Choosing stock

What survives this crop: corridors, facades, glass, desks shot side-on, texture
and material — anything where the interesting content is a horizontal band. What
fails: portraits, anything with a single subject centred vertically, anything
with important detail near the top or bottom edge.
