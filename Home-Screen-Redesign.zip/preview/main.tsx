import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { PreviewShell } from './PreviewShell';
import './preview.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <PreviewShell />
  </StrictMode>,
);
