import { useState } from 'react';
import { HomePage } from '../home';
import styles from './PreviewShell.module.css';

const NAV = [
  { label: 'Home', active: true },
  { label: 'Navigator' },
  { label: 'My agents', children: ['Running', 'Drafts'] },
  { label: 'Favorites' },
  { label: 'Marketplace', children: [] },
  { label: 'Skills & tools' },
  { label: 'Models' },
  { label: 'Claves Governance' },
  { label: 'Latest Updates' },
  { label: 'Learn' },
  { label: 'Support' },
];

const WIDTHS = [
  { label: '1440', value: 1440 },
  { label: '2000', value: 2000 },
  { label: '2560', value: 2560 },
  { label: 'Fill', value: 0 },
];

export function PreviewShell() {
  const [width, setWidth] = useState(0);

  return (
    <div className={styles.shell} style={width ? { width, margin: '0 auto' } : undefined}>
      <header className={styles.masthead}>
        <span className={styles.brand}>UBS</span>
        <span className={styles.product}>Claves</span>
        <div className={styles.utilities}>
          <span className={styles.utility} />
          <span className={styles.utility} />
          <span className={styles.avatar} />
        </div>
      </header>

      <div className={styles.body}>
        <nav className={styles.sidenav}>
          {NAV.map((item) => (
            <div key={item.label}>
              <div className={item.active ? styles.navItem + ' ' + styles.navItemActive : styles.navItem}>
                {item.label}
                {item.children ? <span className={styles.chevron}>▾</span> : null}
              </div>
              {item.children?.map((child) => (
                <div key={child} className={styles.navChild}>{child}</div>
              ))}
            </div>
          ))}
        </nav>

        <main className={styles.content}>
          <HomePage onSearch={(query) => console.log('search', query)} />
        </main>
      </div>

      <div className={styles.switcher}>
        {WIDTHS.map((option) => (
          <button
            key={option.label}
            type="button"
            className={
              width === option.value ? styles.switchButton + ' ' + styles.switchButtonActive : styles.switchButton
            }
            onClick={() => setWidth(option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
}
