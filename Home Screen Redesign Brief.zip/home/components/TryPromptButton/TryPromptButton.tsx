import { useEffect, useRef, useState } from 'react';
import styles from './TryPromptButton.module.css';

export interface TryPromptButtonProps {
  /** One or more example prompts. More than one turns on the carousel. */
  prompts: string[];
  /** Called with the prompt currently showing. */
  onClick?: (prompt: string) => void;
  /**
   * Dots take no layout height: they hang 16px into the parent's bottom
   * padding (give the parent at least ~20px). Default false — dots add a 16px row.
   */
  hangingDots?: boolean;
  /** Auto-advance interval in ms. 0 disables auto-advance. */
  interval?: number;
}

export function TryPromptButton({ prompts, onClick, hangingDots = false, interval = 4500 }: TryPromptButtonProps) {
  const count = prompts.length;
  const [active, setActive] = useState(0);
  const [leaving, setLeaving] = useState<number | null>(null);
  const [paused, setPaused] = useState(false);
  const activeRef = useRef(0);

  function goTo(index: number) {
    const next = ((index % count) + count) % count;
    if (next === activeRef.current) return;
    setLeaving(activeRef.current);
    activeRef.current = next;
    setActive(next);
  }

  useEffect(() => {
    if (count < 2 || interval <= 0 || paused) return;
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    const timer = window.setInterval(() => goTo(activeRef.current + 1), interval);
    return () => window.clearInterval(timer);
  }, [count, interval, paused]);

  useEffect(() => {
    if (activeRef.current >= count) {
      activeRef.current = 0;
      setActive(0);
      setLeaving(null);
    }
  }, [count]);

  if (count === 0) return null;

  const current = prompts[Math.min(active, count - 1)];
  const dotsClass = hangingDots ? styles.dots + ' ' + styles.hanging : styles.dots;

  function slideClass(index: number) {
    if (index === active) return styles.slide + ' ' + styles.active;
    if (index === leaving) return styles.slide + ' ' + styles.leaving;
    return styles.slide;
  }

  return (
    <div
      className={styles.root}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
    >
      <button className={styles.bubble} type="button" onClick={() => onClick?.(current)}>
        <span className={styles.viewport} aria-live={count > 1 ? 'polite' : undefined}>
          {prompts.map((prompt, index) => (
            <span key={index} className={slideClass(index)} aria-hidden={index !== active}>
              {prompt}
            </span>
          ))}
        </span>
        <span className={styles.arrow} aria-hidden="true">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 7h10M8 3l4 4-4 4" />
          </svg>
        </span>
      </button>

      {count > 1 || !hangingDots ? (
        <div className={dotsClass}>
          {count > 1
            ? prompts.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={index === active ? styles.dot + ' ' + styles.dotActive : styles.dot}
                  aria-label={'Show example ' + (index + 1) + ' of ' + count}
                  aria-current={index === active}
                  onClick={() => goTo(index)}
                />
              ))
            : null}
        </div>
      ) : null}
    </div>
  );
}

export default TryPromptButton;
