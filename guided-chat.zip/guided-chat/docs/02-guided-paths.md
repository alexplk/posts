# Feature 2 — Guided Paths

**Priority: high.** Trickier to pin down; the flagship "inspiring" bet.

## Concept

Walk a user through a **complex process**: recognize what they're trying to accomplish
and guide them. The assistant:
- presents **steps**,
- **asks for inputs**,
- gives **suggestions**,
- helps **look things up**,
- shows **progress**,
- ties it together with a **UI**.

## What it's made of

A combination of:
- **Documentation** — big part of the portal, its own app, spans user roles (tech →
  business).
- **Skills**
- **Tools**
- **A UI to tie things together.**

## Reference points

Compared to **cowork** in Claude, Copilot, and other assistants — a guided, multi-step,
assisted-work experience (not a one-shot answer).

## Design threads to develop

- **Path model**: what *is* a guided path as data? Authored (from docs) vs. dynamically
  assembled by the agent vs. hybrid. Likely hybrid: docs/skills define the spine, agent
  adapts.
- **Step UI**: progress indicator, current-step focus, input collection, suggestions,
  lookups inline. Steps likely render **fragments** (forms, asset pickers, results).
- **State**: a path is stateful across turns — inputs gathered, steps done/remaining,
  resumable. Relationship to conversation state.
- **Docs as source**: how documentation content becomes a runnable/guided path. Does the
  docs app author these, or does the agent synthesize from docs + skills at runtime?
- **Handoffs**: a path step may need Search (feature 1) or a Collection (feature 3) —
  these compose.

## Open questions

- Who authors paths, and in what format? Is there a registry of paths (another asset type)?
- How much is deterministic (scripted steps) vs. agent-driven?
- Success/exit criteria — when is a path "complete"?
