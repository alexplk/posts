# Shared Infrastructure

The three features are expected to share a common core. Keep this visible so the reusable
layer doesn't get reinvented per feature.

## Two cross-cutting primitives

### 1. Fragments = the render layer
(see [glossary](glossary.md))

Independent, side-effect-free JS modules exposing components/code across apps at runtime.
Every feature renders marketplace-owned UI inside the assistant via fragments:
- **Search** → asset-tile fragments in a compact list.
- **Guided Paths** → step UIs render fragments (forms, pickers, results).
- **Collections** → pin operates on tiles/fragments; pinned items shown as fragments.

Implication: chat never reimplements asset UI. Marketplaces may need to expose **variants**
(e.g. compact tile, pinned chip).

### 2. Collections = the context layer

A single collection primitive (per Alex: "it's the same mechanism") with different
scopes/lifetimes: favorites, named/shared collections, and **pinned-for-chat**. Feeds
selected assets into the agent as context. Composes with the other features:
- Search results → pin into a collection.
- A Guided Path step → pull from / add to a collection.

## Rough layering (to validate)

- **Fragments**: presentation, cross-app, no shared runtime.
- **Collections**: selection/context state.
- **Agent (LangGraph)**: intent recognition (search vs. path vs. chat), orchestration.
- **assistant-ui**: chat shell, message/tool-render slots, fullscreen⇄sidebar.

## Recurring open questions across features

- Where does **intent recognition** live and how do features hand off to each other?
- Which **fragment variants** must the marketplaces expose?
- Is there a **path** asset type / registry, parallel to existing asset types?
