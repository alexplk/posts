# Glossary

Durable definitions for the guided-chat design thread. Add terms as they come up.

## Portal

Our suite of apps. Contains:
- **AI marketplace**
- **Data marketplace**
- **Home** — dashboard, updates, etc.
- **Search**
- ...and others.

## Fragment

A mechanism by which apps expose their modules to be used by other apps **at runtime**.
Module-federation-like, but:
- **No runtime sharing**, no version negotiation.
- Modules are **completely independent JS modules** with **no global side effects**.
- Supports both **components** and **code**.

Example: render asset tiles as fragments from the AI/Data marketplace inside the Home
dashboard or inside search results.
