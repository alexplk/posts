# guided-chat — docs index

Design notes for a set of related assistant features on the Portal. See
[../AGENTS.md](../AGENTS.md) for how to work in this sandbox (design/direction only,
expect drift from the real unseen codebase).

## Contents

- [glossary.md](glossary.md) — durable definitions (Portal, Fragment, ...).
- [00-shared-infrastructure.md](00-shared-infrastructure.md) — the common core:
  fragments (render layer) + collections (context layer).
- [01-search-via-assistant.md](01-search-via-assistant.md) — **high** — search-shaped
  requests render a real search UX inside chat.
- [02-guided-paths.md](02-guided-paths.md) — **high** — walk users through complex,
  multi-step processes (docs + skills + tools + UI); cowork-like.
- [03-collections.md](03-collections.md) — **low** — align portal Collections with the
  assistant; pin assets as chat context via fragments.
