# Feature 3 — Collections

**Priority: lowest of the three.** About aligning existing portal Collections with the
assistant.

## What Collections are (in portal today)

A set of features to group assets:
- **Favorites** — personal; a dedicated page already exists.
- **Named, shareable collections** — for collaboration.
- General ability to **pick assets and use them**.

## What Alex wants for the assistant

- A **collection of pinned items used as chat input** — the assistant "sees" them as
  context.
- Interaction idea: **open an asset from an on-screen list → pin it → chat sees it.**
- There's an **existing front-end tool** for this, but it was **never designed to work
  with tiles (fragments)** — want to tie it to fragments.
- Also tie in the **other collections** (favorites, named/shared).
- Belief: **it's the same mechanism** underneath all of these.

## Design threads to develop

- **Pin ⇄ context bridge**: pinning an asset injects it into the agent's context. What
  gets sent — asset id/ref, or a richer payload? How is it shown in the composer.
- **Fragment integration**: the pin tool operates on **fragments/tiles**, so pinning from
  a rendered tile (in search results, dashboard, a path step) is one gesture.
- **One mechanism, many sources**: pinned-for-chat, favorites, named collections all as
  the same underlying collection primitive with different scopes/lifetimes.
- **Sharing**: named collections are shareable — does a chat-pinned set become shareable
  / promotable to a named collection?

## Open questions

- Is "pinned for this chat" ephemeral (per-conversation) or persistent?
- What's the existing front-end tool, and what are its current limits vs. fragments?
