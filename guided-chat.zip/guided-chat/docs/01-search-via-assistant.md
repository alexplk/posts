# Feature 1 — Search via Assistant

**Priority: high.** Goal: deliver something *inspiring* before launch.

## Context

- Home page search box leads **immediately to fullscreen assistant chat** (collapsible
  to sidebar view).
- When a typed request is **recognized as a search request**, the assistant should
  present results in a way **comparable to a real search experience** — not just prose.

## Initial direction (Alex's first thoughts)

- Probably a **list** layout.
- **Ability to filter further** in-place.
- **More items, less text** — dense, scannable.
- More to come.

## Design threads to develop

- **Intent recognition**: how/where "this is a search" is detected (agent-side classify
  vs. tool call). Affects whether the UI is a tool-rendered result or a message type.
- **Result rendering**: reuse marketplace **asset-tile fragments** (see [glossary](glossary.md))
  in a list/compact variant rather than reimplementing tiles in chat.
- **Filtering**: conversational (refine by asking) + direct UI controls (facets). Likely
  both; keep them in sync.
- **Search vs. chat continuity**: results live inside a conversation — how does refining,
  scrolling back, and follow-up ("open the 3rd one", "only datasets") work.
- **Fullscreen vs. sidebar**: dense results need room; behavior when collapsed to sidebar.

## Prototype

Scaffolded in [`../poc`](../poc) (pnpm workspace). Relevant pieces:
- `packages/chatbot` — assistant-ui sidebar + **`search` frontend tool** wired to a
  browser-side mock search API. The mock `ChatModelAdapter` detects a search request and
  emits a `search` tool-call; `SearchToolUI` renders results as compact marketplace
  fragments with a pin action. Hand the `SearchArgs`/`SearchResult` shapes to the agent
  devs to mirror as the real tool.
- `packages/core/mock-search.ts` — stand-in for the existing UI search API.
- Result rows reuse `collections`' `AssetTile` → `marketplace-fragments`, proving the
  "no reimplemented tile UI in chat" goal.

Next steps in the POC: facet filters (by asset type) in `SearchToolUI`, sidebar vs.
fullscreen density, "open the 3rd one" style follow-ups.

## Open questions

- Which asset types are searchable here vs. the dedicated Search app? Is this the same
  backend search API?
- Is the compact tile a new fragment variant the marketplaces must expose?
