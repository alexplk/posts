import { useLocalRuntime } from "@assistant-ui/react";
import { useEffect } from "react";
import { mockAgentAdapter } from "./runtime";
import { loadMessages, saveMessages } from "./conversations";

/**
 * Local runtime bound to one conversation: restores that conversation's messages and saves
 * on every thread change. Mount with key={conversationId} so switching conversations
 * remounts with the right history.
 *
 * NOTE: assistant-ui-version-sensitive — `initialMessages`, `thread.subscribe`, and
 * `thread.getState()` are the API surface to check if history doesn't hydrate.
 */
export function usePersistentRuntime(conversationId: string) {
  const runtime = useLocalRuntime(mockAgentAdapter, {
    initialMessages: loadMessages(conversationId),
  });

  useEffect(() => {
    return runtime.thread.subscribe(() => {
      saveMessages(conversationId, runtime.thread.getState().messages);
    });
  }, [runtime, conversationId]);

  return runtime;
}
