import { toggleChecklistItem, useChecklist } from "./conversations";

/** Live checklist (current conversation's workspace.checklist). Hidden until populated. */
export function TaskListPanel() {
  const checklist = useChecklist();
  if (checklist.length === 0) return null;

  const done = checklist.filter((t) => t.done).length;
  return (
    <div className="cb-tasks">
      <div className="cb-tasks__head">
        <h3>Checklist</h3>
        <span className="col-pins__count">{done}/{checklist.length}</span>
      </div>
      <ul className="cb-tasks__list">
        {checklist.map((t) => (
          <li key={t.id}>
            <label className="cb-tasks__item">
              <input type="checkbox" checked={t.done} onChange={() => toggleChecklistItem(t.id)} />
              <span className={t.done ? "cb-tasks__text cb-tasks__text--done" : "cb-tasks__text"}>
                {t.text}
              </span>
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}
