import { AssetTile } from "@poc/collections-fragments";
import { useArtifacts } from "./conversations";

/** Collected artifacts (workspace.artifacts): assets + text blocks for now. */
export function ArtifactsPanel() {
  const artifacts = useArtifacts();
  if (artifacts.length === 0) return null;

  return (
    <div className="art">
      <div className="cb-tasks__head">
        <h3>Artifacts</h3>
        <span className="col-pins__count">{artifacts.length}</span>
      </div>
      <ul className="mp-list mp-compact">
        {artifacts.map((a) =>
          a.kind === "asset" ? (
            <li key={a.id}>
              <AssetTile type={a.ref.type} id={a.ref.id} />
            </li>
          ) : (
            <li key={a.id} className="art__text">
              {a.text}
            </li>
          ),
        )}
      </ul>
    </div>
  );
}
