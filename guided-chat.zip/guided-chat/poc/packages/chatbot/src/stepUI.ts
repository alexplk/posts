import { useSyncExternalStore } from "react";

/**
 * Which step's linked UI is currently shown inline (by step id). Ephemeral (not persisted)
 * so nothing pops on reload. Set by auto-show (first time a step becomes current) or by
 * clicking a step; cleared when the user types. Fresh token so re-showing the same step fires.
 */
let shown: { id: string; n: number } | null = null;
let seq = 0;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export function showStepUI(id: string) {
  shown = { id, n: ++seq };
  emit();
}
export function clearStepUI() {
  if (shown) {
    shown = null;
    emit();
  }
}
export const useShownStepUI = () =>
  useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => shown,
  );
