import type { ChatModelAdapter } from "@assistant-ui/react";
import { parseSearch, searchApi } from "./mock-search-api";
import {
  advanceStep,
  getArtifacts,
  getSteps,
  setChecklist,
  setSteps,
  tickByToken,
} from "./conversations";
import type { Artifact, StepUI } from "./conversations";
import { clearStepUI } from "./stepUI";
import { clearUsedPins } from "@poc/collections-fragments";

let toolCallId = 0;

/**
 * Mock local runtime — the stub agent. Stands in for the LangGraph agent. It parses the
 * user turn and drives workspace tools (search / checklist / steps / artifacts). Tools that
 * change workspace state write the store directly AND emit a tool-call for the thread
 * (reliable, doesn't depend on the assistant-ui execute round-trip).
 */
export const mockAgentAdapter: ChatModelAdapter = {
  async run({ messages }) {
    const last = messages[messages.length - 1];

    // Re-invoked after a tool-call → summarize, don't loop.
    if (last?.role === "assistant") {
      return { content: [{ type: "text", text: "Done." }] };
    }

    const text =
      last?.content
        .map((p) => (p.type === "text" ? p.text : ""))
        .join(" ")
        .trim() ?? "";

    if (!text) {
      return {
        content: [{ type: "text", text: "Try “find KYC agents”, “plan: a, b, c”, “steps”, “step”, or “done 2”." }],
      };
    }

    // The user typed → dismiss any step's inline UI that's currently shown.
    clearStepUI();

    // --- steps: "steps[: a, b, c]" sets steps (linked UIs auto-show as steps become current) ---
    const stepsSet = parseStepsSet(text);
    if (stepsSet !== undefined) {
      const steps = stepsSet ?? defaultSteps();
      setSteps(steps);
      return toolTurn("Laid out the steps…", "updateStepList", { steps }, { count: steps.length });
    }

    // --- tick a specific item: "done <n>" / "<n> done" ---
    const tick = parseTick(text);
    if (tick) {
      tickByToken(tick);
      return { content: [{ type: "text", text: `Marked “${tick}” done.` }] };
    }

    // --- advance: bare "step" / "done" (completes the next step; collect explodes Review) ---
    if (/^(step|done)\b/i.test(text)) {
      const steps = getSteps();
      const nextIdx = steps.findIndex((s) => !s.done);
      const wasCollect = nextIdx >= 0 && steps[nextIdx].kind === "collect";
      advanceStep();
      if (wasCollect) {
        const artifacts = getArtifacts();
        clearUsedPins(); // pins were consumed into artifacts → clear (kept in history)
        return {
          content: [
            { type: "text", text: "Collected assets into Artifacts." },
            {
              type: "tool-call",
              toolCallId: `updateArtifacts-${++toolCallId}`,
              toolName: "updateArtifacts",
              args: { artifacts: artifacts.map(toArtifactArg) },
              result: { count: artifacts.length },
            },
            {
              type: "tool-call",
              toolCallId: `clearUsedPins-${++toolCallId}`,
              toolName: "clearUsedPins",
              args: {},
              result: {},
            },
          ],
        };
      }
      // The newly-current step's linked UI (review form, submit, …) auto-shows via StepUISlot.
      return { content: [{ type: "text", text: "Advanced to the next step." }] };
    }

    // --- checklist: "plan/checklist/tasks[: a, b, c]" ---
    const taskList = parseTaskCommand(text);
    if (taskList) {
      setChecklist(taskList);
      return toolTurn("Setting up your checklist…", "updateTaskList", { tasks: taskList }, { count: taskList.length });
    }

    // --- default: search (stub produces the result inline) ---
    const args = parseSearch(text);
    const { results } = await searchApi(args);
    const scope = args.types?.length ? args.types[0].split("/")[1] + "s" : "everything";
    return toolTurn(`Searched ${scope} for “${args.query || "*"}”:`, "search", args, { results });
  },
};

function toolTurn(text: string, toolName: string, args: unknown, result: unknown) {
  return {
    content: [
      { type: "text" as const, text },
      { type: "tool-call" as const, toolCallId: `${toolName}-${++toolCallId}`, toolName, args, result },
    ],
  };
}

function toArtifactArg(a: Artifact) {
  return a.kind === "asset" ? { kind: "asset", type: a.ref.type, id: a.ref.id } : { kind: "text", text: a.text };
}

/** "plan: a, b, c" / "checklist: …" / "tasks: …" → [{text}]. Null if not a task cmd. */
function parseTaskCommand(text: string): { text: string }[] | null {
  const m = /^(plan|checklist|tasks?)\b[:\-\s]*(.*)$/i.exec(text.trim());
  if (!m) return null;
  const body = m[2].trim();
  const items = body
    ? body.split(/[,;]|\n/).map((s) => s.trim()).filter(Boolean)
    : ["Gather requirements", "Draft solution", "Review & iterate"];
  return items.map((text) => ({ text }));
}

/**
 * "steps" → default flow (undefined-vs-null: undefined = not a steps command, null = default).
 * "steps: a, b, c" → custom items.
 */
function parseStepsSet(text: string): { text: string }[] | null | undefined {
  const m = /^steps\b[:\-\s]*(.*)$/i.exec(text.trim());
  if (!m) return undefined;
  const body = m[1].trim();
  if (!body) return null;
  return body.split(/[,;]|\n/).map((s) => s.trim()).filter(Boolean).map((text) => ({ text }));
}

/** "done <n>" or "<n> done" (n = number or full name). Null otherwise. */
function parseTick(text: string): string | null {
  const t = text.trim();
  let m = /^done\s+(.+)$/i.exec(t);
  if (m) return m[1].trim();
  m = /^(.+?)\s+done$/i.exec(t);
  if (m) return m[1].trim();
  return null;
}

/** Default guided flow: Collect Assets (kind:collect) → Review → Submit Reviews. */
function defaultSteps(): { text: string; description?: string; kind?: "collect"; ui?: StepUI }[] {
  return [
    {
      text: "Collect Assets",
      description: "Find and pin agents, datasets, and other assets",
      kind: "collect",
      ui: {
        kind: "suggest",
        title: "Collect assets",
        description: "Find and pin the assets to review — or just search in chat.",
        options: [
          { label: "Search agents", description: "Browse and pin agents", href: "/marketplace/agents" },
          { label: "Search datasets", description: "Browse and pin datasets", href: "/marketplace/datasets" },
        ],
      },
    },
    { text: "Review" },
    { text: "Submit Reviews", ui: { kind: "submit" } },
  ];
}
