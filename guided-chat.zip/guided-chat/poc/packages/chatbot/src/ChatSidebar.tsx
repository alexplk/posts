import { AssistantRuntimeProvider } from "@assistant-ui/react";
import { usePersistentRuntime } from "./usePersistentRuntime";
import { MyThread } from "./MyThread";
import { SearchToolUI } from "./SearchToolUI";
import { UpdateTaskListTool, UpdateTaskListToolUI } from "./tools/updateTaskList";
import { UpdateStepListTool, UpdateStepListToolUI } from "./tools/updateStepList";
import { UpdateArtifactsTool, UpdateArtifactsToolUI } from "./tools/updateArtifacts";
import { ClearUsedPinsTool, ClearUsedPinsToolUI } from "./tools/clearUsedPins";
import { ConversationList } from "./ConversationList";
import { goHome, newConversation, useConversations, useCurrentConversation } from "./conversations";

/**
 * The always-open chat surface. Shows the conversation list ("home") when no conversation
 * is selected, otherwise the active thread. Chat/workspace persist per conversation.
 */
export function ChatSidebar({ variant = "sidebar" }: { variant?: "sidebar" | "fullscreen" }) {
  const { currentId } = useConversations();
  return (
    <div className={`cb-shell cb-shell--${variant}`}>
      {currentId ? <ActiveChat key={currentId} conversationId={currentId} /> : <ConversationList />}
    </div>
  );
}

function ActiveChat({ conversationId }: { conversationId: string }) {
  const runtime = usePersistentRuntime(conversationId);
  const conv = useCurrentConversation();
  return (
    <AssistantRuntimeProvider runtime={runtime}>
      {/* Register frontend tools + their inline UIs. */}
      <SearchToolUI />
      <UpdateTaskListTool />
      <UpdateTaskListToolUI />
      <UpdateStepListTool />
      <UpdateStepListToolUI />
      <UpdateArtifactsTool />
      <UpdateArtifactsToolUI />
      <ClearUsedPinsTool />
      <ClearUsedPinsToolUI />

      <div className="cb-topbar">
        <button className="cb-btn cb-btn--ghost" onClick={goHome} title="All conversations">
          ← Home
        </button>
        <span className="cb-title">{conv?.title || "New conversation"}</span>
        <button className="cb-btn cb-btn--ghost" onClick={() => newConversation()} title="New conversation">
          + New
        </button>
      </div>
      <MyThread />
    </AssistantRuntimeProvider>
  );
}
