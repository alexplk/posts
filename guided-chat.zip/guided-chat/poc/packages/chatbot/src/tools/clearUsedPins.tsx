import { makeAssistantTool, makeAssistantToolUI } from "@assistant-ui/react";
import { z } from "zod";
import { clearUsedPins } from "@poc/collections-fragments";

/**
 * Frontend tool: consume the current pins (they move to the pins history for undo). Called
 * after a chat interaction uses the pinned assets, so the selection is "use and forget".
 */
export const ClearUsedPinsTool = makeAssistantTool({
  toolName: "clearUsedPins",
  parameters: z.object({}),
  execute: async () => {
    clearUsedPins();
    return {};
  },
});

export const ClearUsedPinsToolUI = makeAssistantToolUI<Record<string, never>, unknown>({
  toolName: "clearUsedPins",
  render: () => <div className="cb-toolnote">✓ Cleared used pins (in Recent)</div>,
});
