import { makeAssistantTool, makeAssistantToolUI } from "@assistant-ui/react";
import { z } from "zod";
import { setArtifacts } from "../conversations";

/**
 * Frontend tool: write the conversation's workspace.artifacts (the Artifacts panel).
 * Items are assets (same type+id as pins/collections) or text blocks. Files/docs later.
 */
const parameters = z.object({
  artifacts: z.array(
    z.union([
      z.object({ kind: z.literal("asset"), type: z.string(), id: z.string() }),
      z.object({ kind: z.literal("text"), text: z.string() }),
    ]),
  ),
});

export const UpdateArtifactsTool = makeAssistantTool({
  toolName: "updateArtifacts",
  parameters,
  execute: async ({ artifacts }) => {
    setArtifacts(
      artifacts.map((a) =>
        a.kind === "asset"
          ? { kind: "asset" as const, ref: { type: a.type as never, id: a.id } }
          : { kind: "text" as const, text: a.text },
      ),
    );
    return { count: artifacts.length };
  },
});

export const UpdateArtifactsToolUI = makeAssistantToolUI<
  { artifacts: unknown[] },
  { count: number }
>({
  toolName: "updateArtifacts",
  render: ({ args }) => {
    const n = args?.artifacts?.length ?? 0;
    return <div className="cb-toolnote">✓ Collected {n} artifact{n === 1 ? "" : "s"}</div>;
  },
});
