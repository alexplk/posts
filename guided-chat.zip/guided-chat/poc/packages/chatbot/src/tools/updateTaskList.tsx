import { makeAssistantTool, makeAssistantToolUI } from "@assistant-ui/react";
import { z } from "zod";
import { setChecklist } from "../conversations";

/**
 * A real FRONTEND tool. `execute` runs in the browser when the tool is called: it writes
 * the checklist into the conversation's workspace, which TaskListPanel renders beside pins. Returns a
 * small result the thread can show.
 */
const parameters = z.object({
  tasks: z.array(z.object({ text: z.string(), done: z.boolean().optional() })),
});

export const UpdateTaskListTool = makeAssistantTool({
  toolName: "updateTaskList",
  parameters,
  execute: async ({ tasks }) => {
    setChecklist(tasks);
    return { count: tasks.length };
  },
});

/** Compact inline confirmation in the thread (the real UI lives in the side panel). */
export const UpdateTaskListToolUI = makeAssistantToolUI<{ tasks: { text: string }[] }, { count: number }>({
  toolName: "updateTaskList",
  render: ({ args }) => {
    const n = args?.tasks?.length ?? 0;
    return <div className="cb-toolnote">✓ Updated checklist — {n} item{n === 1 ? "" : "s"}</div>;
  },
});
