import { makeAssistantTool, makeAssistantToolUI } from "@assistant-ui/react";
import { z } from "zod";
import { setSteps } from "../conversations";

/** Frontend tool: write the conversation's workspace.steps (the stepper panel). */
const parameters = z.object({
  steps: z.array(z.object({ text: z.string(), done: z.boolean().optional() })),
});

export const UpdateStepListTool = makeAssistantTool({
  toolName: "updateStepList",
  parameters,
  execute: async ({ steps }) => {
    setSteps(steps);
    return { count: steps.length };
  },
});

export const UpdateStepListToolUI = makeAssistantToolUI<{ steps: { text: string }[] }, { count: number }>({
  toolName: "updateStepList",
  render: ({ args }) => {
    const n = args?.steps?.length ?? 0;
    return <div className="cb-toolnote">✓ Steps set — {n} step{n === 1 ? "" : "s"}</div>;
  },
});
