import { useSteps } from "./conversations";
import { showStepUI } from "./stepUI";

/**
 * Read-only stepper (workspace.steps). Circle nodes are NOT user-clickable (advance via the
 * "step" command). Steps that have a linked UI have a clickable LABEL to reopen it.
 * Blue circle: outline when incomplete, filled + white check when done. The connector to
 * the next node is blue only when BOTH ends are done — out-of-order completion forms
 * connected blue clumps against a gray rail.
 */
export function StepperPanel() {
  const steps = useSteps();
  if (steps.length === 0) return null;

  const done = steps.filter((s) => s.done).length;
  return (
    <div className="stp-wrap">
      <div className="cb-tasks__head">
        <h3>Steps</h3>
        <span className="col-pins__count">{done}/{steps.length}</span>
      </div>
      <ol className="stp">
        {steps.map((s, i) => {
          const segComplete = s.done && i < steps.length - 1 && steps[i + 1].done;
          return (
            <li className="stp__row" key={s.id}>
              <div className="stp__rail">
                <span className={s.done ? "stp__dot stp__dot--done" : "stp__dot"} aria-hidden>
                  {s.done && <span className="stp__check">✓</span>}
                </span>
                {i < steps.length - 1 && (
                  <span className={segComplete ? "stp__seg stp__seg--done" : "stp__seg"} />
                )}
              </div>
              <div
                className={
                  (s.done ? "stp__label stp__label--done" : "stp__label") + (s.ui ? " stp__label--ui" : "")
                }
                onClick={s.ui ? () => showStepUI(s.id) : undefined}
                title={s.ui ? "Open this step" : undefined}
              >
                <div className="stp__title">{s.text}</div>
                {s.description && <div className="stp__desc">{s.description}</div>}
                {s.status && <div className="stp__status">{s.status}</div>}
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
