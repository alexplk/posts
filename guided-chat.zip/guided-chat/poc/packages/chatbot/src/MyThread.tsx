import { ComposerPrimitive, MessagePrimitive, ThreadPrimitive } from "@assistant-ui/react";
import { StepUISlot } from "./StepUISlot";

/**
 * A lightly-styled thread built from assistant-ui primitives so it isn't raw/unstyled.
 * Kept intentionally minimal (bubbles + a composer row); swap for the product's design
 * system later. Registered tool UIs (e.g. SearchToolUI) render inside message content.
 */
export function MyThread() {
  return (
    <ThreadPrimitive.Root className="cb-thread">
      <ThreadPrimitive.Viewport className="cb-thread__viewport">
        <ThreadPrimitive.Empty>
          <div className="cb-thread__empty">
            Ask me to find agents, datasets, or skills — e.g. “find KYC agents”.
          </div>
        </ThreadPrimitive.Empty>

        <ThreadPrimitive.Messages
          components={{ UserMessage, AssistantMessage }}
        />
      </ThreadPrimitive.Viewport>

      <StepUISlot />

      <ComposerPrimitive.Root className="cb-composer">
        <ComposerPrimitive.Input className="cb-composer__input" placeholder="Message the assistant…" />
        <ComposerPrimitive.Send className="cb-composer__send">Send</ComposerPrimitive.Send>
      </ComposerPrimitive.Root>
    </ThreadPrimitive.Root>
  );
}

function UserMessage() {
  return (
    <MessagePrimitive.Root className="cb-msg cb-msg--user">
      <div className="cb-bubble cb-bubble--user">
        <MessagePrimitive.Content />
      </div>
    </MessagePrimitive.Root>
  );
}

function AssistantMessage() {
  return (
    <MessagePrimitive.Root className="cb-msg cb-msg--assistant">
      <div className="cb-bubble cb-bubble--assistant">
        <MessagePrimitive.Content />
      </div>
    </MessagePrimitive.Root>
  );
}
