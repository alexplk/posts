import { useEffect, useState } from "react";
import type { Step, StepUI } from "./conversations";
import { markStepDone, markStepUiShown, submitReview, useSteps } from "./conversations";
import { clearStepUI, showStepUI, useShownStepUI } from "./stepUI";

/**
 * Renders the inline UI linked to a step, above the composer. A step's UI auto-shows the
 * first time it's the current pending step (then never again — persisted uiShown), is
 * dismissed when the user types, and reopens when the step is clicked in the stepper.
 */
export function StepUISlot() {
  const steps = useSteps();
  const shown = useShownStepUI();
  const current = steps.find((s) => !s.done);

  // Auto-show the current step's UI the first time (once).
  useEffect(() => {
    if (current?.ui && !current.uiShown) {
      markStepUiShown(current.id);
      showStepUI(current.id);
    }
  }, [current?.id, current?.ui, current?.uiShown]);

  const step = shown ? steps.find((s) => s.id === shown.id) : undefined;
  if (!step?.ui) return null;
  return <div className="stepui">{renderUI(step, step.ui)}</div>;
}

function renderUI(step: Step, ui: StepUI) {
  switch (ui.kind) {
    case "suggest":
      return <SuggestMenu ui={ui} />;
    case "reviewForm":
      return <ReviewForm step={step} />;
    case "submit":
      return <SubmitForm step={step} />;
  }
}

function SuggestMenu({ ui }: { ui: Extract<StepUI, { kind: "suggest" }> }) {
  return (
    <div className="uinput">
      <div className="uinput__title">{ui.title}</div>
      {ui.description && <div className="uinput__desc">{ui.description}</div>}
      <div className="uinput__opts">
        {ui.options.map((o, i) =>
          o.href ? (
            <a key={i} className="uinput__opt" href={o.href}>
              <span className="uinput__opt-label">{o.label}</span>
              {o.description && <span className="uinput__opt-desc">{o.description}</span>}
            </a>
          ) : (
            <button key={i} className="uinput__opt">
              <span className="uinput__opt-label">{o.label}</span>
            </button>
          ),
        )}
      </div>
    </div>
  );
}

const TAGS = ["recommend", "modify"];

function ReviewForm({ step }: { step: Step }) {
  const [note, setNote] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const toggle = (t: string) => setTags((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]));
  return (
    <div className="uform">
      <div className="uform__title">{step.text}</div>
      <textarea
        className="uform__text"
        rows={3}
        value={note}
        placeholder="Notes…"
        onChange={(e) => setNote(e.target.value)}
      />
      <div className="uform__tags">
        {TAGS.map((t) => (
          <button
            key={t}
            className={tags.includes(t) ? "uform__tag uform__tag--on" : "uform__tag"}
            aria-pressed={tags.includes(t)}
            onClick={() => toggle(t)}
          >
            {t}
          </button>
        ))}
      </div>
      <button
        className="uform__submit"
        onClick={() => {
          submitReview(step.text, note, tags);
          clearStepUI();
        }}
      >
        Submit
      </button>
    </div>
  );
}

function SubmitForm({ step }: { step: Step }) {
  return (
    <div className="uform">
      <div className="uform__title">{step.text}</div>
      <p className="uform__note">This review is ready to be submitted.</p>
      <button
        className="uform__submit"
        onClick={() => {
          markStepDone(step.id);
          clearStepUI();
        }}
      >
        Submit
      </button>
    </div>
  );
}
