import { deleteConversation, newConversation, selectConversation, useConversations } from "./conversations";

/** The "home" view of the chat panel: saved conversations, with open / delete / new. */
export function ConversationList() {
  const { list } = useConversations();
  return (
    <div className="cb-convos">
      <div className="cb-convos__head">
        <h3>Conversations</h3>
        <button className="cb-btn" onClick={() => newConversation()}>+ New</button>
      </div>
      {list.length === 0 && <p className="cb-convos__empty">No conversations yet.</p>}
      <ul className="cb-convos__list">
        {list.map((c) => (
          <li key={c.id} className="cb-convo">
            <button className="cb-convo__open" onClick={() => selectConversation(c.id)}>
              <span className="cb-convo__title">{c.title || "New conversation"}</span>
              <span className="cb-convo__meta">
                {c.messages.length} msg{c.messages.length === 1 ? "" : "s"}
              </span>
            </button>
            <button
              className="cb-convo__del"
              title="Delete conversation"
              aria-label="Delete conversation"
              onClick={() => deleteConversation(c.id)}
            >
              ✕
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
