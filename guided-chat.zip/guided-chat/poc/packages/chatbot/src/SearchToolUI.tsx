import type { SearchResult } from "@poc/core";
import { AssetTile, PinButton } from "@poc/collections-fragments";
import { makeAssistantToolUI } from "@assistant-ui/react";

type SearchArgs = { query: string; types?: string[] };
type SearchOut = { results: SearchResult[] };

/**
 * Renders the `search` tool result as a real search-style list: compact rows,
 * marketplace fragments, pin action per row. This is the "search UX inside chat" bet.
 */
export const SearchToolUI = makeAssistantToolUI<SearchArgs, SearchOut>({
  toolName: "search",
  render: ({ args, result, status }) => {
    if (status.type === "running") return <div className="cb-search__status">Searching “{args.query}”…</div>;
    const results = result?.results ?? [];
    return (
      <div className="cb-search">
        <div className="cb-search__head">
          {results.length} result{results.length === 1 ? "" : "s"} for “{args.query}”
        </div>
        {/* TODO: facet filters (by asset type) render here — feature 1 next step */}
        <ul className="mp-list mp-compact">
          {results.map((r) => (
            <li key={`${r.ref.type}:${r.ref.id}`}>
              <AssetTile {...r.ref} actions={<PinButton target={r.ref} />} />
            </li>
          ))}
        </ul>
      </div>
    );
  },
});
