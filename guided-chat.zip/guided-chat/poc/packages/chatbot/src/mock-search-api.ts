import { mockSearch } from "@poc/core";
import type { AssetTypeId, SearchResult } from "@poc/core";
import { ASSET_TYPES } from "@poc/collections-fragments";

/**
 * Browser-side wrapper around the search API. In the real POC this is where you'd call
 * the existing UI search endpoint. Keep the args/return shape stable — this is the
 * contract we'll hand to the agent devs to mirror as an MCP/agent tool.
 */
export interface SearchArgs {
  query: string;
  types?: AssetTypeId[];
}

export async function searchApi(args: SearchArgs): Promise<{ results: SearchResult[] }> {
  const results = await mockSearch(args);
  return { results };
}

// --- stub intent parsing ---------------------------------------------------

// keyword → type, from the asset-type labels ("agent|agents"). Longest first so
// multi-word / plural forms win (e.g. "data products" before a bare word).
const KEYWORDS = ASSET_TYPES.flatMap((t) => {
  const [one, many] = t.label.split("|");
  return [
    { kw: many.toLowerCase(), type: t.type },
    { kw: one.toLowerCase(), type: t.type },
  ];
}).sort((a, b) => b.kw.length - a.kw.length);

const FIND_PREFIX = /^(find|search|show|list|look\s*up)\s+/i;

/**
 * Parse a stub query:
 *  - optional leading "find|search|…" is stripped
 *  - if what remains ends with an asset-type keyword (agent/agents, dataset/datasets, …),
 *    restrict to that type and substring-search the text before it
 *  - otherwise substring-search everything
 * Examples: "find kyc agents" → {query:"kyc", types:[agent]}; "kyc" → {query:"kyc"}.
 */
export function parseSearch(input: string): SearchArgs {
  const text = input.trim().replace(FIND_PREFIX, "").trim();
  const lower = text.toLowerCase();

  for (const { kw, type } of KEYWORDS) {
    if (lower === kw || lower.endsWith(" " + kw)) {
      const query = text.slice(0, text.length - kw.length).trim();
      return { query, types: [type] };
    }
  }
  return { query: text };
}
