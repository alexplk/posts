import { useSyncExternalStore } from "react";
import type { ThreadMessageLike } from "@assistant-ui/react";
import type { AssetRef } from "@poc/core";
import { getAsset } from "@poc/core";
import { assetLabel, getCollection, setActivePanel } from "@poc/collections-fragments";

/**
 * Conversation store — the hub for saved chats. Each conversation owns its thread
 * (messages) and its **workspace** (checklist, steps, artifacts). Persisted to
 * localStorage. Pins are NOT here — they're user-global (collections-fragments).
 */
export interface Task {
  id: string;
  text: string;
  done: boolean;
}

export type StepUI =
  | { kind: "suggest"; title: string; description?: string; options: { label: string; description?: string; href?: string }[] }
  | { kind: "reviewForm" }
  | { kind: "submit" };

export interface Step {
  id: string;
  text: string;
  description?: string;
  /** small bold line under the description, e.g. "2 agents, 1 skill" */
  status?: string;
  done: boolean;
  /** marks special steps ("collect" drives the collect→explode flow) */
  kind?: "collect";
  /** inline UI linked to this step (form/menu), shown when it first becomes current */
  ui?: StepUI;
  /** true once the linked UI has auto-shown — so it never auto-pops again (incl. reload) */
  uiShown?: boolean;
}

export type Artifact =
  | { id: string; kind: "asset"; ref: AssetRef }
  | { id: string; kind: "text"; text: string };

export interface Workspace {
  checklist: Task[];
  steps: Step[];
  artifacts: Artifact[];
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  messages: ThreadMessageLike[];
  workspace: Workspace;
}

interface State {
  list: Conversation[];
  currentId: string | null;
}

const KEY = "poc.conversations.v1";
const EMPTY_TASKS: Task[] = [];
const EMPTY_STEPS: Step[] = [];
const EMPTY_ARTIFACTS: Artifact[] = [];
const emptyWorkspace = (): Workspace => ({ checklist: [], steps: [], artifacts: [] });
const genId = () =>
  typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : String(Date.now()) + Math.random().toString(16).slice(2);

let state: State = hydrate();
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());
const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};

function hydrate(): State {
  if (typeof localStorage === "undefined") return { list: [], currentId: null };
  try {
    const s = JSON.parse(localStorage.getItem(KEY) ?? "{}");
    return { list: s.list ?? [], currentId: s.currentId ?? null };
  } catch {
    return { list: [], currentId: null };
  }
}

function set(next: State) {
  state = next;
  if (typeof localStorage !== "undefined") {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* ignore quota */
    }
  }
  emit();
}

const current = (): Conversation | null => state.list.find((c) => c.id === state.currentId) ?? null;

function updateCurrent(fn: (c: Conversation) => Conversation) {
  if (!state.currentId) return;
  set({ ...state, list: state.list.map((c) => (c.id === state.currentId ? fn(c) : c)) });
}

// --- navigation / lifecycle ---

export function newConversation(): string {
  const conv: Conversation = {
    id: genId(),
    title: "",
    createdAt: Date.now(),
    messages: [],
    workspace: emptyWorkspace(),
  };
  set({ list: [conv, ...state.list], currentId: conv.id });
  return conv.id;
}

export function selectConversation(id: string) {
  set({ ...state, currentId: id });
}

export function goHome() {
  set({ ...state, currentId: null });
}

export function deleteConversation(id: string) {
  set({
    list: state.list.filter((c) => c.id !== id),
    currentId: state.currentId === id ? null : state.currentId,
  });
}

// --- thread persistence ---

export function loadMessages(id: string): ThreadMessageLike[] {
  return state.list.find((c) => c.id === id)?.messages ?? [];
}

export function saveMessages(id: string, messages: readonly { role: string; content: unknown }[]) {
  const slim = messages.map((m) => ({ role: m.role, content: m.content })) as ThreadMessageLike[];
  set({
    ...state,
    list: state.list.map((c) =>
      c.id === id ? { ...c, messages: slim, title: c.title || deriveTitle(slim) } : c,
    ),
  });
}

function deriveTitle(messages: ThreadMessageLike[]): string {
  const first = messages.find((m) => m.role === "user");
  const parts = (first?.content ?? []) as { type: string; text?: string }[];
  const text = Array.isArray(parts)
    ? parts.map((p) => (p.type === "text" ? p.text : "")).join(" ").trim()
    : "";
  return text.slice(0, 40);
}

// --- checklist ---

export function setChecklist(items: { text: string; done?: boolean }[]) {
  updateCurrent((c) => ({
    ...c,
    workspace: {
      ...c.workspace,
      checklist: items.map((t, i) => ({ id: String(i + 1), text: t.text, done: !!t.done })),
    },
  }));
  setActivePanel("tasks");
}

export function toggleChecklistItem(taskId: string) {
  updateCurrent((c) => ({
    ...c,
    workspace: {
      ...c.workspace,
      checklist: c.workspace.checklist.map((t) => (t.id === taskId ? { ...t, done: !t.done } : t)),
    },
  }));
}

// --- steps ---

type StepInput = {
  text: string;
  description?: string;
  status?: string;
  done?: boolean;
  kind?: "collect";
  ui?: StepUI;
};

export function setSteps(items: StepInput[]) {
  updateCurrent((c) => ({
    ...c,
    workspace: {
      ...c.workspace,
      steps: items.map((s, i) => ({
        id: String(i + 1),
        text: s.text,
        description: s.description,
        status: s.status,
        done: !!s.done,
        kind: s.kind,
        ui: s.ui,
      })),
    },
  }));
  setActivePanel("steps");
}

/** Mark a step's linked UI as auto-shown (so it won't auto-pop again). */
export function markStepUiShown(stepId: string) {
  updateCurrent((c) => ({
    ...c,
    workspace: {
      ...c.workspace,
      steps: c.workspace.steps.map((s) => (s.id === stepId ? { ...s, uiShown: true } : s)),
    },
  }));
}

/** Mark a step done by id (used by the Submit form). */
export function markStepDone(stepId: string) {
  updateCurrent((c) => ({
    ...c,
    workspace: {
      ...c.workspace,
      steps: c.workspace.steps.map((s) => (s.id === stepId ? { ...s, done: true } : s)),
    },
  }));
  setActivePanel("steps");
}

/** Mark step at index done. If it's the "collect" step, run the collect→explode flow. */
export function completeStepAt(index: number) {
  const isCollect = (current()?.workspace.steps ?? [])[index]?.kind === "collect";
  updateCurrent((c) => {
    const steps = c.workspace.steps ?? [];
    if (index < 0 || index >= steps.length) return c;
    if (steps[index].kind === "collect") {
      return { ...c, workspace: applyCollect(c.workspace, index) };
    }
    return {
      ...c,
      workspace: { ...c.workspace, steps: steps.map((s, i) => (i === index ? { ...s, done: true } : s)) },
    };
  });
  // Completing "Collect Assets" produces artifacts — bring that tab forward.
  if (isCollect) setActivePanel("artifacts");
}

/** Complete the first not-done step (the "step" / "done" command). */
export function advanceStep() {
  const c = current();
  if (!c) return;
  const idx = (c.workspace.steps ?? []).findIndex((s) => !s.done);
  if (idx >= 0) completeStepAt(idx);
}

/**
 * "done <n>" / "<n> done": tick one item by 1-indexed number or exact displayed name.
 * Targets steps first (guided flow), then the checklist.
 */
export function tickByToken(token: string) {
  const c = current();
  if (!c) return;
  const t = token.trim();
  const num = /^\d+$/.test(t) ? parseInt(t, 10) : null;
  const steps = c.workspace.steps ?? [];
  const checklist = c.workspace.checklist ?? [];

  const sIdx = num != null ? num - 1 : steps.findIndex((s) => s.text.toLowerCase() === t.toLowerCase());
  if (sIdx >= 0 && sIdx < steps.length) {
    completeStepAt(sIdx);
    return;
  }
  const cIdx = num != null ? num - 1 : checklist.findIndex((x) => x.text.toLowerCase() === t.toLowerCase());
  if (cIdx >= 0 && cIdx < checklist.length) {
    updateCurrent((cc) => ({
      ...cc,
      workspace: {
        ...cc.workspace,
        checklist: cc.workspace.checklist.map((x, i) => (i === cIdx ? { ...x, done: true } : x)),
      },
    }));
  }
}

/** Completing "Collect Assets": stamp status from pins, add them to artifacts, explode Review. */
function applyCollect(ws: Workspace, collectIdx: number): Workspace {
  const pins = getCollection("pins")?.items ?? [];
  let steps = ws.steps.slice();
  steps[collectIdx] = {
    ...steps[collectIdx],
    done: true,
    status: pins.length ? summarizePins(pins) : "No assets",
  };

  if (pins.length) {
    const reviewIdx = steps.findIndex((s) => s.text === "Review" && s.kind !== "collect");
    if (reviewIdx >= 0) {
      const exploded: Step[] = pins.map((ref) => ({
        id: "",
        text: `Review ${getAsset(ref)?.name ?? ref.id}`,
        done: false,
        ui: { kind: "reviewForm" },
      }));
      steps = [...steps.slice(0, reviewIdx), ...exploded, ...steps.slice(reviewIdx + 1)];
    }
  }
  steps = steps.map((s, i) => ({ ...s, id: String(i + 1) }));

  const fromPins: Artifact[] = pins.map((ref) => ({ id: `ast:${ref.type}:${ref.id}`, kind: "asset", ref }));
  return { ...ws, steps, artifacts: mergeArtifacts(ws.artifacts ?? [], fromPins) };
}

function summarizePins(pins: AssetRef[]): string {
  const counts: Record<string, number> = {};
  for (const p of pins) counts[p.type] = (counts[p.type] ?? 0) + 1;
  return Object.entries(counts)
    .map(([type, n]) => `${n} ${assetLabel(type as AssetRef["type"], n > 1)}`)
    .join(", ");
}

// --- artifacts ---

export function setArtifacts(items: ({ kind: "asset"; ref: AssetRef } | { kind: "text"; text: string })[]) {
  updateCurrent((c) => ({
    ...c,
    workspace: { ...c.workspace, artifacts: items.map(withArtifactId) },
  }));
  setActivePanel("artifacts");
}

function withArtifactId(a: { kind: "asset"; ref: AssetRef } | { kind: "text"; text: string }, i: number): Artifact {
  return a.kind === "asset" ? { id: `ast:${a.ref.type}:${a.ref.id}`, kind: "asset", ref: a.ref } : { id: `txt:${i}`, kind: "text", text: a.text };
}

function mergeArtifacts(existing: Artifact[], incoming: Artifact[]): Artifact[] {
  const seen = new Set(existing.map((a) => a.id));
  return [...existing, ...incoming.filter((a) => !seen.has(a.id))];
}

/** Submit a Review form: mark the matching step done, stamp tags, drop a note artifact. */
export function submitReview(stepText: string, note: string, tags: string[]) {
  updateCurrent((c) => {
    const steps = c.workspace.steps.map((s) =>
      s.text === stepText ? { ...s, done: true, status: tags.length ? tags.join(", ") : s.status } : s,
    );
    const noteText = `${stepText}${tags.length ? ` [${tags.join(", ")}]` : ""}${note ? `: ${note}` : ""}`;
    const artifacts = mergeArtifacts(c.workspace.artifacts, [
      { id: `rev:${stepText}`, kind: "text", text: noteText },
    ]);
    return { ...c, workspace: { ...c.workspace, steps, artifacts } };
  });
  setActivePanel("steps");
}

// --- getters (non-hook, for the runtime) ---

export const getSteps = (): Step[] => current()?.workspace.steps ?? [];
export const getArtifacts = (): Artifact[] => current()?.workspace.artifacts ?? [];

// --- hooks ---

export const useConversations = () => useSyncExternalStore(subscribe, () => state);
export function useCurrentConversation(): Conversation | null {
  const s = useConversations();
  return s.list.find((c) => c.id === s.currentId) ?? null;
}
export const useChecklist = (): Task[] => useCurrentConversation()?.workspace.checklist ?? EMPTY_TASKS;
export const useSteps = (): Step[] => useCurrentConversation()?.workspace.steps ?? EMPTY_STEPS;
export const useArtifacts = (): Artifact[] => useCurrentConversation()?.workspace.artifacts ?? EMPTY_ARTIFACTS;
