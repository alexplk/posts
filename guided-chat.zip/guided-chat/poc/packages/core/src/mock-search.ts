import { allAssets } from "./mock-data";
import type { AssetTypeId, SearchResult } from "./types";

export interface SearchQuery {
  query: string;
  /** optional facet: restrict to these asset types */
  types?: AssetTypeId[];
}

/**
 * Mock of the (existing, UI-side) search API. Async + a little latency so the
 * assistant tool integration looks realistic. Swap this for the real API / MCP tool
 * later — keep the SearchResult shape stable so the agent devs can target it.
 */
export async function mockSearch({ query, types }: SearchQuery): Promise<SearchResult[]> {
  await delay(250);
  const q = query.trim().toLowerCase();
  return allAssets()
    .filter((a) => !types || types.includes(a.type))
    .filter((a) => !q || `${a.name} ${describe(a)}`.toLowerCase().includes(q))
    .map((a) => ({
      ref: { type: a.type, id: a.id },
      name: a.name,
      snippet: describe(a),
    }));
}

function describe(a: { [k: string]: unknown }): string {
  return (a.capability ?? a.format ?? a.category ?? "") as string;
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
