import type { Asset, AssetRef, AssetTypeId } from "./types";

/** Tiny mock registry. Very simple models: id, name, one relevant extra prop. */
// Overlapping words across types (kyc, trade, fraud, reconciliation) so substring
// searches return cross-asset results.
const AGENTS: Asset[] = [
  { type: "assets/agent", id: "a1", name: "Invoice Triage Agent", capability: "routes invoices to approvers" },
  { type: "assets/agent", id: "a2", name: "KYC Assistant", capability: "gathers and checks KYC docs" },
  { type: "assets/agent", id: "a3", name: "Report Summarizer", capability: "summarizes long filings" },
  { type: "assets/agent", id: "a4", name: "Trade Reconciliation Agent", capability: "matches trade breaks" },
  { type: "assets/agent", id: "a5", name: "Fraud Watch Agent", capability: "flags suspicious fraud patterns" },
  { type: "assets/agent", id: "a6", name: "Client Onboarding Agent", capability: "runs daily client onboarding" },
];

const DATASETS: Asset[] = [
  { type: "assets/dataset", id: "d1", name: "Trade Tickets 2024", format: "parquet" },
  { type: "assets/dataset", id: "d2", name: "Client Reference Data", format: "delta" },
  { type: "assets/dataset", id: "d3", name: "FX Rates Daily", format: "csv" },
  { type: "assets/dataset", id: "d4", name: "KYC Document Store", format: "delta" },
  { type: "assets/dataset", id: "d5", name: "Fraud Alerts History", format: "parquet" },
];

const SKILLS: Asset[] = [
  { type: "assets/skill", id: "s1", name: "Extract Entities", category: "nlp" },
  { type: "assets/skill", id: "s2", name: "Reconcile Ledgers", category: "finance" },
  { type: "assets/skill", id: "s3", name: "Redact PII", category: "compliance" },
  { type: "assets/skill", id: "s4", name: "KYC Document Check", category: "compliance" },
  { type: "assets/skill", id: "s5", name: "Trade Break Detection", category: "finance" },
  { type: "assets/skill", id: "s6", name: "Client Daily Digest", category: "reporting" },
];

const STORE: Partial<Record<AssetTypeId, Asset[]>> = {
  "assets/agent": AGENTS,
  "assets/dataset": DATASETS,
  "assets/skill": SKILLS,
  // model / tool / data-product intentionally unpopulated — exercises fallbacks.
};

export function listAssets(type: AssetTypeId): Asset[] {
  return STORE[type] ?? [];
}

export function allAssets(): Asset[] {
  return Object.values(STORE).flat();
}

export function getAsset(ref: AssetRef): Asset | undefined {
  return (STORE[ref.type] ?? []).find((a) => a.id === ref.id);
}
