/** Canonical asset type ids. Mirrors the "assets/<kind>" namespace used in the registry. */
export type AssetTypeId =
  | "assets/agent"
  | "assets/model"
  | "assets/skill"
  | "assets/tool"
  | "assets/dataset"
  | "assets/data-product";

/** One entry per available asset type. `label` is "singular|plural". */
export interface AssetTypeDef {
  type: AssetTypeId;
  label: `${string}|${string}`;
}

/** A pointer to an asset — the unit collections/pins/fragments pass around. */
export interface AssetRef {
  type: AssetTypeId;
  id: string;
}

export interface BaseAsset extends AssetRef {
  name: string;
}

export interface Agent extends BaseAsset {
  type: "assets/agent";
  /** one-line what-it-does */
  capability: string;
}

export interface Dataset extends BaseAsset {
  type: "assets/dataset";
  format: string; // e.g. "parquet"
}

export interface Skill extends BaseAsset {
  type: "assets/skill";
  category: string; // e.g. "finance"
}

/** Full asset union. Types without a richer model fall back to BaseAsset. */
export type Asset = Agent | Dataset | Skill | BaseAsset;

export interface SearchResult {
  ref: AssetRef;
  name: string;
  /** short reason/context for the match — for the compact list row */
  snippet: string;
}
