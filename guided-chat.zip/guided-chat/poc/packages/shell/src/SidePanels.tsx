import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { useActivePanel } from "@poc/collections-fragments";

export interface PanelDef {
  id: string;
  label: string;
  /** whether this panel currently has content to show */
  present: boolean;
  render: () => ReactNode;
}

/**
 * The stack of panels above the chat (pins, steps, artifacts, checklist).
 *  - 0 present → nothing
 *  - 1 present → shown plainly
 *  - 2+ present → tabs
 * Tools can bring a tab forward via setActivePanel (useActivePanel here); the user can
 * still click tabs, and their click wins until the next programmatic activation.
 */
export function SidePanels({ panels }: { panels: PanelDef[] }) {
  const activePanel = useActivePanel();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const visible = panels.filter((p) => p.present);
  const visibleKey = visible.map((p) => p.id).join(",");

  // Follow programmatic activation when the target panel is visible.
  useEffect(() => {
    if (activePanel && visible.some((p) => p.id === activePanel.id)) {
      setSelectedId(activePanel.id);
    }
  }, [activePanel, visibleKey]); // eslint-disable-line react-hooks/exhaustive-deps

  if (visible.length === 0) return null;
  if (visible.length === 1) return <div className="shell__side">{visible[0].render()}</div>;

  const active = visible.find((p) => p.id === selectedId) ?? visible[0];
  return (
    <div className="shell__side">
      <div className="side__tabs" role="tablist">
        {visible.map((p) => (
          <button
            key={p.id}
            role="tab"
            aria-selected={p.id === active.id}
            className={p.id === active.id ? "side__tab side__tab--on" : "side__tab"}
            onClick={() => setSelectedId(p.id)}
          >
            {p.label}
          </button>
        ))}
      </div>
      <div className="side__body">{active.render()}</div>
    </div>
  );
}
