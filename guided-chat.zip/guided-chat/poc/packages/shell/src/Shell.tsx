import type { ReactNode } from "react";
import {
  ArtifactsPanel,
  ChatSidebar,
  StepperPanel,
  TaskListPanel,
  useArtifacts,
  useChecklist,
  useSteps,
} from "@poc/chatbot";
import { PinsScreen, useCollection } from "@poc/collections-fragments";
import { SidePanels } from "./SidePanels";
import type { PanelDef } from "./SidePanels";

/**
 * Shared app shell. Every Portal app renders inside this: brand header, optional left
 * nav, routed/app content, and the assistant **always open** on the right (never
 * fullscreen) so the rest of the app stays visible. Pins sit above the thread because
 * they're the context the chat sees.
 */
export function Shell({
  app,
  nav,
  children,
}: {
  app: string;
  nav?: ReactNode;
  children: ReactNode;
}) {
  const panels = usePanels();
  return (
    <div className="shell">
      <header className="shell__top">
        <strong>Portal</strong>
        <span className="shell__muted">{app} · POC</span>
      </header>
      <div className="shell__body">
        {nav && <nav className="shell__nav">{nav}</nav>}
        <main className="shell__main">{children}</main>
        <aside className="shell__chat">
          <SidePanels panels={panels} />
          <div className="shell__thread">
            <ChatSidebar variant="fullscreen" />
          </div>
        </aside>
      </div>
    </div>
  );
}

/**
 * Panels shown above the chat. Pins is the always-present baseline; others appear when
 * they have content. Add future panels here — SidePanels handles the single-vs-tabs layout.
 */
function usePanels(): PanelDef[] {
  const pins = useCollection("pins");
  const checklist = useChecklist();
  const steps = useSteps();
  const artifacts = useArtifacts();
  return [
    {
      id: "pins",
      label: `Pins${pins.items.length ? ` (${pins.items.length})` : ""}`,
      present: true,
      render: () => <PinsScreen />,
    },
    {
      id: "steps",
      label: `Steps${steps.length ? ` (${steps.filter((s) => s.done).length}/${steps.length})` : ""}`,
      present: steps.length > 0,
      render: () => <StepperPanel />,
    },
    {
      id: "artifacts",
      label: `Artifacts${artifacts.length ? ` (${artifacts.length})` : ""}`,
      present: artifacts.length > 0,
      render: () => <ArtifactsPanel />,
    },
    {
      id: "tasks",
      label: `Checklist${checklist.length ? ` (${checklist.length})` : ""}`,
      present: checklist.length > 0,
      render: () => <TaskListPanel />,
    },
  ];
}
