import type { AssetRef } from "@poc/core";
import { getCollection } from "./pins/store";

/** Serialize a collection into the compact context payload the agent receives. */
export function pinsContext(): { pins: AssetRef[] } {
  return { pins: getCollection("pins")?.items ?? [] };
}

/** Stable string key for an AssetRef (dedupe, react keys). */
export const refKey = (r: AssetRef) => `${r.type}:${r.id}`;
