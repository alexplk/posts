import type { AssetTypeDef, AssetTypeId } from "@poc/core";

/** The full list of available asset types. Used to drive UI and frontend tools. */
export const ASSET_TYPES: AssetTypeDef[] = [
  { type: "assets/agent", label: "agent|agents" },
  { type: "assets/model", label: "model|models" },
  { type: "assets/skill", label: "skill|skills" },
  { type: "assets/tool", label: "tool|tools" },
  { type: "assets/dataset", label: "dataset|datasets" },
  { type: "assets/data-product", label: "data product|data products" },
];

const BY_TYPE = new Map(ASSET_TYPES.map((t) => [t.type, t]));

export function assetTypeDef(type: AssetTypeId): AssetTypeDef | undefined {
  return BY_TYPE.get(type);
}

export function assetLabel(type: AssetTypeId, plural = false): string {
  const [one, many] = (BY_TYPE.get(type)?.label ?? "asset|assets").split("|");
  return plural ? many : one;
}
