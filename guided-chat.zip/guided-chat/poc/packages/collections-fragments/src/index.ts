// asset types
export { ASSET_TYPES, assetTypeDef, assetLabel } from "./asset-types";

// central registry + the render-anything tile
export { getFragment, hasFragment } from "./registry";
export type { AssetFragment } from "./registry";
export { AssetTile } from "./AssetTile";

// tiles (also usable directly)
export { TileShell } from "./tiles/shared";
export { AgentTile } from "./tiles/agents/AgentTile";
export { AgentList } from "./tiles/agents/AgentList";
export { DatasetTile } from "./tiles/datasets/DatasetTile";
export { DatasetList } from "./tiles/datasets/DatasetList";
export { SkillTile } from "./tiles/skills/SkillTile";
export { SkillList } from "./tiles/skills/SkillList";
export { FallbackTile } from "./tiles/FallbackTile";

// pins / collections (all persistence goes through here)
export { PinButton } from "./pins/PinButton";
export { PinsScreen } from "./pins/PinsScreen";
export {
  useCollection,
  getCollection,
  ensureCollection,
  toggle,
  isIn,
  pin,
  isPinned,
  clearUsedPins,
  restorePin,
  usePinsHistory,
} from "./pins/store";
export type { Collection } from "./pins/store";
export { setActivePanel, useActivePanel } from "./activePanel";
export { pinsContext, refKey } from "./utils";
