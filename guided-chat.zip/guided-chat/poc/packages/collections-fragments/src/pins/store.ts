import type { AssetRef } from "@poc/core";
import { useSyncExternalStore } from "react";
import { setActivePanel } from "../activePanel";

/**
 * One collection mechanism, many scopes. A collection is just a named, ordered set of
 * AssetRefs. Favorites, named/shared collections, and the chat "pins" are all collections
 * with different ids/lifetimes. Persisted to localStorage (swap for real backend later).
 *
 * Pins are a *temporary* selection: chat interactions that use them call clearUsedPins(),
 * which moves them into a history list (kept for easy undo).
 */
export interface Collection {
  id: string;
  name: string;
  scope: "pins" | "favorites" | "named";
  items: AssetRef[];
}

const refKey = (r: AssetRef) => `${r.type}:${r.id}`;
const STORAGE_KEY = "poc.collections.v1";
const HISTORY_KEY = "poc.pins.history.v1";

const DEFAULTS: Collection[] = [
  { id: "pins", name: "Pinned for chat", scope: "pins", items: [] },
  { id: "favorites", name: "Favorites", scope: "favorites", items: [] },
];

const collections = new Map<string, Collection>(DEFAULTS.map((c) => [c.id, c]));
hydrate();

/** Previously-cleared pins, newest first — shown collapsed under the pins panel for undo. */
let pinsHistory: AssetRef[] = hydrateHistory();

const listeners = new Set<() => void>();
function emit() {
  for (const l of listeners) l();
}
function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

// --- persistence -----------------------------------------------------------

function hydrate() {
  if (typeof localStorage === "undefined") return;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw) as Collection[];
    for (const c of saved) collections.set(c.id, c);
  } catch {
    /* ignore corrupt storage */
  }
}

function persist() {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...collections.values()]));
  } catch {
    /* ignore quota/serialization errors */
  }
}

function hydrateHistory(): AssetRef[] {
  if (typeof localStorage === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) ?? "[]") as AssetRef[];
  } catch {
    return [];
  }
}

function persistHistory() {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(pinsHistory));
  } catch {
    /* ignore */
  }
}

// --- api -------------------------------------------------------------------

export function getCollection(id: string): Collection | undefined {
  return collections.get(id);
}

export function ensureCollection(id: string, name = id, scope: Collection["scope"] = "named") {
  if (!collections.has(id)) {
    collections.set(id, { id, name, scope, items: [] });
    persist();
  }
  return collections.get(id)!;
}

export function toggle(collectionId: string, ref: AssetRef) {
  const c = ensureCollection(collectionId);
  const exists = c.items.some((i) => refKey(i) === refKey(ref));
  const items = exists ? c.items.filter((i) => refKey(i) !== refKey(ref)) : [...c.items, ref];
  // Replace the object so useSyncExternalStore's identity check fires.
  collections.set(collectionId, { ...c, items });
  persist();
  // Adding a pin brings the pins panel forward.
  if (!exists && collectionId === "pins") setActivePanel("pins");
  emit();
}

export function isIn(collectionId: string, ref: AssetRef): boolean {
  return !!collections.get(collectionId)?.items.some((i) => refKey(i) === refKey(ref));
}

/**
 * Consume the current pins: empty the active list, pushing them (deduped) to the front of
 * history so the selection is "use and forget" but easy to restore.
 */
export function clearUsedPins() {
  const pins = collections.get("pins");
  const used = pins?.items ?? [];
  if (used.length === 0) return;
  const seen = new Set(pinsHistory.map(refKey));
  pinsHistory = [...used.filter((r) => !seen.has(refKey(r))), ...pinsHistory];
  collections.set("pins", { ...pins!, items: [] });
  persist();
  persistHistory();
  emit();
}

/** Re-pin a history entry (undo a clear). */
export function restorePin(ref: AssetRef) {
  if (!isIn("pins", ref)) toggle("pins", ref);
}

/** React binding — re-renders on any collection change. */
export function useCollection(id: string): Collection {
  return useSyncExternalStore(subscribe, () => ensureCollection(id));
}

export function usePinsHistory(): AssetRef[] {
  return useSyncExternalStore(subscribe, () => pinsHistory);
}

// Convenience wrappers for the chat-pins scope.
export const pin = (ref: AssetRef) => toggle("pins", ref);
export const isPinned = (ref: AssetRef) => isIn("pins", ref);
