import type { AssetRef } from "@poc/core";
import { isPinned, pin, useCollection } from "./store";

/** Drop into any tile's `actions` slot to pin/unpin it for chat. */
export function PinButton({ target }: { target: AssetRef }) {
  useCollection("pins"); // re-render on pin state change
  const pinned = isPinned(target);
  return (
    <button
      className="col-pin-btn"
      aria-pressed={pinned}
      title={pinned ? "Unpin from chat" : "Pin to chat"}
      onClick={() => pin(target)}
    >
      {pinned ? "📌 Pinned" : "📍 Pin"}
    </button>
  );
}
