import { AssetTile } from "../AssetTile";
import { PinButton } from "./PinButton";
import { restorePin, useCollection, usePinsHistory } from "./store";

/** Pins panel: active (temporary) pins + a collapsed history for undoing clears. */
export function PinsScreen() {
  const pins = useCollection("pins");
  const history = usePinsHistory();

  return (
    <div className="col-pins">
      <div className="col-pins__head">
        <h3>{pins.name}</h3>
        <span className="col-pins__count">{pins.items.length}</span>
      </div>
      {pins.items.length === 0 && (
        <p className="col-pins__empty">Nothing pinned. Pin assets to give the chat context.</p>
      )}
      <ul className="mp-list mp-compact">
        {pins.items.map((ref) => (
          <li key={`${ref.type}:${ref.id}`}>
            <AssetTile {...ref} actions={<PinButton target={ref} />} />
          </li>
        ))}
      </ul>

      {history.length > 0 && (
        <details className="col-pins__history">
          <summary>Recent pins ({history.length})</summary>
          <ul className="mp-list mp-compact">
            {history.map((ref) => (
              <li key={`h:${ref.type}:${ref.id}`}>
                <AssetTile
                  {...ref}
                  actions={
                    <button className="col-pin-btn" onClick={() => restorePin(ref)} title="Re-pin">
                      ↩ Re-pin
                    </button>
                  }
                />
              </li>
            ))}
          </ul>
        </details>
      )}
    </div>
  );
}
