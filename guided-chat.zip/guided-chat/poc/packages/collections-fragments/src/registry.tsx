import type { Asset, AssetTypeId } from "@poc/core";
import type { ComponentType, ReactNode } from "react";
import { AgentTile } from "./tiles/agents/AgentTile";
import { AgentList } from "./tiles/agents/AgentList";
import { DatasetTile } from "./tiles/datasets/DatasetTile";
import { DatasetList } from "./tiles/datasets/DatasetList";
import { SkillTile } from "./tiles/skills/SkillTile";
import { SkillList } from "./tiles/skills/SkillList";
import { FallbackTile } from "./tiles/FallbackTile";

/**
 * The one central registry. It knows the tile for every asset type — regardless of which
 * app "owns" it. In production each entry would resolve a runtime fragment from the owning
 * app; here they're direct imports. Collections/AssetTile render through this.
 */
export interface AssetFragment {
  Tile: ComponentType<{ asset: any; actions?: ReactNode }>;
  List: ComponentType<{ assets: any[] }>;
}

const FRAGMENTS: Partial<Record<AssetTypeId, AssetFragment>> = {
  "assets/agent": { Tile: AgentTile, List: AgentList },
  "assets/dataset": { Tile: DatasetTile, List: DatasetList },
  "assets/skill": { Tile: SkillTile, List: SkillList },
};

const FALLBACK: AssetFragment = {
  Tile: FallbackTile,
  List: ({ assets }: { assets: Asset[] }) => (
    <ul className="mp-list">
      {assets.map((a) => (
        <li key={a.id}>
          <FallbackTile asset={a} />
        </li>
      ))}
    </ul>
  ),
};

/** Resolve the fragment for a type; never throws — falls back to a generic tile. */
export function getFragment(type: AssetTypeId): AssetFragment {
  return FRAGMENTS[type] ?? FALLBACK;
}

export function hasFragment(type: AssetTypeId): boolean {
  return type in FRAGMENTS;
}
