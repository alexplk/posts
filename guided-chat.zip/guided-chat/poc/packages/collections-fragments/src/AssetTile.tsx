import { getAsset } from "@poc/core";
import type { AssetRef } from "@poc/core";
import type { ReactNode } from "react";
import { getFragment } from "./registry";

/**
 * Render any asset by { type, id }. Resolves data (mock now, API later) and the owning
 * tile from the central registry. The one component collections/search/pins/paths reuse.
 */
export function AssetTile({
  type,
  id,
  actions,
}: AssetRef & { actions?: ReactNode }) {
  const asset = getAsset({ type, id });
  if (!asset) {
    return <article className="mp-tile mp-tile--missing">Unknown asset {type}:{id}</article>;
  }
  const { Tile } = getFragment(type);
  return <Tile asset={asset} actions={actions} />;
}
