import type { Dataset } from "@poc/core";
import type { ReactNode } from "react";
import { TileShell } from "../shared";

export function DatasetTile({ asset, actions }: { asset: Dataset; actions?: ReactNode }) {
  return (
    <TileShell
      kind="Dataset"
      name={asset.name}
      meta={`format: ${asset.format}`}
      actions={actions}
      href={`/marketplace/datasets/${asset.id}`}
    />
  );
}
