import type { Dataset } from "@poc/core";
import { DatasetTile } from "./DatasetTile";

export function DatasetList({ assets }: { assets: Dataset[] }) {
  return (
    <ul className="mp-list">
      {assets.map((a) => (
        <li key={a.id}>
          <DatasetTile asset={a} />
        </li>
      ))}
    </ul>
  );
}
