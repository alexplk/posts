import type { Skill } from "@poc/core";
import type { ReactNode } from "react";
import { TileShell } from "../shared";

export function SkillTile({ asset, actions }: { asset: Skill; actions?: ReactNode }) {
  return (
    <TileShell
      kind="Skill"
      name={asset.name}
      meta={`category: ${asset.category}`}
      actions={actions}
      href={`/marketplace/skills/${asset.id}`}
    />
  );
}
