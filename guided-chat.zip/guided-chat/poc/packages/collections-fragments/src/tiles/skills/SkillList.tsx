import type { Skill } from "@poc/core";
import { SkillTile } from "./SkillTile";

export function SkillList({ assets }: { assets: Skill[] }) {
  return (
    <ul className="mp-list">
      {assets.map((a) => (
        <li key={a.id}>
          <SkillTile asset={a} />
        </li>
      ))}
    </ul>
  );
}
