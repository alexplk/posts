import type { Agent } from "@poc/core";
import type { ReactNode } from "react";
import { TileShell } from "../shared";

export function AgentTile({ asset, actions }: { asset: Agent; actions?: ReactNode }) {
  return (
    <TileShell
      kind="Agent"
      name={asset.name}
      meta={asset.capability}
      actions={actions}
      href={`/marketplace/agents/${asset.id}`}
    />
  );
}
