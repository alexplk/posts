import type { Agent } from "@poc/core";
import { AgentTile } from "./AgentTile";

export function AgentList({ assets }: { assets: Agent[] }) {
  return (
    <ul className="mp-list">
      {assets.map((a) => (
        <li key={a.id}>
          <AgentTile asset={a} />
        </li>
      ))}
    </ul>
  );
}
