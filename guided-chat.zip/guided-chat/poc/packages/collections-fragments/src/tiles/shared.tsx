import type { ReactNode } from "react";

/**
 * Shared visual shell for every tile — a self-contained <article>. When `href` is given,
 * the title is a "stretched link" that covers the whole card for navigation, while actions
 * (pin, etc.) sit above it via z-index so they stay independently clickable.
 *
 * `href` is a plain string hardcoded by each tile (tiles are isolated fragments from
 * different apps — they own their own detail URL and never touch an app router).
 *
 * The tile IS the <article>; wrapping it (in <li>, a grid cell, etc.) is the caller's
 * job and depends on where it's rendered.
 */
export function TileShell({
  kind,
  name,
  meta,
  actions,
  href,
}: {
  kind: string;
  name: string;
  meta?: ReactNode;
  actions?: ReactNode;
  href?: string;
}) {
  return (
    <article className="mp-tile">
      <div className="mp-tile__head">
        <span className="mp-tile__kind">{kind}</span>
        {actions && <span className="mp-tile__actions">{actions}</span>}
      </div>
      <h3 className="mp-tile__name">
        {href ? (
          <a className="mp-tile__link" href={href}>
            {name}
          </a>
        ) : (
          name
        )}
      </h3>
      {meta && <div className="mp-tile__meta">{meta}</div>}
    </article>
  );
}
