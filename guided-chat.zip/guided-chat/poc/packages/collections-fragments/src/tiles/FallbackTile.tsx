import type { Asset } from "@poc/core";
import type { ReactNode } from "react";
import { assetLabel } from "../asset-types";
import { TileShell } from "./shared";

/** Rendered when an asset type has no registered fragment yet (model/tool/data-product). */
export function FallbackTile({ asset, actions }: { asset: Asset; actions?: ReactNode }) {
  return (
    <TileShell
      kind={assetLabel(asset.type)}
      name={asset.name}
      meta="(no fragment yet)"
      actions={actions}
    />
  );
}
