import { useSyncExternalStore } from "react";

/**
 * Which workspace panel/tab should be selected. Tools call setActivePanel when they update
 * a surface (pin added → "pins", steps set → "steps", …) so the relevant tab comes forward.
 * Lives here (below chatbot + shell) so any package can signal it. Ephemeral.
 */
/** A fresh token each call so re-activating the same panel still fires effects. */
export interface ActivePanel {
  id: string;
  n: number;
}

let active: ActivePanel | null = null;
let seq = 0;
const listeners = new Set<() => void>();

export function setActivePanel(id: string) {
  active = { id, n: ++seq };
  for (const l of listeners) l();
}

export const useActivePanel = (): ActivePanel | null =>
  useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => active,
  );
