# guided-chat POC workspace

A pnpm workspace to prototype **Search via Assistant** and the shared **fragments +
collections** core. Design sandbox — see [../docs](../docs) for intent.

> ⚠️ Scaffold, **not verified to run**. Dependency versions (esp. `@assistant-ui/react`)
> are indicative; align them on `pnpm install`. This exists so Alex can pull
> snippets/structure, not as a production build.

## Layout

```
packages/
  core                   pure types, mock data + mock search (no UI)
  collections-fragments  THE shared layer. Owns: asset-type list, central tile registry,
                         all tiles (tiles/agents|datasets|skills + fallback), AssetTile(type,id),
                         and pins (localStorage store + PinButton + PinsScreen). Anyone renders
                         any asset by { type, id } through here.
  chatbot                assistant-ui + civilized custom thread + search frontend tool
  shell                  shared app Shell: header + left nav slot + always-open chat
apps/
  portal                 the single SPA. App sections are folders:
                           src/home/         home dashboard
                           src/marketplace/  generic list (registry) + PER-TYPE detail pages
                                             (AgentDetail, DatasetDetail, SkillDetail)
                           src/collections/  collections/pins management section
```

## Where things live (per the design intent)

- **Tiles + registry are NOT per app** — they live centrally in `collections-fragments`.
  `AssetTile` knows internally how to render any type. Pins go through this package too.
- **Detail pages ARE per app / per type** — `AgentDetail` etc. are owned by the marketplace
  section, not a generic renderer, because each type's detail is genuinely different.

## Single-app / SPA note

One app (`apps/portal`). `Shell` (with the always-open chat) is the **layout route**,
rendered once; only the `<Outlet/>` swaps on nav, so **the chat + its runtime and pins
survive page navigation**. In the prototype `collections-fragments` imports tiles directly;
in production it's a shell that resolves each tile as a runtime fragment from its owning app.

## Dependency direction (no cycles)

```
core  ←  collections-fragments  ←  chatbot  ←  shell  ←  apps/portal
```

## Key idea being prototyped

- Marketplace exposes tiles as **fragments** (`marketplace-fragments`). In this prototype
  the fragments are direct imports; **in production this package is a shell that at runtime
  calls out to the owning apps for the actual modules** (no shared runtime, no versioning).
- `collections` renders any asset by `{ type, id }` via a **fragment registry** + resolves
  its data — same mechanism backs favorites, named collections, and **pinned-for-chat**.
- `chatbot` has a **frontend search tool**: recognizes a search request, calls the mock
  search API in the browser, and renders results as marketplace `AssetTile` fragments.

## Run (after aligning deps)

```bash
pnpm install
pnpm portal       # http://localhost:5173
```
