import { BrowserRouter, NavLink, Navigate, Outlet, Route, Routes } from "react-router-dom";
import { Shell } from "@poc/shell";
import { NAV } from "./marketplace/asset-nav";
import { HomePage } from "./home/HomePage";
import { ListPage } from "./marketplace/ListPage";
import { AgentDetail } from "./marketplace/pages/AgentDetail";
import { DatasetDetail } from "./marketplace/pages/DatasetDetail";
import { SkillDetail } from "./marketplace/pages/SkillDetail";
import { CollectionsPage } from "./collections/CollectionsPage";
import { CheatSheetPage } from "./help/CheatSheetPage";

/**
 * Single-app SPA. Shell (with the always-open chat) is the layout route element, rendered
 * ONCE; only the <Outlet/> content swaps on nav, so the chat + its runtime and the pins
 * panel survive page navigation. home/ marketplace/ collections/ are app sections.
 *
 * Lists are generic (registry-driven); detail pages are per-type and owned here.
 */
export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          element={
            <Shell app="Portal" nav={<Nav />}>
              <Outlet />
            </Shell>
          }
        >
          <Route index element={<HomePage />} />

          <Route path="marketplace" element={<Navigate to="/marketplace/agents" replace />} />
          <Route path="marketplace/:slug" element={<ListPage />} />
          <Route path="marketplace/agents/:id" element={<AgentDetail />} />
          <Route path="marketplace/datasets/:id" element={<DatasetDetail />} />
          <Route path="marketplace/skills/:id" element={<SkillDetail />} />

          <Route path="collections" element={<CollectionsPage />} />
          <Route path="help" element={<CheatSheetPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

function Nav() {
  const link = ({ isActive }: { isActive: boolean }) =>
    isActive ? "nav__link nav__link--on" : "nav__link";
  return (
    <>
      <NavLink to="/" end className={link}>
        Home
      </NavLink>
      <div className="nav__group">Marketplace</div>
      {NAV.map((n) => (
        <NavLink key={n.slug} to={`/marketplace/${n.slug}`} className={link}>
          {n.label}
        </NavLink>
      ))}
      <div className="nav__group">You</div>
      <NavLink to="/collections" className={link}>
        Collections
      </NavLink>
      <NavLink to="/help" className={link}>
        Cheat sheet
      </NavLink>
    </>
  );
}
