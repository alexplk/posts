import { AssetTile, PinButton, useCollection } from "@poc/collections-fragments";

/**
 * Collections section of the portal. Renders the user's collections (pins, favorites)
 * — all backed by the same collections-fragments store. Pins here are the exact set the
 * chat sees. (Named/shared collections would list here too.)
 */
export function CollectionsPage() {
  return (
    <div>
      <h1 className="home__h1">Collections</h1>
      <p className="home__lead">Everything you've pinned or favorited. Backed by the shared store.</p>
      <CollectionBlock id="pins" />
      <CollectionBlock id="favorites" />
    </div>
  );
}

function CollectionBlock({ id }: { id: string }) {
  const c = useCollection(id);
  return (
    <section style={{ marginTop: 20 }}>
      <h3 className="home__section">
        {c.name} <span className="col-pins__count">{c.items.length}</span>
      </h3>
      {c.items.length === 0 ? (
        <p className="mkt__empty">Empty.</p>
      ) : (
        <ul className="mp-list mp-compact">
          {c.items.map((ref) => (
            <li key={`${ref.type}:${ref.id}`}>
              <AssetTile {...ref} actions={<PinButton target={ref} />} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
