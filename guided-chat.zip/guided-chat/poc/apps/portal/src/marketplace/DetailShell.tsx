import type { AssetRef } from "@poc/core";
import { PinButton } from "@poc/collections-fragments";
import type { ReactNode } from "react";
import { Link } from "react-router-dom";

/** App-local layout shared by the per-type detail pages (back link + pin + body). */
export function DetailShell({
  backTo,
  backLabel,
  target,
  title,
  children,
}: {
  backTo: string;
  backLabel: string;
  target: AssetRef;
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="mkt__detail">
      <Link className="mkt__open" to={backTo}>← {backLabel}</Link>
      <div className="mkt__detail-head">
        <h2 className="mkt__h2">{title}</h2>
        <PinButton target={target} />
      </div>
      {children}
    </div>
  );
}
