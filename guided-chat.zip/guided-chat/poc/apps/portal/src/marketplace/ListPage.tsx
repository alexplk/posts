import { listAssets } from "@poc/core";
import { assetLabel, getFragment, PinButton } from "@poc/collections-fragments";
import { useParams } from "react-router-dom";
import { typeForSlug } from "./asset-nav";

export function ListPage() {
  const { slug } = useParams();
  const type = typeForSlug(slug);
  if (!type) return <p className="mkt__empty">Unknown collection.</p>;

  const assets = listAssets(type);
  const { Tile } = getFragment(type);
  return (
    <div>
      <h2 className="mkt__h2">{assetLabel(type, true)}</h2>
      {assets.length === 0 && <p className="mkt__empty">No {assetLabel(type, true)} yet.</p>}
      <ul className="mp-list">
        {assets.map((a) => (
          <li key={a.id}>
            <Tile asset={a} actions={<PinButton target={{ type: a.type, id: a.id }} />} />
          </li>
        ))}
      </ul>
    </div>
  );
}
