import { getAsset } from "@poc/core";
import type { Agent } from "@poc/core";
import { useParams } from "react-router-dom";
import { DetailShell } from "../DetailShell";
import { NotFound } from "./NotFound";

/** Agent-specific detail page — owned by the marketplace app, not a generic renderer. */
export function AgentDetail() {
  const { id } = useParams();
  const asset = id ? (getAsset({ type: "assets/agent", id }) as Agent | undefined) : undefined;
  if (!asset) return <NotFound backTo="/marketplace/agents" />;

  return (
    <DetailShell
      backTo="/marketplace/agents"
      backLabel="Agents"
      target={{ type: "assets/agent", id: asset.id }}
      title={asset.name}
    >
      <p className="mkt__lead">{asset.capability}</p>
      <dl className="mkt__props">
        <dt>id</dt><dd>{asset.id}</dd>
        <dt>capability</dt><dd>{asset.capability}</dd>
      </dl>
      {/* Agent-only affordances would live here (run, versions, tools it uses…). */}
    </DetailShell>
  );
}
