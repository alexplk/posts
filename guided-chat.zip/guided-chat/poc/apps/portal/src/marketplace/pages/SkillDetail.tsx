import { getAsset } from "@poc/core";
import type { Skill } from "@poc/core";
import { useParams } from "react-router-dom";
import { DetailShell } from "../DetailShell";
import { NotFound } from "./NotFound";

export function SkillDetail() {
  const { id } = useParams();
  const asset = id ? (getAsset({ type: "assets/skill", id }) as Skill | undefined) : undefined;
  if (!asset) return <NotFound backTo="/marketplace/skills" />;

  return (
    <DetailShell
      backTo="/marketplace/skills"
      backLabel="Skills"
      target={{ type: "assets/skill", id: asset.id }}
      title={asset.name}
    >
      <dl className="mkt__props">
        <dt>id</dt><dd>{asset.id}</dd>
        <dt>category</dt><dd>{asset.category}</dd>
      </dl>
      {/* Skill-only affordances: inputs/outputs, example invocation… */}
    </DetailShell>
  );
}
