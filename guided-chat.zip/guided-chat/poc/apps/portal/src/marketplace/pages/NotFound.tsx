import { Link } from "react-router-dom";

export function NotFound({ backTo }: { backTo: string }) {
  return (
    <div>
      <Link className="mkt__open" to={backTo}>← back</Link>
      <p className="mkt__empty">Asset not found.</p>
    </div>
  );
}
