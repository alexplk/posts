import { getAsset } from "@poc/core";
import type { Dataset } from "@poc/core";
import { useParams } from "react-router-dom";
import { DetailShell } from "../DetailShell";
import { NotFound } from "./NotFound";

export function DatasetDetail() {
  const { id } = useParams();
  const asset = id ? (getAsset({ type: "assets/dataset", id }) as Dataset | undefined) : undefined;
  if (!asset) return <NotFound backTo="/marketplace/datasets" />;

  return (
    <DetailShell
      backTo="/marketplace/datasets"
      backLabel="Datasets"
      target={{ type: "assets/dataset", id: asset.id }}
      title={asset.name}
    >
      <dl className="mkt__props">
        <dt>id</dt><dd>{asset.id}</dd>
        <dt>format</dt><dd>{asset.format}</dd>
      </dl>
      {/* Dataset-only affordances: schema preview, sample rows, lineage… */}
    </DetailShell>
  );
}
