import type { AssetTypeId } from "@poc/core";

/** URL slug ⇄ asset type for marketplace routes / left nav. */
export const NAV: { slug: string; type: AssetTypeId; label: string }[] = [
  { slug: "agents", type: "assets/agent", label: "Agents" },
  { slug: "datasets", type: "assets/dataset", label: "Datasets" },
  { slug: "skills", type: "assets/skill", label: "Skills" },
];

export const typeForSlug = (slug?: string) => NAV.find((n) => n.slug === slug)?.type;
