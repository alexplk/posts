import type { ReactNode } from "react";
import { ASSET_TYPES, assetLabel } from "@poc/collections-fragments";

/**
 * Cheat sheet for the stub agent's chat commands. Mirrors the parsing in chatbot's
 * mock-search-api (parseSearch) and runtime (parseTaskCommand). Keep in sync if those change.
 */
export function CheatSheetPage() {
  const typeWords = ASSET_TYPES.map((t) => assetLabel(t.type, true)).join(", ");
  return (
    <div className="cheat">
      <h1 className="home__h1">Chat commands</h1>
      <p className="home__lead">What the assistant understands today (stub agent).</p>

      <section className="cheat__sec">
        <h3>Search</h3>
        <p>Type anything — it substring-searches everything by name and description.</p>
        <ul className="cheat__list">
          <li><Cmd>kyc</Cmd> — everything matching “kyc”, across all asset types</li>
          <li>
            <Cmd>kyc agents</Cmd> — end with a type to filter to it. Type words:{" "}
            <span className="cheat__muted">{typeWords}</span> (singular works too)
          </li>
          <li><Cmd>find trade datasets</Cmd> — a leading <em>find / search / show / list / look up</em> is optional and ignored</li>
        </ul>
        <p className="cheat__muted">The type filter is a pure “ends with” match — a keyword mid-sentence stays a full-text search.</p>
      </section>

      <section className="cheat__sec">
        <h3>Checklist</h3>
        <p>Populates the Checklist panel (user-checkable items).</p>
        <ul className="cheat__list">
          <li><Cmd>plan: gather docs, run checks, submit</Cmd> — comma/semicolon-separated items</li>
          <li><Cmd>checklist:</Cmd> / <Cmd>tasks:</Cmd> — same, other trigger words</li>
          <li><Cmd>plan</Cmd> — with no items, seeds a default 3-item checklist</li>
        </ul>
      </section>

      <section className="cheat__sec">
        <h3>Steps (guided progress)</h3>
        <p>Populates the read-only Steps panel. Advance via command — nodes aren’t clickable.</p>
        <ul className="cheat__list">
          <li><Cmd>steps</Cmd> — default guided flow: <b>Collect Assets → Review → Submit Reviews</b></li>
          <li><Cmd>steps: scope, build, test</Cmd> — your own, comma/semicolon-separated</li>
          <li><Cmd>step</Cmd> / <Cmd>done</Cmd> — complete the next step (advance by one)</li>
          <li><Cmd>done 2</Cmd> / <Cmd>2 done</Cmd> / <Cmd>done Submit Reviews</Cmd> — tick one item by number or exact name (steps first, then checklist)</li>
        </ul>
        <p className="cheat__muted">
          Completing <b>Collect Assets</b> (with pins) stamps its status (“2 agents, 1 skill”), copies the pins into the
          <b> Artifacts</b> panel, and explodes <b>Review</b> into one “Review &lt;asset&gt;” step per collected asset.
          Connectors turn blue only between two completed steps, so out-of-order completion forms connected blue clumps.
        </p>
      </section>

      <section className="cheat__sec">
        <h3>Step-linked UI</h3>
        <p>Some steps have an inline UI (above the composer). It appears the <b>first time</b> that
          step becomes current, is dismissed as soon as you type, and never auto-pops again —
          click the step in the Steps panel to reopen it.</p>
        <ul className="cheat__list">
          <li><b>Collect Assets</b> → a menu (Search agents / Search datasets — click to navigate).</li>
          <li><b>Review &lt;asset&gt;</b> → a form: notes + recommend/modify. Submit marks the step done + notes an Artifact.</li>
          <li><b>Submit Reviews</b> → a confirm (“ready to be submitted”) with a Submit button.</li>
        </ul>
      </section>

      <section className="cheat__sec">
        <h3>Artifacts</h3>
        <p>The Artifacts panel collects assets and text blocks (files/docs later). Populated by the
          Collect Assets step, or directly by the assistant’s <Cmd>updateArtifacts</Cmd> tool.</p>
      </section>

      <section className="cheat__sec">
        <h3>Elsewhere in the UI</h3>
        <ul className="cheat__list">
          <li><b>Pin</b> — pin any tile to give the chat context; pinning brings the Pins tab forward. Pins are a <em>temporary</em> selection — a chat step that uses them clears them (into “Recent pins”, one click to re-pin).</li>
          <li><b>Tabs</b> — updating a surface (pin, steps, checklist, artifacts) auto-selects its tab; you can still click between them.</li>
          <li><b>Conversations</b> — <em>+ New</em> starts a chat, <em>← Home</em> lists saved ones, <em>✕</em> deletes. Each keeps its own messages + checklist.</li>
        </ul>
      </section>
    </div>
  );
}

function Cmd({ children }: { children: ReactNode }) {
  return <code className="cheat__cmd">{children}</code>;
}
