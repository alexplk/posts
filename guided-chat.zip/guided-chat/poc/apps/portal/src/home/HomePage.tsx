import { AssetTile } from "@poc/collections-fragments";
import { allAssets } from "@poc/core";

/** Home section. The search-driven flow lives in the always-open chat panel (right). */
export function HomePage() {
  const recent = allAssets().slice(0, 4);
  return (
    <div>
      <h1 className="home__h1">Welcome back</h1>
      <p className="home__lead">Ask the assistant on the right — try “find KYC agents”.</p>
      <h3 className="home__section">Recently added</h3>
      <ul className="mp-list">
        {recent.map((a) => (
          <li key={`${a.type}:${a.id}`}>
            <AssetTile type={a.type} id={a.id} />
          </li>
        ))}
      </ul>
    </div>
  );
}
