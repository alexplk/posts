# guided-chat

Design + thinking workspace for a set of related features on top of an
assistant-ui chatbot. This is a **design sandbox**, not the real codebase.

## How to work in here

- **Direction, not implementation.** Alex takes snippets and ideas from here into
  the real (unseen) codebase. Optimize for clear thinking, decisions, and reusable
  patterns — not a runnable app.
- **Expect drift.** The real implementation lives at work and Claude never sees it.
  Alex will summarize progress back here when he can; assume this repo may be out of
  sync with what actually shipped. When resuming, re-read `docs/` before assuming state.
- **Coming back often.** This is a long-lived design thread. Keep notes durable and
  self-explanatory so a cold-start session can pick up.
- Follow `code/platform/ARCHITECTURE.md` conventions if/when UI code gets written here.

## Domain context

- **Chatbot**: assistant-ui frontend.
- **Agent**: internal LangGraph-based agent behind the scenes.
- **Agent capabilities**: internal data APIs, search APIs, registries of assets.
- **Asset space**: company AI & data registry. Asset types include agents, models,
  skills, tools/MCPs, datasets, data products, and more.

## Features

Three related features sharing a common core. Full notes in `docs/`:
1. **Search via Assistant** (high) — search-shaped requests render a real search UX in chat.
2. **Guided Paths** (high) — walk users through complex multi-step processes; cowork-like.
3. **Collections** (low) — align portal Collections with the assistant; pin assets as context.

Shared core: **fragments** (render layer) + **collections** (context layer). See
`docs/00-shared-infrastructure.md`.

## Docs & code

- `docs/` — one file per feature/topic (see `docs/README.md`).
- `poc/` — pnpm workspace prototype (design sandbox, not verified to run). Packages:
  `core`, `marketplace-fragments` (fragment tiles + registry), `collections` (AssetTile
  resolver + localStorage pin store + Pins screen), `chatbot` (assistant-ui + search
  frontend tool), `shell` (shared layout + always-open chat). **Single app** `apps/portal`
  (SPA): `src/home/` and `src/marketplace/` are folders, not separate apps. Shell is the
  layout route so chat survives nav. Dep direction: core ← marketplace-fragments ←
  collections ← chatbot ← shell ← portal. See `poc/README.md`.

_Last updated: 2026-08-14 — scaffolding only._
