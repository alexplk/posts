# Filters & insights — architecture

How filters, the search bar, insight widgets, the results banner and the AI agent fit together in this POC. Companion docs: [`agents-filters-widgets.md`](./agents-filters-widgets.md) (the agents page: which filters and widgets exist and why they hide) and [`src/components/insights/README.md`](./src/components/insights/README.md) (the widget kit: primitives, renderers, charts, how they look, when to use which).

---

## 1. Define filters once, derive everything else

**The filter definition is the single source of truth.** A filter is described once, with a user/agent-facing facet and a code-facing facet. Every surface that lets someone see, set, remove, explain or execute a filter is derived from that definition and keeps no copy of names, values or matching logic.

```
                          ┌────────────────────────────┐
                          │     FILTER DEFINITIONS     │
                          │  user/agent facet + code   │
                          │  facet, incl. composites   │
                          └─────────────┬──────────────┘
                                        │ derive
   ┌───────────────┬────────────────────┼──────────────────┬──────────────────────┐
   ▼               ▼                    ▼                  ▼                      ▼
Filter list UI   Search-bar chips    Insight widgets    Search queries       AI skill and/or
(combos,         (applied filters    (summaries of the  (Azure AI Search     frontend tool
checkboxes)      next to keywords,   filtered set that  index or similar)    (shared language,
                 add / remove)       add/remove the                          agent → filter set
                                     same filters)       [not built]         → query) [not built]
[not built]
```

- The **filter list** (combos or checkboxes beside the keyword search) is generated from the definitions, not hand-built.
- **Chips in the search bar** take their display name and value label from the definition; removing a chip removes the filter.
- An **insight widget** click is expressed in the same vocabulary (`stage = PROD` + `registry = X`), so widgets and controls cannot disagree, and widget counts come from the same evaluator as the result list.
- The **query translator** reads the code facet (keys, DB values, composite expansion) to produce the search query.
- The **AI skill / frontend tool** reads the user facet (display names, descriptions, available values) so user and agent share one language; the agent converts filters to a query in the background without ever writing query syntax itself.

### 1.1 The two facets

| Facet | Contents |
|---|---|
| **User / agent facing** | display name · description · known values, each with its own label and description |
| **Code facing** | key (the `field` in a `FilterPatch`) · in-memory predicate `matches(asset, value)` · `exclusive` flag · (to come) DB values / ids and the expression used for querying |

### 1.2 Composite filters

A filter may be a combination, implemented as a calculated condition. To the user and the agent it is one logical filter; only the code facet knows the expansion. Example in the POC: `quality = no-octo-id` → `!asset.octoId`. A future "Has data quality issues" would expand to something like `has dqIssue OR issueCount > 0 OR name is undefined`.

### 1.3 Keywords are part of the filter set

The keyword box and the filters are one thing: keywords apply on top of the filters, the generated filter UI sits next to the keyword box, and applied filters show as chips inside it.

### 1.4 Definitions vs. state

- **Definitions** hold functions (predicates, later value loaders): not serialisable, live in code (`FilterCatalog`).
- **Filter state** is plain data: `FilterPatch[]` = `{ field, value }[]` plus a keyword string. URL, agent tool calls and widget clicks all produce this same shape.
- Semantics: **OR within a field, AND across fields**, keywords AND-ed on top. Negation is not user-facing.
- One **expression tree** per definition (`toExpr`) is the planned bridge to backends: OData `$filter` for Azure AI Search, an in-memory predicate, and the text the agent skill uses to explain a composite. Today only the in-memory predicate exists (`matches`).

---

## 2. Code layout

```
src/
  filters/                     domain-blind filter library, no React
    types.ts                   FilterPatch, FilterValue, FilterDefinition<A>, FilterCatalog<A>
    define.ts                  fieldFilter(), computedFilter(), defineCatalog()
    filterSet.ts               add / remove / toggle / isApplied / allApplied / valuesOf /
                               hasField / singleValueOf / replaceFields / withoutFields / patchId
    match.ts                   matchAssets(catalog, assets, filters, keywords) — the in-memory evaluator
    describe.ts                definitionOf / labelOf / describe — user-facing text for a patch
    useFilterSet.ts            React state with the filterSet operations bound to it
  components/
    FilterBar/                 search field: chips + keyword input (domain-blind)
    ResultsSummary/            results banner: "N of M" eyebrow + identity line (domain-blind)
    insights/                  widget kit — see its README
  capabilities/assets/
    agents.filters.ts          THE agents filter catalogue (one list)
    agents.widgets.ts          THE agents widget list (one entry per widget, with its isEnabled rule)
    agents.mock.ts             sample data (deterministic generator)
    AssetSearch.tsx            one filter set drives bar, shelf, banner, cards
    AgentInsights.tsx          catalogue + widgets → InsightCtx → resolveInsights → InsightShelf
    ResultsSummaryWidget.tsx   picks the pinned identity fields for the banner
    AgentResults.tsx           first page of cards
  pages/AssetSearchPage.tsx    breadcrumb, title, AssetSearch
```

Layering follows `code/platform/ARCHITECTURE.md`: components (domain-blind, own all CSS) → capabilities (domain) → pages (assembly), dependencies downward only. `src/filters/` is a library both components and capabilities may import.

---

## 3. What each surface derives from the catalogue

### 3.1 Search-bar chips
`FilterBar` receives `{ id, kind, label }` chips built with `describe(catalog, patch)`: kind = the filter's display name, label = the value's label (falls back to the raw value for open-ended filters). Removing a chip calls `remove()` on the filter set. Backspace on an empty keyword box removes the last chip.

### 3.2 Insight widgets
Widgets are `InsightDefinition[]` — `{ id, isEnabled?(filters), build(ctx) }`. `resolveInsights` runs `isEnabled` against the current filters, calls `build` for the survivors (a build may return `null`), and marks every point `selected` whose filters are all active. `build` receives an `InsightCtx` whose `match`, `matchIgnoring(fields)` and `countIfClicked(patch)` all go through `matchAssets` with the same catalogue as the result list, so widget numbers and result counts can never diverge.

Click handling: `InsightWidget` forwards `onApply(filters, exclusiveFields)`; a widget marked `exclusive` names its own fields so choosing a value replaces the previous one. The page binds `onApply` to `toggle`, so clicking an already-applied point removes its filters.

Counting rule for breakdowns: a point's number is the size of the result set if it were clicked — current filters with the point's own field(s) replaced. A breakdown by X therefore ignores an active X filter (else unselected rows read 0) and every other filter narrows it. Suggestion chips are the exception: they count inside the current result set and hide at 0. With a search index this is facet counting with the facet's own filter excluded.

### 3.3 Results banner
`ResultsSummaryWidget` takes the identity fields to headline, in order; a field joins the line only while `singleValueOf(filters, field)` is set, labelled through `labelOf`. Always shows page size of total. Read-only.

### 3.4 Query translation — not built
Filter set → expression tree → target query (Azure AI Search or similar; pluggable). The expression tree will be produced per definition so composites expand in one place.

### 3.5 AI skill / frontend tool — not built
Generated from the catalogue: a skill listing filters, values and descriptions in user language (common vocabulary), plus a tool contract that takes a `FilterPatch[]` rather than query text, so the same translator serves UI and agent. As a frontend tool the agent can also drive the on-screen filter set directly (add / remove chips). Open: whether composites expose only their logical name or also their expansion.

### 3.6 Filter list UI — not built
Combos or checkboxes generated per definition next to the keyword box. The current "Filters ▾" button is a placeholder; the dropdown pattern it stands for is not liked and has no replacement yet.

---

## 4. Insight widgets — behaviour rules

- A widget **summarises the current filtered subset** and **acts as a filter**: a click applies one or more filters (`point.filters`), e.g. a registry row applies `registry = X` **and** `stage = PROD`.
- Widgets are **curated and conditional**: each has `isEnabled(filters)`. When a filter pins the axis a widget is about, it steps aside and a simpler variant steps in (see the agents doc for the concrete pairs).
- **Exclusive axes** replace rather than stack; everything else stacks (OR within the field).
- **Toggle**: clicking something whose filters are all active removes them.
- **Selected state** is derived, never configured. Rows, chips and tabs have their own selected styles; focus numbers (FocusNumberChart, FocusRatioChart) show a `SelectedFilterCheckMark` in the tile's top-right corner instead of tinting the number block.
- **Interaction lives in tables, chips, tabs and menu items.** Rails and rings are presentational and only react to a table row's hover.

---

## 5. Layout and look

- **Shelf**: 12 columns, 12px gutter. Each widget claims `layout.minSpan` (optional `maxSpan`); the packer fills rows greedily in list order and grows a row's widgets until it is exactly 12 wide, so a lone widget takes the full width and rows stretch to the tallest tile. List order is layout order — full-width widgets go last so narrower ones can pair up when a variant drops out. Below 900px every tile is full width.
- **Tile**: recessed — one step lighter than the page, 1px hairline border, radius 10, 16/18px padding. White result cards sit on the page; tiles sit in it.
- **Page rhythm**: search bar → shelf 20px · shelf → results banner 32px · banner → cards 20px.
- **Results banner**: "**N** of M results" at 17px (N strong), identity line at 21px medium, fields split by 5px grey dots; nothing clickable.
- **Type & colour**: no font families anywhere; sizes are `--font-size-1..7` (11/13/17/21/26/34/44); all colours are named tokens in `components/insights/tokens.css`; the app's `--company-semantic-color-*` are re-pointed to the same warm palette in `src/styles/theme-design.css` so "tile lighter than page" holds.
- **Styling**: `.module.css` only; runtime values reach a stylesheet as CSS custom properties through `style={cssVars({ "--x": v })}` (`npm run lint:styles` enforces it).

---

## 6. Open questions

- Dependent filters (org → team) and values that only load given other filters.
- Aggregations: with a real index, breakdowns are facets — does the catalogue also declare "groupable" fields and the own-facet-excluded counting rule?
- Per asset type: separate catalogues, or one with `appliesTo`?
- What replaces the Filters dropdown?
- Skill vs. frontend tool vs. both; how much of a composite's expansion the agent sees.
- URL serialisation of the filter set.
- Design tokens: the kit's scales (11/13/17/21/26/34/44 type, extra spacing steps, series colours, "unwanted" tone) do not map onto `--company-*` yet — either the design gets constrained to company tokens, or these become proposed additions.
