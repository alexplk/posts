# filters

POC: **one schema for describing filters over a list of typed assets**, with several UI and agent features generated from the same definitions.

Status: the **insight widgets + filter bar UI** are implemented from the Claude Design project and computed from mock agents; eight curated widgets switch on/off via `isEnabled(filters)`. The filter definitions live in `src/filters/` (library) + `agents.filters.ts` (catalogue); the generated filter list, query translation and the agent skill are not started.

Docs:
- [`filters-insights-architecture.md`](./filters-insights-architecture.md) — how filters, chips, widgets, banner and agent relate; code layout.
- [`agents-filters-widgets.md`](./agents-filters-widgets.md) — the agents page: filters, widgets, when they hide and why.
- [`src/components/insights/README.md`](./src/components/insights/README.md) — the widget kit: primitives, renderers, charts, how they look, which to use.

```
npm install
npm run dev          # http://localhost:5180
npm run build        # tsc + vite build
npm run lint:styles  # fails on any style= that is not cssVars()
```

## Idea

A filter is defined once and has two facets.

**User / agent facing** — what a person or an AI agent reads:

- display name
- description
- available values, when known up front or loadable, each with its own display name and description

**Code facing** — what the app runs:

- key
- callbacks to add / remove the filter in a filter set
- callback to check whether the filter is applied in a filter set
- DB values / ids used for matching and querying

Everything in scope consumes these definitions and nothing else, so the UI, the query layer, the insight widgets and the agent all share one vocabulary.

## In scope

1. **Generated filter UI.** Combos or checkboxes rendered next to a keyword search bar, produced from the definitions. Keywords are part of the same filter set, not a separate mechanism.
2. **Add / remove filters on the UI search.** The active filter set is editable from anywhere that holds a definition (controls, chips, widgets).
3. **Translate filters to search queries.** Azure AI Search index or similar; the target is pluggable.
4. **Generate a skill for AI agents.** The skill makes the agent understand the logical filters the user has for the assets and the data model, gives user and agent a common language, and in the background lets the agent convert filters to a search query.
5. **Data insights.** Small summaries and visualization widgets that apply to the *filtered subset* of data, and can themselves add or remove filters using the same definitions. Example: for a list of Datasets, a "Datasets in PROD by Org" bar chart; clicking a bar adds `env = Prod` and `org = <selected org>`.
6. **Composite filters.** A filter can be a combination, implemented as a calculated prop. Example: **Has Data Quality Issues** translates to something like `has field dqIssue OR issueCount > 0 OR name is undefined`.

## Draft shape (starting point, not decided)

The scope implies two separate things: **definitions** (hold functions, not serializable) and **filter state** (plain data, serializable — URL, agent tool calls, widget clicks all produce it).

```ts
// State: what is applied. Plain data.
type AppliedFilter = { key: string; values: string[] };
type FilterSet = { keywords: string; filters: AppliedFilter[] };

// One expression tree that every backend compiles from.
type Expr =
  | { op: "eq" | "ne" | "gt" | "ge" | "lt" | "le"; field: string; value: string | number | boolean }
  | { op: "in"; field: string; values: (string | number)[] }
  | { op: "exists" | "missing"; field: string }
  | { op: "and" | "or"; args: Expr[] }
  | { op: "not"; arg: Expr };

type FilterValue = {
  value: string;          // db value / id used for matching
  displayName: string;
  description?: string;
};

type FilterDefinition<Asset> = {
  // user / agent facet
  displayName: string;
  description: string;
  values?: FilterValue[] | (() => Promise<FilterValue[]>);
  control: "combo" | "checkboxes" | "toggle";

  // code facet
  key: string;
  appliesTo: AssetType[];
  add(set: FilterSet, values: string[]): FilterSet;
  remove(set: FilterSet, values?: string[]): FilterSet;
  isApplied(set: FilterSet, value?: string): boolean;
  toExpr(values: string[]): Expr;   // simple: { op: "in", field, values }
                                    // composite: any tree, e.g. Has DQ Issues
};
```

Consumers of the same `Expr` tree:

| Consumer | Output |
|---|---|
| Azure AI Search translator | OData `$filter` string + `search` for keywords |
| In-memory evaluator | `(asset) => boolean` — runs the POC on mock data, and lets insights compute over the filtered subset |
| Agent skill generator | `SKILL.md` listing filters / values / descriptions in user language, plus a tool contract that takes a `FilterSet` — the agent never writes OData itself |
| Insight widgets | declare the filters they group by; a click emits `add()` calls, e.g. `env=Prod` + `org=X` |

Simple filters would come from a helper (`fieldFilter({ key, field, ... })`) that fills in add / remove / isApplied / toExpr, so only composites write `toExpr` by hand.

## Open questions

- Semantics inside vs. across filters: OR within one filter's values, AND across filters? Is negation ("not PROD") user-facing?
- Dependent filters (org → team) and values that only load given other filters.
- Insights need aggregations (counts by org). With a real index that is facets, not a filter — does the schema describe "groupable" fields too?
- Which asset types share which filters; does the definition set vary per type or is it one set with `appliesTo`?
- Composite filters in the agent skill: expose only the logical name, or also the expansion so the agent can explain it?
- URL serialization of `FilterSet`.

## Design import

Source: Claude Design project "Filter widgets design exploration", file `Filter Widgets.dc.html`, **variant 3a (Recessed, agreed base)** — ShareBar (span 5) + FocusNumber with gaps-by-registry (4) + FilterTabs (3), then FilterChips full width — plus the project's `insights/` code kit.

| Where | What |
|---|---|
| `src/components/insights/` | The design's `insights/` kit, same file layout so a re-import diffs cleanly: `primitives/`, `charts/`, `renderers/`, `InsightShelf`, `allocateSpans`, `tokens.css`. Domain-blind; filter state moved out to `src/filters/useFilterSet`. |
| `src/components/FilterBar/` | Search field holding applied filters as removable chips + keywords (Backspace on empty input removes the last chip). |
| `src/filters/` | Domain-blind filter library (no React): definitions, filter-set operations, in-memory matcher, labels, `useFilterSet`. |
| `src/capabilities/assets/agents.filters.ts` | The agents **filter catalogue** — the one place to edit display names, value labels, composites. |
| `src/capabilities/assets/agents.widgets.ts` | The agents **widget list** — one entry per widget with its `isEnabled` rule. |
| `src/capabilities/assets/` | `AssetSearch`, `AgentInsights`, `ResultsSummaryWidget`, `AgentResults`, `agents.mock.ts` — wiring only. |
| `src/styles/theme-design.css` | Re-points `--company-semantic-color-*` to the design's warm palette, so "tile one step lighter than the page" holds. |

Changes made to the kit while importing:

- `style={{…}}` → `style={cssVars({…})}`; `RatioBar`'s inline `flex-grow` became `--segment-grow`.
- `InsightWidget` reports `exclusive` to the shelf callback: `onApply(filters, exclusiveFields)`, so Environment tabs *replace* the stage filter while ShareBar rows *stack*.
- 3a deltas the kit didn't have yet: vertical `SegmentedTabs` (`NumberChip row`), FocusNumber breakdown with a share column (`breakdownShareColumns`), muted total in ShareBar's label.
- Interactive rows/menu items use `calc(100% + 2 × inset)` so the hover bleed is symmetric (a 100%-wide button with negative margins only bleeds left).
- Shelf tiles stack below 900px (design is drawn at 1440 only).

Not imported: masthead + side nav (platform shell, not part of this POC); Donut/Numbers/RatioBar charts are in the kit but not on the page; turn 1–2 explorations and variants 3b–3d.

Since the import, widget configs are no longer static: `agents.widgets.ts` holds definitions (`isEnabled` + `build`) computed over ~4,200 generated mock agents — see the architecture doc §3.

### Token gap (finding)

The kit brings its own `tokens.css` (`--font-size-1..7`, `--space-1..10`, `--color-*`). It does not map onto `--company-*`: company type scale is 12/14/16/20/32 vs. the design's 11/13/17/21/26/34/44; spacing lacks 6/10/14/18/22px; there are no categorical series colours, no "unwanted" tone, no hairline/divider distinction. So two token layers coexist here. Either the design gets constrained to company tokens, or these become proposed additions.

## UI architecture

Follows `code/platform/ARCHITECTURE.md` (source of truth — not copied here to avoid drift). Short version:

- **components/** — domain-blind building blocks; all CSS lives here. **capabilities/** — domain concepts (asset search, filter bar, insights). **pages/** — assembly only. Dependencies point downward only.
- A component, or plain semantic HTML. Global CSS is only `styles/base.css` (element defaults) and `styles/utils.module.css` (single-element modifiers, imported as `u`).
- Tokens from `src/global-design.css` (`--company-primitive-*`, `--company-semantic-*`); never hardcode raw values.
- No Tailwind / utility-first frameworks.

POC-specific, stricter than `code/platform`:

- **`.module.css` for all styles.** Platform's `Stack` / `Row` / `Panel` took inline styles; here layout props map to classes in `components/layout/layout.module.css`.
- **One exception, from the design's own rules:** runtime values (segment colour, grid span, column tracks) reach the stylesheet as CSS custom properties via `style={cssVars({ "--x": v })}` (`components/cssVars.ts`). `npm run lint:styles` fails on any other `style=`.
- `@/` aliases `src/`.

Planned non-UI home for the schema: `src/filters/` (definitions, `Expr`, translators, skill generator) — domain logic with no React in it, consumed by capabilities.
