import { Page } from "@/components/layout/Page";
import { Stack } from "@/components/layout/Stack";
import { Heading } from "@/components/Heading";
import { AssetSearch } from "@/capabilities/assets/AssetSearch";
import u from "@/styles/utils.module.css";

export function AssetSearchPage() {
  return (
    <Page>
      <Stack gap={7}>
        <Stack gap={3} as="header">
          <p className={u.caption}>Home / Marketplace / Agents</p>
          <Heading level={1}>Agents</Heading>
        </Stack>
        <AssetSearch />
      </Stack>
    </Page>
  );
}
