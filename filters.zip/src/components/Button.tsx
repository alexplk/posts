import type { ButtonHTMLAttributes, ReactNode } from "react";
import styles from "./Button.module.css";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost";
  size?: "medium" | "small";
};

export function Button({
  children,
  variant = "secondary",
  size = "medium",
  className,
  type = "button",
  ...rest
}: ButtonProps) {
  const cls = [styles.button, styles[variant], styles[size], className].filter(Boolean).join(" ");
  return (
    <button className={cls} type={type} {...rest}>
      {children}
    </button>
  );
}
