import type { ReactNode } from "react";
import styles from "./Card.module.css";

/** Raised white result card: sits ON the page, unlike insight tiles which sit IN it. */
export function Card({ children }: { children: ReactNode }) {
  return <article className={styles.card}>{children}</article>;
}
