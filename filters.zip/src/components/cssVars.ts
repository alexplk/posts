import type { CSSProperties } from "react";

/**
 * The ONE sanctioned use of the style attribute: handing runtime values to a
 * .module.css file as CSS custom properties (segment colour, grid span, column
 * tracks). Appearance still lives in the stylesheet — it reads var(--x).
 * `npm run lint:styles` rejects any style= that doesn't go through this.
 */
export function cssVars(vars: Record<`--${string}`, string | number>): CSSProperties {
  return vars as CSSProperties;
}
