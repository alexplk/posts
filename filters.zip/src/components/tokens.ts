/* Typed view of the design-token scales in global-design.css, for component
 * props. Props map to classes in .module.css files — never to inline styles. */

// Steps available as --company-primitive-size-*.
export type SizeStep =
  | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14;
