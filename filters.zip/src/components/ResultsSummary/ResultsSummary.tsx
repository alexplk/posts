import type { ReactNode } from "react";
import styles from "./ResultsSummary.module.css";

type ResultsSummaryProps = {
  /** how many results are shown (the page) */
  shown: number;
  /** how many match in total */
  total: number;
  /** noun after the count, e.g. "results" or "agents" */
  noun?: string;
  /** small muted note after the count, e.g. "sorted by relevance" */
  note?: ReactNode;
  /** identity fields to headline, in order; only pass the ones that are present */
  identity?: string[];
  /** right-hand slot (sort control etc.) */
  trailing?: ReactNode;
};

const int = new Intl.NumberFormat("en-US");

/**
 * Banner above a result list (design 9a): "N of M results" (· optional note) as an
 * eyebrow, then the identity fields in one line, equal weight, split by grey dots.
 * Nothing here is clickable — the search bar owns editing.
 */
export function ResultsSummary({
  shown,
  total,
  noun = "results",
  note,
  identity = [],
  trailing,
}: ResultsSummaryProps) {
  return (
    <div className={styles.banner}>
      <div className={styles.lead}>
        <p className={styles.eyebrow} aria-live="polite">
          <span className={styles.count}>
            <strong>{int.format(shown)}</strong> of {int.format(total)} {noun}
          </span>
          {note != null && (
            <>
              <span className={styles.dot} aria-hidden="true" />
              <span className={styles.note}>{note}</span>
            </>
          )}
        </p>
        {identity.length > 0 && (
          <h2 className={styles.identity}>
            {identity.map((label, i) => (
              <span key={`${i}-${label}`} className={styles.field}>
                {i > 0 && <span className={styles.dot} aria-hidden="true" />}
                {label}
              </span>
            ))}
          </h2>
        )}
      </div>
      {trailing != null && <div className={styles.trailing}>{trailing}</div>}
    </div>
  );
}
