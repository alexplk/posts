import type { ReactNode } from "react";
import styles from "./KeyValue.module.css";

/** Small label over a value. */
export function KeyValue({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className={styles.pair}>
      <dt className={styles.label}>{label}</dt>
      <dd className={styles.value}>{children}</dd>
    </div>
  );
}

/** Grid of KeyValue pairs, ruled off from the content above. */
export function KeyValueGrid({ children }: { children: ReactNode }) {
  return <dl className={styles.grid}>{children}</dl>;
}
