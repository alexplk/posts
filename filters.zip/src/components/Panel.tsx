import type { ReactNode } from "react";
import styles from "./Panel.module.css";

type PanelProps = {
  children: ReactNode;
  /** subtle = tinted background instead of white */
  tone?: "default" | "subtle";
  /** remove inner padding (for panels that manage their own internal layout) */
  flush?: boolean;
};

/** A bordered surface box. */
export function Panel({ children, tone = "default", flush = false }: PanelProps) {
  const cls = [styles.panel, styles[tone], flush ? styles.flush : ""]
    .filter(Boolean)
    .join(" ");
  return <div className={cls}>{children}</div>;
}
