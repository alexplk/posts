import type { FormEvent, ReactNode } from "react";
import styles from "./FilterBar.module.css";

export type FilterBarChip = {
  id: string;
  /** small qualifier shown before the label, e.g. the filter's name */
  kind: string;
  label: string;
};

type FilterBarProps = {
  chips: FilterBarChip[];
  onRemoveChip: (id: string) => void;
  keywords: string;
  onKeywordsChange: (value: string) => void;
  onSubmit?: () => void;
  placeholder?: string;
  /** buttons rendered to the right of the field (Filters, Search, …) */
  actions?: ReactNode;
};

/**
 * Search field that holds applied filters as removable chips next to free-text
 * keywords. Structure (chip = kind + label + remove, field = chips + input)
 * lives here, so callers only pass data.
 */
export function FilterBar({
  chips,
  onRemoveChip,
  keywords,
  onKeywordsChange,
  onSubmit,
  placeholder = "Add keywords",
  actions,
}: FilterBarProps) {
  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit?.();
  };

  return (
    <form className={styles.bar} role="search" onSubmit={submit}>
      <div className={styles.field}>
        {chips.map((c) => (
          <span key={c.id} className={styles.chip}>
            <span className={styles.kind}>{c.kind}</span>
            <span>{c.label}</span>
            <button
              type="button"
              className={styles.remove}
              aria-label={`Remove filter ${c.kind} ${c.label}`}
              onClick={() => onRemoveChip(c.id)}
            >
              ×
            </button>
          </span>
        ))}
        <input
          className={styles.input}
          type="search"
          value={keywords}
          placeholder={placeholder}
          aria-label="Keywords"
          onChange={(e) => onKeywordsChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Backspace" && keywords === "" && chips.length > 0) {
              onRemoveChip(chips[chips.length - 1].id);
            }
          }}
        />
      </div>
      {actions}
    </form>
  );
}
