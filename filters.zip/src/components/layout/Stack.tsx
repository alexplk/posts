import type { ElementType, ReactNode } from "react";
import type { SizeStep } from "../tokens";
import { layoutClasses, type Align } from "./layoutProps";

type StackProps = {
  children: ReactNode;
  /** gap between children, on the primitive size scale */
  gap?: SizeStep;
  align?: Align;
  as?: ElementType;
  className?: string;
};

/** Vertical flow with a token-driven gap. Pure layout, no visual styling. */
export function Stack({ children, gap = 4, align, as: Tag = "div", className }: StackProps) {
  return <Tag className={layoutClasses("stack", { gap, align, className })}>{children}</Tag>;
}
