import type { ReactNode } from "react";
import styles from "./Grid.module.css";

type GridProps = { children: ReactNode; columns?: 2 | 3 | 4 };

/** Equal-column grid that collapses on narrow viewports. */
export function Grid({ children, columns = 3 }: GridProps) {
  return <div className={[styles.grid, styles[`cols${columns}`]].join(" ")}>{children}</div>;
}
