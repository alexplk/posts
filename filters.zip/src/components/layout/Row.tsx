import type { ElementType, ReactNode } from "react";
import type { SizeStep } from "../tokens";
import { layoutClasses, type Align, type Justify } from "./layoutProps";

type RowProps = {
  children: ReactNode;
  gap?: SizeStep;
  align?: Align;
  justify?: Justify;
  wrap?: boolean;
  as?: ElementType;
  className?: string;
};

/** Horizontal flow with a token-driven gap. Pure layout. */
export function Row({
  children,
  gap = 4,
  align = "center",
  justify,
  wrap = false,
  as: Tag = "div",
  className,
}: RowProps) {
  return (
    <Tag className={layoutClasses("row", { gap, align, justify, wrap, className })}>
      {children}
    </Tag>
  );
}
