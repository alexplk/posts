import styles from "./layout.module.css";
import type { SizeStep } from "../tokens";

export type Align = "start" | "center" | "end" | "stretch" | "baseline";
export type Justify = "start" | "center" | "end" | "between";

const cap = (s: string) => s[0].toUpperCase() + s.slice(1);

/** Maps layout props to layout.module.css classes. */
export function layoutClasses(
  base: "stack" | "row",
  opts: {
    gap: SizeStep;
    align?: Align;
    justify?: Justify;
    wrap?: boolean;
    className?: string;
  },
): string {
  return [
    styles[base],
    styles[`gap${opts.gap}`],
    opts.align && styles[`align${cap(opts.align)}`],
    opts.justify && styles[`justify${cap(opts.justify)}`],
    opts.wrap && styles.wrap,
    opts.className,
  ]
    .filter(Boolean)
    .join(" ");
}
