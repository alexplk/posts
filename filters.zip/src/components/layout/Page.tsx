import type { ReactNode } from "react";
import styles from "./Page.module.css";

type PageProps = {
  children: ReactNode;
};

/** Content column for a page body: max width + page padding. */
export function Page({ children }: PageProps) {
  return <div className={styles.page}>{children}</div>;
}
