import type { ReactNode } from "react";
import styles from "./Heading.module.css";

type HeadingProps = {
  children: ReactNode;
  /** visual level; also picks the heading element unless `as` overrides */
  level?: 1 | 2 | 3 | 4;
  as?: "h1" | "h2" | "h3" | "h4";
};

/** Typographic heading bound to the type scale. */
export function Heading({ children, level = 2, as }: HeadingProps) {
  const Tag = as ?? (`h${level}` as const);
  return <Tag className={styles[`level${level}`]}>{children}</Tag>;
}
