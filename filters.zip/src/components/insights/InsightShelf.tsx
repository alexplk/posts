import { cssVars } from "../cssVars";
import { InsightWidget } from "./InsightWidget";
import { allocateSpans } from "./allocateSpans";
import type { ApplyFilters, InsightConfig } from "./types";
import s from "./InsightShelf.module.css";

type Props = { widgets: InsightConfig[]; onApply?: ApplyFilters };

/**
 * InsightShelf — the 12-column grid the widgets live on.
 *
 * Each widget claims `layout.minSpan` (optionally `maxSpan`); `allocateSpans`
 * packs them greedily in list order and grows a row's widgets until it is
 * exactly 12 wide, so a lone widget fills the row and rows stretch to the
 * tallest tile. Gutter 12px. Below 900px every tile spans the full width.
 *
 * Because packing is greedy, list order is layout order: put full-width
 * widgets last so narrower ones can pair up when a variant drops out.
 */
export const InsightShelf = ({ widgets, onApply }: Props) => {
  const spans = allocateSpans(widgets);

  return (
    <div className={s.shelf}>
      {widgets.map((w, i) => (
        <div key={w.id} className={s.slot} style={cssVars({ "--slot-span": spans[i] })}>
          <InsightWidget config={w} onApply={onApply} />
        </div>
      ))}
    </div>
  );
};
