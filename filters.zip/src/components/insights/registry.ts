import type { ComponentType } from "react";
import { ShareBarChart } from "./charts/ShareBarChart";
import { DonutChart } from "./charts/DonutChart";
import { NumbersChart } from "./charts/NumbersChart";
import { FilterChipsChart } from "./charts/FilterChipsChart";
import { FilterTabsChart } from "./charts/FilterTabsChart";
import { RatioBarChart } from "./charts/RatioBarChart";
import { FocusNumberChart } from "./charts/FocusNumberChart";
import { FocusRatioChart } from "./charts/FocusRatioChart";
import type { ChartProps, ChartType } from "./types";

export const chartRegistry: Record<ChartType, ComponentType<ChartProps>> = {
  "share-bar": ShareBarChart,
  donut: DonutChart,
  numbers: NumbersChart,
  "filter-chips": FilterChipsChart,
  "filter-tabs": FilterTabsChart,
  "ratio-bar": RatioBarChart,
  "focus-number": FocusNumberChart,
  "focus-ratio": FocusRatioChart,
};
