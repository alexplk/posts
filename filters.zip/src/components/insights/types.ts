import type { ReactNode } from "react";
import type { FilterPatch } from "@/filters";

export type { FilterPatch };

export type SeriesPoint = {
  name: string;
  value: number;
  secondary?: number;
  color?: string;
  selected?: boolean;
  filters?: FilterPatch[];
  /** "secondary" demotes the whole point to muted ink (number and name) — e.g. an "Other" bucket */
  tone?: "secondary";
};

export type Series = { data: SeriesPoint[] };

export type LayoutClaim = { minSpan: number; maxSpan?: number };

export type LegendConfig = { enabled?: boolean; as?: "table"; columns?: string[] };

export type InsightConfig = {
  id: string;
  type: ChartType;
  title: string;
  /** small muted note next to the title (ratio-bar: the footer label; numbers: e.g. "5 of 7 shown") */
  description?: string;
  layout: LayoutClaim;
  total?: { value: number; label?: string };
  focus?: SeriesPoint & { renderer?: RendererName };
  series: Series[];
  legend?: LegendConfig;
  /** clicking replaces any active filter on the same field(s) instead of stacking */
  exclusive?: boolean;
  /** filter-tabs: stack tabs in a column / drop the small counts */
  tabs?: { vertical?: boolean; hideValues?: boolean };
  /** numbers: what SeriesPoint.secondary means — a 30d delta (default) or a share of the total */
  secondaryAs?: "delta" | "percent";
};

export type ChartType =
  | "share-bar"
  | "donut"
  | "numbers"
  | "filter-chips"
  | "filter-tabs"
  | "ratio-bar"
  | "focus-number"
  | "focus-ratio";

export type RendererName =
  | "text"
  | "number"
  | "count"
  | "unwanted-count"
  | "percent"
  | "secondary-number"
  | "secondary-percentage"
  | "dot"
  | "delta";

/** Duck-typed cell renderer: value in, node out. Formats and colours only — never font or size. */
export type Renderer<V = unknown, R = Record<string, unknown>> = (props: {
  value: V;
  item?: R;
}) => ReactNode;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Row = Record<string, any>;

export type Column<R = Row> = {
  name: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  renderer: Renderer<any, R>;
  label?: string;
  align?: "start" | "end";
  width?: string;
};

export type ChartProps = {
  config: InsightConfig;
  onApply?: (filters: FilterPatch[]) => void;
};

/** Shelf-level callback: exclusiveFields lists fields whose current values should be replaced. */
export type ApplyFilters = (filters: FilterPatch[], exclusiveFields: string[]) => void;

/**
 * A widget as the app declares it: a condition plus a builder. `isEnabled` gets
 * the filters currently set, so a widget can step aside (or a variant can step
 * in) when a specific filter is present. `build` only runs for enabled widgets.
 */
export type InsightDefinition<Ctx> = {
  id: string;
  isEnabled?: (filters: FilterPatch[]) => boolean;
  /** return null to drop the widget after all (e.g. nothing left to suggest) */
  build: (ctx: Ctx) => InsightConfig | null;
};
