import { patchId, replaceFields, withoutFields, type FilterPatch } from "@/filters";

/**
 * What a widget builder gets: the current filters and a memoised matcher, so a
 * widget can count "the result set if X were applied" without knowing the domain.
 */
export type InsightCtx<A> = {
  filters: FilterPatch[];
  /** assets matching keywords + `filters` (defaults to the current ones) */
  match: (filters?: FilterPatch[]) => A[];
  /** result-set size if `patch` were clicked: its fields replaced, everything else kept */
  countIfClicked: (patch: FilterPatch[]) => number;
  /** current result set, ignoring any filter on these fields (a breakdown by X ignores the X filter) */
  matchIgnoring: (fields: string[]) => A[];
};

export function createInsightCtx<A>(
  filters: FilterPatch[],
  matchWith: (filters: FilterPatch[]) => A[],
): InsightCtx<A> {
  const cache = new Map<string, A[]>();
  const match = (f: FilterPatch[] = filters) => {
    const k = f.map(patchId).sort().join("|");
    if (!cache.has(k)) cache.set(k, matchWith(f));
    return cache.get(k)!;
  };
  return {
    filters,
    match,
    countIfClicked: (patch) => match(replaceFields(filters, patch)).length,
    matchIgnoring: (fields) => match(withoutFields(filters, fields)),
  };
}

/** distinct values of a field in a list, most frequent first */
export function rankBy<A>(list: A[], field: keyof A): [string, number][] {
  const counts = new Map<string, number>();
  for (const a of list) {
    const key = String(a[field]);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  return [...counts].sort((a, b) => b[1] - a[1]);
}

export const seriesColor = (i: number) => `var(--color-series-${(i % 6) + 1})`;
