import { MediumNumber } from "./MediumNumber";
import { SecondaryNumberRenderer } from "../renderers";
import type { Renderer } from "../types";
import s from "./Numbers.module.css";

type Props = { value: number; total: number; renderer?: Renderer<number> };

/**
 * NumberRatio — "8,257 / 8,771": a MediumNumber, a slash and the total in muted 17px.
 * Use for: one number against its ceiling (RatioBarChart).
 */
export const NumberRatio = ({ value, total, renderer }: Props) => (
  <span className={s.ratio}>
    <MediumNumber value={value} renderer={renderer} />
    <span className={s.ratioTotal}>
      / <SecondaryNumberRenderer value={total} />
    </span>
  </span>
);
