import s from "./SelectedFilterCheckMark.module.css";

type Props = { label?: string };

/**
 * SelectedFilterCheckMark — "this filter is applied" badge in a tile's top-right corner.
 *
 * Looks: 18px circle, accent border, accent-soft fill, olive check.
 *
 * Use for: shapeless focus numbers (FocusNumberChart, FocusRatioChart) where
 * tinting a big number block would read as a state of the tile, not of the filter. Rows, chips and tabs
 * carry their own selected styles and must not use this. Parent needs
 * `position: relative`.
 */
export const SelectedFilterCheckMark = ({ label = "Filter applied" }: Props) => (
  <span className={s.mark} role="img" aria-label={label}>
    <svg viewBox="0 0 12 12" className={s.icon} aria-hidden="true">
      <path d="M2.5 6.2 5 8.6l4.6-5.2" />
    </svg>
  </span>
);
