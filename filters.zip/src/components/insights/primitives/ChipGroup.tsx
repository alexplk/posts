import type { ReactNode } from "react";
import s from "./NumberChip.module.css";

/** ChipGroup — wraps NumberChips in a flex row with 8px gaps, wrapping as needed. */
export const ChipGroup = ({ children }: { children: ReactNode }) => (
  <div className={s.group}>{children}</div>
);
