import { cssVars } from "../../cssVars";
import type { Column, Row as RowData } from "../types";
import s from "./Table.module.css";

type Props<R extends RowData> = {
  cols: Column<R>[];
  data: R[];
  showHeader?: boolean;
  activeIndex?: number | null;
  onRowClick?: (item: R, index: number) => void;
  onRowHover?: (item: R | null, index: number | null) => void;
};

const track = (c: Column<never>) => c.width ?? (c.align === "end" ? "auto" : "minmax(0, 1fr)");

/**
 * Table — the legend / breakdown rows under a chart. NOT a data grid: a few
 * rows, no header by default, no scrolling.
 *
 * Looks: one row per item, 13px, hairline between rows only (never above the
 * first or below the last). Columns come from `cols` (see charts/columns.ts):
 * [dot · name · value · share] for legends, [name · value (· share)] for
 * breakdowns. Value columns are right-aligned tabular numbers.
 *
 * Behaviour: rows are buttons when `onRowClick` is given (hover bleed 6px past
 * the text, symmetric). `onRowHover` reports the hovered row so a sibling
 * graphic (RatioBar, Donut) can dim the others via `activeIndex`. A row whose
 * `selected` is true gets the accent-soft background.
 *
 * Use for: anything with 2–6 labelled numbers where the label matters as much
 * as the number. For 1–7 big numbers side by side use DividedRow instead.
 */
export function Table<R extends RowData>({
  cols,
  data,
  showHeader = false,
  activeIndex = null,
  onRowClick,
  onRowHover,
}: Props<R>) {
  const interactive = Boolean(onRowClick);
  const columns = (cols as Column<never>[]).map(track).join(" ");

  return (
    <div
      className={s.table}
      style={cssVars({ "--table-columns": columns })}
      onMouseLeave={() => onRowHover?.(null, null)}
    >
      {showHeader && (
        <div className={s.head}>
          {cols.map((c) => (
            <span key={c.name} className={c.align === "end" ? s.cellEnd : undefined}>
              {c.label ?? ""}
            </span>
          ))}
        </div>
      )}
      {data.map((item, i) => {
        const Row = interactive ? "button" : "div";
        return (
          <Row
            key={item.id ?? item.name ?? i}
            type={interactive ? "button" : undefined}
            className={[
              s.row,
              interactive ? s.interactive : "",
              activeIndex === i ? s.active : "",
              item.selected ? s.selected : "",
            ]
              .filter(Boolean)
              .join(" ")}
            aria-pressed={interactive ? Boolean(item.selected) : undefined}
            onClick={interactive ? () => onRowClick?.(item, i) : undefined}
            onMouseEnter={() => onRowHover?.(item, i)}
          >
            {cols.map((c) => {
              const Cell = c.renderer;
              return (
                <span key={c.name} className={c.align === "end" ? s.cellEnd : undefined}>
                  <Cell value={item[c.name]} item={item} />
                </span>
              );
            })}
          </Row>
        );
      })}
    </div>
  );
}
