import { CountRenderer } from "../renderers";
import type { Renderer } from "../types";
import s from "./Numbers.module.css";

type Props = { value: number; renderer?: Renderer<number> };

/**
 * BigNumber — 44px strong, tight tracking, tabular figures, block-level.
 * Takes a `renderer` for format + colour (CountRenderer by default,
 * UnwantedCountRenderer for red, SecondaryPercentageRenderer for a %).
 * The only chart allowed to use it is FocusNumberChart / FocusRatioChart: one number the whole tile is about.
 */
export const BigNumber = ({ value, renderer: R = CountRenderer }: Props) => (
  <span className={s.big}>
    <R value={value} />
  </span>
);
