import { NumberChip } from "./NumberChip";
import s from "./SegmentedTabs.module.css";

type Tab = { name: string; value?: number; selected?: boolean };

type Props = {
  tabs: Tab[];
  /** stack tabs in a column, label left / value right (design 3a) */
  vertical?: boolean;
  onSelect?: (tab: Tab, index: number) => void;
};

/**
 * SegmentedTabs — a flat inset track holding NumberChips as tabs.
 *
 * Looks: 3px inset well in surface-inset, radius 7. Horizontal: tabs share the
 * width, "inline" chips, 1px hairline between unselected neighbours; the
 * hairline disappears on both sides of the selected tab, which sits on the
 * tile colour. Vertical: "row" chips stacked with 2px gaps, no hairlines.
 *
 * Behaviour: single choice — the parent decides what selection means
 * (FilterTabsChart sets `exclusive`, so choosing one replaces the other).
 *
 * Use for: one axis with 2–5 mutually exclusive values (environment). Use
 * FilterChipsChart when values are independent and can stack.
 */
export const SegmentedTabs = ({ tabs, vertical = false, onSelect }: Props) => (
  <div className={[s.tabs, vertical ? s.vertical : ""].filter(Boolean).join(" ")}>
    {tabs.map((t, i) => {
      const divided = !vertical && i > 0 && !t.selected && !tabs[i - 1].selected;
      return (
        <div
          key={t.name}
          className={[s.tab, t.selected ? s.selected : "", divided ? s.divided : ""]
            .filter(Boolean)
            .join(" ")}
        >
          <NumberChip
            label={t.name}
            value={t.value}
            selected={t.selected}
            variant={vertical ? "row" : "inline"}
            onClick={() => onSelect?.(t, i)}
          />
        </div>
      );
    })}
  </div>
);
