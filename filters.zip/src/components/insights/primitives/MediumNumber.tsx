import { CountRenderer } from "../renderers";
import type { Renderer } from "../types";
import s from "./Numbers.module.css";

type Props = { value: number; renderer?: Renderer<number> };

/**
 * MediumNumber — 26px strong, tabular figures, block-level.
 * Takes a `renderer` for format + colour (CountRenderer by default,
 * UnwantedCountRenderer for red, SecondaryPercentageRenderer for a %).
 * The workhorse: every NumbersChart cell, the total in FocusRatioChart. Never mix Big and Medium in the same row of cells.
 */
export const MediumNumber = ({ value, renderer: R = CountRenderer }: Props) => (
  <span className={s.medium}>
    <R value={value} />
  </span>
);
