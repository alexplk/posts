import type { ReactNode } from "react";
import s from "./Donut.module.css";

type Item = { value: number; color?: string };

type Props = {
  total: number;
  items: Item[];
  centerValue: ReactNode;
  centerLabel?: ReactNode;
  activeIndex?: number | null;
};

const R = 40;
const CIRC = 2 * Math.PI * R;
const GAP = 1.5;

/**
 * Donut — ring version of RatioBar with a centre label.
 *
 * Looks: 104px ring, 8px stroke, 1.5px gaps between segments, series colours;
 * centre shows a 21px strong number over a micro-caps label.
 *
 * Behaviour: presentational — hover comes from the legend Table via
 * `activeIndex`; the chart swaps `centerValue` (total → hovered share).
 *
 * Use for: the same data as ShareBarChart when the tile is wide enough for a
 * ring beside its legend (≥ 5 columns). Prefer ShareBarChart in narrow tiles.
 */
export const Donut = ({ total, items, centerValue, centerLabel, activeIndex = null }: Props) => {
  let offset = 0;
  const denominator = total || items.reduce((a, b) => a + b.value, 0) || 1;

  return (
    <div className={s.donut}>
      <svg viewBox="0 0 96 96" className={s.svg} aria-hidden="true">
        <circle cx="48" cy="48" r={R} className={s.track} />
        {items.map((it, i) => {
          const len = (it.value / denominator) * CIRC;
          const node = (
            <circle
              key={i}
              cx="48"
              cy="48"
              r={R}
              className={[s.segment, activeIndex !== null && activeIndex !== i ? s.dimmed : ""]
                .filter(Boolean)
                .join(" ")}
              stroke={it.color ?? `var(--color-series-${(i % 6) + 1})`}
              strokeDasharray={`${Math.max(len - GAP, 0)} ${CIRC - Math.max(len - GAP, 0)}`}
              strokeDashoffset={-offset}
            />
          );
          offset += len;
          return node;
        })}
      </svg>
      <div className={s.center}>
        <span className={s.centerValue}>{centerValue}</span>
        {centerLabel != null && <span className={s.centerLabel}>{centerLabel}</span>}
      </div>
    </div>
  );
};
