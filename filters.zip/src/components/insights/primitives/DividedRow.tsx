import type { ReactNode } from "react";
import { cssVars } from "../../cssVars";
import s from "./DividedRow.module.css";

type Props = {
  items: ReactNode[];
  onItemClick?: (index: number) => void;
  /** opt single cells out of clicking (e.g. an "Other (n)" remainder); default: all clickable when onItemClick is set */
  isItemInteractive?: (index: number) => boolean;
};

/**
 * DividedRow — equal-width cells separated by vertical hairlines.
 *
 * Looks: N cells in a grid, 16px inner padding, 1px divider between cells
 * only (none before the first). Each cell is whatever node you pass.
 *
 * Behaviour: cells become buttons when `onItemClick` is given (hover
 * background, 5px radius); `isItemInteractive` can keep individual cells
 * static. Long content truncates inside its cell.
 *
 * Use for: the NumbersChart cells (a number over a name). Best with 3–7 cells;
 * below 3 the dividers look lonely, above 7 names start to truncate.
 */
export const DividedRow = ({ items, onItemClick, isItemInteractive }: Props) => (
  <div className={s.row} style={cssVars({ "--divided-count": items.length })}>
    {items.map((node, i) => {
      const interactive = Boolean(onItemClick) && (isItemInteractive?.(i) ?? true);
      const Cell = interactive ? "button" : "div";
      return (
        <Cell
          key={i}
          type={interactive ? "button" : undefined}
          className={[s.cell, interactive ? s.interactive : ""].filter(Boolean).join(" ")}
          onClick={interactive ? () => onItemClick?.(i) : undefined}
        >
          {node}
        </Cell>
      );
    })}
  </div>
);
