import type { ReactNode } from "react";
import s from "./MenuItem.module.css";

type Props = { label: ReactNode; trailing?: ReactNode; onClick?: () => void };

/**
 * MenuItem — an action styled like a table row, with a trailing arrow.
 *
 * Looks: full-width row, 13px body text, "→" in muted ink on the right, hover
 * background like Table rows. Deliberately NOT a link (no underline / link colour).
 *
 * Use for: the one call-to-action under a chart (RatioBarChart's footer).
 */
export const MenuItem = ({ label, trailing = "→", onClick }: Props) => (
  <button type="button" className={s.item} onClick={onClick}>
    <span>{label}</span>
    <span className={s.trailing}>{trailing}</span>
  </button>
);
