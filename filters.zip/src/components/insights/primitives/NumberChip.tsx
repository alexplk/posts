import { SecondaryNumberRenderer } from "../renderers";
import s from "./NumberChip.module.css";

export type NumberChipVariant =
  /** outlined pill — FilterChipsChart */
  | "pill"
  /** borderless, label over value — horizontal SegmentedTabs (design 2b) */
  | "stacked"
  /** borderless, label left / value right — vertical SegmentedTabs (design 3a) */
  | "row"
  /** borderless, label and value on one baseline, centred — wide SegmentedTabs (design 11/12a) */
  | "inline";

type Props = {
  label: string;
  value?: number;
  selected?: boolean;
  variant?: NumberChipVariant;
  onClick?: () => void;
};

/**
 * NumberChip — a label with a small grey count.
 *
 * Variants (see NumberChipVariant):
 *  - pill     outlined pill on white, count after the label. Hover / selected
 *             turn olive (accent border + accent-soft fill). FilterChipsChart.
 *  - inline   no border, label + count on one baseline, centred. Lives inside
 *             a horizontal SegmentedTabs track. Selected = strong label + tile
 *             background.
 *  - row      no border, label left / count right. Vertical SegmentedTabs.
 *  - stacked  no border, count under the label, centred. Horizontal tabs in a
 *             narrow tile.
 *
 * Behaviour: always a button; `aria-pressed` mirrors `selected`.
 */
export const NumberChip = ({ label, value, selected, variant = "pill", onClick }: Props) => (
  <button
    type="button"
    onClick={onClick}
    aria-pressed={selected ?? false}
    className={[s.chip, s[variant], selected ? s.selected : ""].filter(Boolean).join(" ")}
  >
    <span className={s.label}>{label}</span>
    {value != null && (
      <span className={s.value}>
        <SecondaryNumberRenderer value={value} />
      </span>
    )}
  </button>
);
