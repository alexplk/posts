import type { ReactNode } from "react";
import s from "./WidgetLabel.module.css";

type Props = { children: ReactNode; trailing?: ReactNode };

/**
 * WidgetLabel — the micro-caps title of every widget.
 *
 * Looks: 11px, strong, 0.1em tracking, uppercase, muted ink. With `trailing`,
 * a small tabular number/note sits at the right end of the same line
 * (ShareBarChart's total, NumbersChart's "5 of 7 shown").
 */
export const WidgetLabel = ({ children, trailing }: Props) =>
  trailing == null ? (
    <div className={s.label}>{children}</div>
  ) : (
    <div className={s.row}>
      <div className={s.label}>{children}</div>
      <div className={s.total}>{trailing}</div>
    </div>
  );
