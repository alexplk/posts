import { NumberRenderer } from "../renderers";
import type { Renderer } from "../types";
import s from "./Numbers.module.css";

type Props = { value: number; renderer?: Renderer<number> };

/**
 * SmallNumber — 17px regular, secondary ink, tabular figures, block-level.
 * Takes a `renderer` for format + colour (CountRenderer by default,
 * UnwantedCountRenderer for red, SecondaryPercentageRenderer for a %).
 * A quiet companion number (FocusRatioChart share). Not for headline values.
 */
export const SmallNumber = ({ value, renderer: R = NumberRenderer }: Props) => (
  <span className={s.small}>
    <R value={value} />
  </span>
);
