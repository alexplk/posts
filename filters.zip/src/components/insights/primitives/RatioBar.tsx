import { cssVars } from "../../cssVars";
import s from "./RatioBar.module.css";

type Item = { value: number; color?: string };

type Props = {
  total: number;
  items: Item[];
  thin?: boolean;
  /** index of the item highlighted elsewhere (e.g. hovered table row) */
  activeIndex?: number | null;
};

/**
 * RatioBar — a thin horizontal rail split by value.
 *
 * Looks: 8px tall pill (6px with `thin`), track in surface-track, segments in
 * the series palette (or `item.color`); the remainder of `total` stays track
 * colour. One item = "N of M" progress bar; many items = 100 % stacked bar.
 *
 * Behaviour: presentational only — no hover, no click. Pass `activeIndex`
 * (from the Table's hover) to dim every other segment to 30 %.
 *
 * Use for: showing how a total is shared out (ShareBarChart) or how far one
 * number is from a total (RatioBarChart). Not for comparing unrelated numbers.
 */
export const RatioBar = ({ total, items, thin = false, activeIndex = null }: Props) => {
  const used = items.reduce((a, b) => a + b.value, 0);
  const denominator = Math.max(total, used) || 1;

  return (
    <div className={[s.bar, thin ? s.thin : ""].filter(Boolean).join(" ")}>
      {items.map((it, i) => (
        <span
          key={i}
          className={[s.segment, activeIndex !== null && activeIndex !== i ? s.dimmed : ""]
            .filter(Boolean)
            .join(" ")}
          style={cssVars({
            "--segment-grow": it.value / denominator,
            "--segment-color": it.color ?? `var(--color-series-${(i % 6) + 1})`,
          })}
        />
      ))}
    </div>
  );
};
