import type { InsightConfig } from "./types";

const COLUMNS = 12;

/**
 * Greedy row packer for InsightShelf. Fills rows with minSpan claims in list
 * order, then grows the widgets in a row (up to their maxSpan) one column at a
 * time until the row is exactly COLUMNS wide. A claim wider than a row is
 * clamped to the row.
 */
export function allocateSpans(widgets: InsightConfig[]): number[] {
  const spans = widgets.map((w) => Math.min(w.layout.minSpan, COLUMNS));
  let start = 0;

  while (start < spans.length) {
    let end = start;
    let used = 0;
    while (end < spans.length && used + spans[end] <= COLUMNS) {
      used += spans[end];
      end += 1;
    }
    if (end === start) {
      spans[start] = COLUMNS;
      end = start + 1;
      used = COLUMNS;
    }

    let slack = COLUMNS - used;
    while (slack > 0) {
      let grew = false;
      for (let i = start; i < end && slack > 0; i += 1) {
        const max = widgets[i].layout.maxSpan ?? COLUMNS;
        if (spans[i] < max) {
          spans[i] += 1;
          slack -= 1;
          grew = true;
        }
      }
      if (!grew) break;
    }
    start = end;
  }

  return spans;
}
