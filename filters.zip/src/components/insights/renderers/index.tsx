/**
 * Renderers — value in, node out. They FORMAT and COLOUR; they never set font
 * family or size (the owning primitive does), so the same renderer looks right
 * in a Table cell, a BigNumber or standalone: `<CountRenderer value={514} />`.
 *
 *  TextRenderer                 plain text, body ink, truncates with an ellipsis
 *  NumberRenderer               1,234 — primary ink, regular weight
 *  CountRenderer                1,234 — primary ink, medium weight (the default for counts)
 *  UnwantedCountRenderer        1,234 in "unwanted" clay-red — for gaps, missing, errors
 *  PercentRenderer              81 % — medium weight, primary ink
 *  SecondaryNumberRenderer      1,234 — muted ink (totals, counts on chips)
 *  SecondaryPercentageRenderer  81 % / "<1%" — muted ink (share columns)
 *  DeltaRenderer                +412 / −12 — muted, signed (30-day change)
 *  DotRenderer / RoundDotRenderer  7px colour swatch; value = a colour token string
 *
 * Signature is duck-typed like an AG Grid cell renderer: `({ value, item? })`.
 * `renderers` maps the RendererName strings used in widget configs to these.
 */
import { cssVars } from "../../cssVars";
import type { Renderer } from "../types";
import s from "./renderers.module.css";

const int = new Intl.NumberFormat("en-US");
const pct = new Intl.NumberFormat("en-US", { style: "percent", maximumFractionDigits: 0 });

export const TextRenderer: Renderer<string> = ({ value }) => <span className={s.text}>{value}</span>;

export const NumberRenderer: Renderer<number> = ({ value }) => (
  <span className={s.number}>{int.format(value)}</span>
);

export const CountRenderer: Renderer<number> = ({ value }) => (
  <span className={s.count}>{int.format(value)}</span>
);

export const UnwantedCountRenderer: Renderer<number> = ({ value }) => (
  <span className={s.unwanted}>{int.format(value)}</span>
);

export const PercentRenderer: Renderer<number> = ({ value }) => (
  <span className={s.count}>{pct.format(value)}</span>
);

export const SecondaryNumberRenderer: Renderer<number> = ({ value }) => (
  <span className={s.secondary}>{int.format(value)}</span>
);

export const SecondaryPercentageRenderer: Renderer<number> = ({ value }) => (
  <span className={s.secondary}>{value < 0.01 ? "<1%" : pct.format(value)}</span>
);

export const DeltaRenderer: Renderer<number> = ({ value }) => (
  <span className={s.secondary}>
    {`${value > 0 ? "+" : value < 0 ? "−" : ""}${int.format(Math.abs(value))}`}
  </span>
);

/** value is a colour token, e.g. "var(--color-series-2)". */
export const DotRenderer: Renderer<string> = ({ value }) => (
  <span className={s.dot} style={cssVars({ "--dot-color": value })} />
);

export const RoundDotRenderer: Renderer<string> = ({ value }) => (
  <span className={s.dotRound} style={cssVars({ "--dot-color": value })} />
);

export const renderers = {
  text: TextRenderer,
  number: NumberRenderer,
  count: CountRenderer,
  "unwanted-count": UnwantedCountRenderer,
  percent: PercentRenderer,
  "secondary-number": SecondaryNumberRenderer,
  "secondary-percentage": SecondaryPercentageRenderer,
  dot: DotRenderer,
  delta: DeltaRenderer,
} as const;
