import { allApplied, type FilterPatch } from "@/filters";
import type { InsightConfig, InsightDefinition } from "./types";

/**
 * Definitions → the configs to render right now: drops widgets whose isEnabled
 * says no, builds the rest (a build may return null to bow out), and marks a
 * point `selected` when every filter it would apply is already active.
 */
export function resolveInsights<Ctx>(
  definitions: InsightDefinition<Ctx>[],
  filters: FilterPatch[],
  ctx: Ctx,
): InsightConfig[] {
  const isActive = (patch?: FilterPatch[]) => allApplied(filters, patch ?? []);

  return definitions
    .filter((d) => d.isEnabled?.(filters) ?? true)
    .flatMap((d) => {
      const config = d.build(ctx);
      if (!config) return [];
      return {
        ...config,
        focus: config.focus && { ...config.focus, selected: isActive(config.focus.filters) },
        series: config.series.map((s) => ({
          data: s.data.map((p) => ({ ...p, selected: isActive(p.filters) })),
        })),
      };
    });
}
