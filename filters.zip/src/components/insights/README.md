# Insight widget kit

Domain-blind building blocks for the "insight" tiles that summarise a filtered list and act as filters. Every file's header comment says what it renders, how it looks and when to use it; this page is the map. Nothing in here knows about agents — the agents page configures it from `src/capabilities/assets/agents.widgets.ts`.

```
insights/
  tokens.css        theme: type scale --font-size-1..7, colours, spacing, radii (design-owned, verbatim)
  types.ts          InsightConfig, SeriesPoint, Column, Renderer, InsightDefinition
  registry.ts       config.type → chart component
  InsightShelf      12-column grid; allocateSpans packs claims into full rows
  InsightWidget     the recessed tile frame; forwards clicks with exclusive fields
  resolveInsights   definitions → configs: runs isEnabled, build, marks selected points
  context           InsightCtx (filters + memoised matcher), rankBy, seriesColor
  charts/           visuals assembled from primitives (one per config.type)
  primitives/       small reusable pieces
  renderers/        value → node formatters (format + colour only)
```

## Three layers

| Layer | What it is | Rule |
|---|---|---|
| **renderers/** | `({ value, item? }) → node`. Format and colour a single value. | Never set font family or size. Usable standalone or as a Table column. |
| **primitives/** | Small components with structure: a table, a bar, a chip, a number. | Presentational; interaction only where noted (Table rows, chips, MenuItem). No filter knowledge. |
| **charts/** | One per `config.type`. Compose primitives, read an `InsightConfig`, call `onApply(filters)`. | No new styling beyond layout of the pieces; all appearance lives in primitives. |

## Choosing a chart

| Question | Chart | Size (cols) | Looks |
|---|---|---|---|
| How does a total split across categories? | **ShareBarChart** `share-bar` | 5–7 | rail + legend rows with dots, count and % |
| Same, but with a focal graphic | **DonutChart** `donut` | ≥ 5 | ring left, legend right, total in the centre |
| What are the counts per category? | **NumbersChart** `numbers` | 3 per cell… 8 for 5–7 | big numbers over names, hairline-divided |
| Which suggestions can I add? (stackable) | **FilterChipsChart** `filter-chips` | 4+ | outlined pills with grey counts |
| Which ONE value of an axis? (exclusive) | **FilterTabsChart** `filter-tabs` | 12 (or 3 vertical) | flat segmented track |
| How complete is X out of all? | **RatioBarChart** `ratio-bar` | 3 | "N / M", thin rail, row-styled action |
| One problem count + where it comes from | **FocusNumberChart** `focus-number` | 4 | 44px number + breakdown table; corner check when the number's filter is applied |
| One problem count, breakdown already pinned | **FocusRatioChart** `focus-ratio` | 4 | "61 / 446 14%" + corner check when applied |

Rules of thumb:

- Big number (44px) belongs to Focus* charts only; NumbersChart is uniformly medium (26px).
- Interaction lives in tables, chips, tabs, menu items. Rails and rings are never clickable; they respond to a table row's hover through `activeIndex`.
- Hairlines only between items, never before the first or after the last.
- Selected state: rows, chips and tabs have their own; focus numbers (FocusNumber / FocusRatio) use `SelectedFilterCheckMark` instead of a tint.
- Give a chart the tile width it needs (`layout.minSpan`); the shelf grows it, never shrinks it.

## Primitives at a glance

| Primitive | Renders | Interactive |
|---|---|---|
| `Table` | rows from `cols` × `data`, hairlines between | rows click / hover, `selected` rows tinted |
| `RatioBar` | 8px (6px thin) split rail | no — `activeIndex` dims others |
| `Donut` | 104px ring + centre label | no — `activeIndex` |
| `DividedRow` | equal cells with vertical hairlines | cells click; single cells can opt out |
| `NumberChip` | label + grey count; variants pill / inline / row / stacked | yes, `aria-pressed` |
| `ChipGroup` | wrapping row of chips | — |
| `SegmentedTabs` | inset track of NumberChips, hairlines between unselected | yes |
| `MenuItem` | row-styled action with → | yes |
| `WidgetLabel` | micro-caps title (+ trailing note) | — |
| `BigNumber` / `MediumNumber` / `SmallNumber` | 44 / 26 / 17px numbers, renderer-driven | — |
| `NumberRatio` | "value / total" | — |
| `SelectedFilterCheckMark` | 18px olive check badge, top-right | — |

## Config shape

```ts
{
  id: "in-prod-by-registry",
  type: "share-bar",
  title: "In production by registry",
  description?: "…",                    // note beside the title (numbers) or footer (ratio-bar)
  layout: { minSpan: 5, maxSpan: 7 },
  total?: { value: 50680, label: "Total" },
  focus?: { name, value, renderer: "unwanted-count", filters },   // focus-number / focus-ratio
  exclusive?: true,                     // filter-tabs: clicking replaces the field's filter
  tabs?: { vertical, hideValues },      // filter-tabs
  secondaryAs?: "delta" | "percent",    // numbers: meaning of point.secondary
  series: [{ data: [
    { name, value, secondary?, color?, filters: [{ field, value }] }
  ]}]
}
```

`point.tone: "secondary"` demotes one point to muted ink (NumbersChart renders its number and name muted — used for an "Other (n)" remainder). A point without `filters` is not clickable. `selected` on points is never configured; `resolveInsights` sets it when every filter the point would apply is active.

## Widget definitions

A page declares widgets as `InsightDefinition<Ctx>[]`:

```ts
{ id, isEnabled?: (filters) => boolean, build: (ctx) => InsightConfig | null }
```

`resolveInsights` drops disabled ones, builds the rest and returns configs for `InsightShelf`. `createInsightCtx(filters, matchWith)` gives builders `match`, `matchIgnoring(fields)` and `countIfClicked(patch)` so counts come from the same evaluator as the result list.

## Styling rules

- `.module.css` only. Runtime values (segment colour, grid span, column tracks) go through `style={cssVars({ "--x": v })}`; `npm run lint:styles` enforces it.
- No font families anywhere; sizes are `--font-size-1..7`; colours are named tokens in `tokens.css`.
- `tokens.css` is the design project's file verbatim; theme overrides for the app live in `src/styles/theme-design.css`.
