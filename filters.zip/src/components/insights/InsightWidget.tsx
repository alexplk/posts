import { chartRegistry } from "./registry";
import type { ApplyFilters, FilterPatch, InsightConfig } from "./types";
import s from "./InsightWidget.module.css";

type Props = { config: InsightConfig; onApply?: ApplyFilters };

/**
 * InsightWidget — the tile frame around one chart.
 *
 * Looks: "recessed" tile — one step lighter than the page, 1px hairline
 * border, radius 10, 16/18px padding, 13px base text; stretches to the row
 * height. White result cards sit ON the page; tiles sit IN it.
 *
 * Behaviour: picks the chart by `config.type` (registry.ts) and forwards
 * clicks as `onApply(filters, exclusiveFields)` — the fields to replace are
 * the config's own when it is `exclusive`, none otherwise.
 */
export const InsightWidget = ({ config, onApply }: Props) => {
  const Chart = chartRegistry[config.type];
  const apply = (filters: FilterPatch[]) =>
    onApply?.(filters, config.exclusive ? [...new Set(filters.map((f) => f.field))] : []);

  return (
    <section className={s.widget} data-insight-id={config.id}>
      <div className={s.body}>
        <Chart config={config} onApply={apply} />
      </div>
    </section>
  );
};
