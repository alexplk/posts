import { BigNumber, SelectedFilterCheckMark, Table, WidgetLabel } from "../primitives";
import { renderers } from "../renderers";
import { breakdownColumns, breakdownShareColumns } from "./columns";
import type { ChartProps } from "../types";
import s from "./FocusNumberChart.module.css";

/**
 * FocusNumberChart ("focus-number") — one callout number with a breakdown table.
 *
 * Composition: WidgetLabel · BigNumber + label · Table[name, count (, share)].
 * Looks: 44px number (red via `focus.renderer: "unwanted-count"` for gaps)
 * over a 13px label; the table sits at the bottom of the tile. A share
 * column appears automatically when rows carry `secondary`.
 * Interaction: the number applies `focus.filters` — applied state is a
 * SelectedFilterCheckMark in the tile's corner, the number block itself is
 * never tinted; each row applies its own filters (typically the row's
 * category + the focus condition) and shows Table's row selection.
 * Size: minSpan 4; the only chart that may use BigNumber.
 *
 * Use for: a problem count worth a headline, with where it comes from.
 * When the "where" is already pinned by a filter, use FocusRatioChart.
 */
export const FocusNumberChart = ({ config, onApply }: ChartProps) => {
  const focus = config.focus!;
  const renderer = renderers[focus.renderer ?? "count"] as typeof renderers.count;
  const data = config.series[0].data;
  const cols = data.some((d) => d.secondary != null) ? breakdownShareColumns : breakdownColumns;

  return (
    <div className={s.chart}>
      {focus.selected && <SelectedFilterCheckMark />}
      <WidgetLabel>{config.title}</WidgetLabel>
      <button
        type="button"
        className={s.focus}
        aria-pressed={focus.selected ?? false}
        onClick={() => onApply?.(focus.filters ?? [])}
      >
        <BigNumber value={focus.value} renderer={renderer} />
        <span className={s.focusLabel}>{focus.name}</span>
      </button>
      <div className={s.breakdown}>
        <Table cols={cols} data={data} onRowClick={(item) => onApply?.(item.filters ?? [])} />
      </div>
    </div>
  );
};
