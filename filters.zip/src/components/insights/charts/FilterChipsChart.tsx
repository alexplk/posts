import { ChipGroup, NumberChip, WidgetLabel } from "../primitives";
import type { ChartProps } from "../types";
import s from "./FilterChipsChart.module.css";

/**
 * FilterChipsChart ("filter-chips") — suggested filters as pills.
 *
 * Composition: WidgetLabel · ChipGroup[NumberChip pill].
 * Looks: label on the left, outlined pills with a grey count wrapping after
 * it; applied pills turn olive.
 * Interaction: each pill toggles its `point.filters`; pills from several
 * fields can sit together, values stack (OR within a field).
 * Size: minSpan 4; wraps to more lines when narrow, spreads in a full row.
 *
 * Use for: independent, non-exclusive suggestions (lifecycle, visibility).
 * For one exclusive axis use FilterTabsChart.
 */
export const FilterChipsChart = ({ config, onApply }: ChartProps) => (
  <div className={s.chart}>
    <WidgetLabel>{config.title}</WidgetLabel>
    <ChipGroup>
      {config.series[0].data.map((item) => (
        <NumberChip
          key={item.name}
          label={item.name}
          value={item.value}
          selected={item.selected}
          onClick={() => onApply?.(item.filters ?? [])}
        />
      ))}
    </ChipGroup>
  </div>
);
