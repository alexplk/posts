import { BigNumber, MediumNumber, SelectedFilterCheckMark, SmallNumber, WidgetLabel } from "../primitives";
import { renderers, CountRenderer, SecondaryPercentageRenderer } from "../renderers";
import type { ChartProps } from "../types";
import s from "./FocusRatioChart.module.css";

/**
 * FocusRatioChart ("focus-ratio") — FocusNumberChart without the table.
 *
 * Composition: WidgetLabel · [BigNumber / MediumNumber · SmallNumber %] · label.
 * Looks: "61 / 446 14%" — 44px red, slash, 26px ink total, 17px muted share —
 * over a 13px label; numbers sit at the bottom of the tile. Applied state is
 * a SelectedFilterCheckMark in the top-right corner, not a tinted tile.
 * Interaction: the whole number block toggles `focus.filters`.
 * Size: minSpan 4.
 *
 * Use for: the same problem count once the breakdown axis is already a filter
 * (single registry selected) — a one-row table would be noise.
 */
export const FocusRatioChart = ({ config, onApply }: ChartProps) => {
  const focus = config.focus!;
  const total = config.total?.value ?? focus.value;
  const renderer = renderers[focus.renderer ?? "count"] as typeof renderers.count;

  return (
    <div className={s.chart}>
      {focus.selected && <SelectedFilterCheckMark />}
      <WidgetLabel>{config.title}</WidgetLabel>
      <button
        type="button"
        className={s.focus}
        aria-pressed={focus.selected ?? false}
        onClick={() => onApply?.(focus.filters ?? [])}
      >
        <span className={s.numbers}>
          <BigNumber value={focus.value} renderer={renderer} />
          <span className={s.slash}>/</span>
          <MediumNumber value={total} renderer={CountRenderer} />
          <SmallNumber value={total ? focus.value / total : 0} renderer={SecondaryPercentageRenderer} />
        </span>
        <span className={s.label}>
          {focus.name}
          {config.total?.label ? <span className={s.totalLabel}> / {config.total.label}</span> : null}
        </span>
      </button>
    </div>
  );
};
