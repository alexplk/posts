import { useState } from "react";
import { Donut, Table, WidgetLabel } from "../primitives";
import { NumberRenderer, PercentRenderer } from "../renderers";
import { shareColumnsRound } from "./columns";
import type { ChartProps } from "../types";
import s from "./DonutChart.module.css";

/**
 * DonutChart ("donut") — the same data as ShareBarChart, as a ring + legend.
 *
 * Composition: WidgetLabel · [Donut | Table[round dot, name, count, share]].
 * Looks: 104px ring left, legend right; centre shows the total, or the
 * hovered row's share while a legend row is hovered.
 * Interaction: legend rows apply filters; the ring is presentational.
 * Size: needs ≥ 5 columns for ring + legend side by side.
 *
 * Use for: when a distribution deserves a focal graphic. Otherwise ShareBarChart.
 */
export const DonutChart = ({ config, onApply }: ChartProps) => {
  const [active, setActive] = useState<number | null>(null);
  const data = config.series[0].data;
  const total = config.total?.value ?? data.reduce((a, b) => a + b.value, 0);
  const hovered = active === null ? null : data[active];

  return (
    <div className={s.chart}>
      <WidgetLabel>{config.title}</WidgetLabel>
      <div className={s.body}>
        <Donut
          total={total}
          items={data}
          activeIndex={active}
          centerValue={
            hovered ? (
              <PercentRenderer value={hovered.secondary ?? hovered.value / total} />
            ) : (
              <NumberRenderer value={total} />
            )
          }
          centerLabel={hovered ? hovered.name : (config.total?.label ?? "Total")}
        />
        <div className={s.legend}>
          <Table
            cols={shareColumnsRound}
            data={data}
            activeIndex={active}
            onRowHover={(_, i) => setActive(i)}
            onRowClick={(item) => onApply?.(item.filters ?? [])}
          />
        </div>
      </div>
    </div>
  );
};
