import { MenuItem, NumberRatio, RatioBar, WidgetLabel } from "../primitives";
import type { ChartProps } from "../types";
import s from "./RatioBarChart.module.css";

/**
 * RatioBarChart ("ratio-bar") — one number against its total, with an action.
 *
 * Composition: WidgetLabel · NumberRatio · RatioBar(1, thin) · MenuItem.
 * Looks: "8,257 / 8,771" over a 6px progress rail, then a row-styled action
 * with an arrow (the `description`, e.g. "Show the 514 agents without …").
 * Interaction: only the MenuItem applies filters.
 * Size: minSpan 3.
 *
 * Use for: coverage / completeness ("has X" out of all). Not on the agents
 * page today; FocusNumberChart took its slot.
 */
export const RatioBarChart = ({ config, onApply }: ChartProps) => {
  const item = config.series[0].data[0];
  const total = config.total?.value ?? item.value;
  const gap = Math.max(total - item.value, 0);

  return (
    <div className={s.chart}>
      <WidgetLabel>{config.title}</WidgetLabel>
      <div className={s.ratio}>
        <NumberRatio value={item.value} total={total} />
      </div>
      <RatioBar total={total} items={[item]} thin />
      <MenuItem
        label={config.description ?? `${gap} missing`}
        onClick={() => onApply?.(item.filters ?? [])}
      />
    </div>
  );
};
