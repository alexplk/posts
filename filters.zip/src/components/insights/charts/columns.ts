import {
  TextRenderer,
  CountRenderer,
  DotRenderer,
  RoundDotRenderer,
  SecondaryPercentageRenderer,
  DeltaRenderer,
} from "../renderers";
import type { Column } from "../types";

/** The shared legend table used by ShareBarChart and DonutChart. */
export const shareColumns: Column[] = [
  { name: "color", renderer: DotRenderer, width: "14px" },
  { name: "name", renderer: TextRenderer },
  { name: "value", renderer: CountRenderer, align: "end" },
  { name: "secondary", renderer: SecondaryPercentageRenderer, align: "end", width: "44px" },
];

export const shareColumnsRound: Column[] = [
  { ...shareColumns[0], renderer: RoundDotRenderer },
  ...shareColumns.slice(1),
];

export const breakdownColumns: Column[] = [
  { name: "name", renderer: TextRenderer },
  { name: "value", renderer: CountRenderer, align: "end" },
];

/** Breakdown with a share column (design 3a: gaps by registry). */
export const breakdownShareColumns: Column[] = [
  ...breakdownColumns,
  { name: "secondary", renderer: SecondaryPercentageRenderer, align: "end", width: "40px" },
];

/** NumbersChart is configured like a Table: one line per column, stacked in each cell. */
export const numbersColumns: Column[] = [
  { name: "value", renderer: CountRenderer },
  { name: "name", renderer: TextRenderer },
  { name: "secondary", renderer: DeltaRenderer, label: "30d" },
];

/** NumbersChart where secondary is a share of the total rather than a delta. */
export const numbersShareColumns: Column[] = [
  { name: "value", renderer: CountRenderer },
  { name: "name", renderer: TextRenderer },
  { name: "secondary", renderer: SecondaryPercentageRenderer },
];
