import { useState } from "react";
import { RatioBar, Table, WidgetLabel } from "../primitives";
import { SecondaryNumberRenderer } from "../renderers";
import { shareColumns } from "./columns";
import type { ChartProps } from "../types";
import s from "./ShareBarChart.module.css";

/**
 * ShareBarChart ("share-bar") — how a total splits across categories.
 *
 * Composition: WidgetLabel (+ total, muted) · RatioBar(n) · Table[dot, name, count, share].
 * Looks: one 8px rail on top, then a legend row per category with a colour
 * dot; hovering a row dims the other rail segments.
 * Interaction: table rows apply `point.filters` (often two at once, e.g.
 * registry + PROD). The rail itself is not clickable.
 * Size: minSpan 5, reads well up to 7. Best with 3–6 categories.
 *
 * Use for: "by <category>" breakdowns where the share matters (registry).
 * Prefer NumbersChart when only the counts matter, DonutChart in wide tiles.
 */
export const ShareBarChart = ({ config, onApply }: ChartProps) => {
  const [active, setActive] = useState<number | null>(null);
  const data = config.series[0].data;
  const total = config.total?.value ?? data.reduce((a, b) => a + b.value, 0);

  return (
    <div className={s.chart}>
      <WidgetLabel trailing={<SecondaryNumberRenderer value={total} />}>{config.title}</WidgetLabel>
      <RatioBar total={total} items={data} activeIndex={active} />
      <Table
        cols={shareColumns}
        data={data}
        activeIndex={active}
        onRowHover={(_, i) => setActive(i)}
        onRowClick={(item) => onApply?.(item.filters ?? [])}
      />
    </div>
  );
};
