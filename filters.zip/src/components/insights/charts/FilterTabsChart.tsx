import { SegmentedTabs, WidgetLabel } from "../primitives";
import type { ChartProps } from "../types";
import s from "./FilterTabsChart.module.css";

/**
 * FilterTabsChart ("filter-tabs") — one exclusive axis as a segmented control.
 *
 * Composition: WidgetLabel · SegmentedTabs[NumberChip inline | row].
 * Looks, horizontal (default, full-width tile): label inline on the left, flat
 * track filling the rest, hairlines between unselected tabs, selected tab on
 * the tile colour with a strong label. `tabs.hideValues` drops the counts
 * (used once a value is chosen). Vertical (`tabs.vertical`, narrow tile):
 * label above, tabs stacked, count right-aligned.
 * Interaction: choosing a tab REPLACES the filter on that field (`exclusive`);
 * clicking the selected tab clears it.
 * Size: minSpan 12 horizontal, 3 vertical.
 *
 * Use for: 2–5 mutually exclusive values (environment). Not for stackable ones.
 */
export const FilterTabsChart = ({ config, onApply }: ChartProps) => {
  const data = config.series[0].data;
  const vertical = Boolean(config.tabs?.vertical);
  return (
    <div className={[s.chart, vertical ? s.column : s.inline].join(" ")}>
      <WidgetLabel>{config.title}</WidgetLabel>
      <div className={s.tabs}>
        <SegmentedTabs
          vertical={config.tabs?.vertical}
          tabs={data.map((d) => ({
            name: d.name,
            value: config.tabs?.hideValues ? undefined : d.value,
            selected: d.selected,
          }))}
          onSelect={(_, i) => onApply?.(data[i].filters ?? [])}
        />
      </div>
    </div>
  );
};
