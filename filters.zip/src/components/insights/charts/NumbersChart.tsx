import { DividedRow, WidgetLabel } from "../primitives";
import { SecondaryNumberRenderer } from "../renderers";
import { numbersColumns, numbersShareColumns } from "./columns";
import type { ChartProps, Column, Renderer, Row } from "../types";
import s from "./NumbersChart.module.css";

type Props = ChartProps & { cols?: Column[] };

/**
 * NumbersChart ("numbers") — a bar chart without bars: one big number per category.
 *
 * Composition: WidgetLabel (+ optional `description` note) · DividedRow[MediumNumber · name (· secondary)].
 * Looks: cells of equal width separated by hairlines; 26px number over a 13px
 * name (26px medium); an optional 11px muted third line (delta by default, share with
 * `secondaryAs: "percent"`). Every cell is MediumNumber — no emphasis mixing;
 * a point with `tone: "secondary"` renders number and name in muted ink (an
 * "Other" bucket reads as a remainder, not a category).
 * Interaction: each cell applies its `point.filters`; a point without filters
 * (an "Other (n)" remainder) renders as a static cell.
 * Size: minSpan 3 for one cell; give it 8 for five to seven cells. Long names truncate.
 *
 * Use for: a handful of categories where the absolute counts are the message
 * (organizations, SDLC stages). For shares use ShareBarChart.
 */
export const NumbersChart = ({ config, onApply, cols: colsProp }: Props) => {
  const data = config.series[0].data;
  const cols = colsProp ?? (config.secondaryAs === "percent" ? numbersShareColumns : numbersColumns);

  const cells = data.map((item) => (
    <span className={[s.cell, item.tone === "secondary" ? s.secondary : ""].filter(Boolean).join(" ")}>
      {cols.map((c, ci) => {
        const value = (item as Row)[c.name];
        if (value == null) return null;
        const Cell: Renderer<unknown, Row> =
          ci === 0 && item.tone === "secondary" ? (SecondaryNumberRenderer as Renderer<unknown, Row>) : c.renderer;
        return (
          <span key={c.name} className={ci === 0 ? s.value : ci === 1 ? s.line : s.sub}>
            <Cell value={value} item={item} />
            {c.label ? ` ${c.label}` : ""}
          </span>
        );
      })}
    </span>
  ));

  return (
    <div className={s.chart}>
      <WidgetLabel trailing={config.description}>{config.title}</WidgetLabel>
      <div className={s.body}>
        <DividedRow
          items={cells}
          onItemClick={(i) => onApply?.(data[i].filters ?? [])}
          isItemInteractive={(i) => Boolean(data[i].filters?.length)}
        />
      </div>
    </div>
  );
};
