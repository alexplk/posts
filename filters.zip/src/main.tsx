import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./global-design.css";
import "./styles/theme-design.css";
import "./components/insights/tokens.css";
import "./styles/base.css";
import App from "./App.tsx";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
