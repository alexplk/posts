import { AssetSearchPage } from "@/pages/AssetSearchPage";

/** Single page for now; add react-router (as in code/platform) when a second page shows up. */
export default function App() {
  return <AssetSearchPage />;
}
