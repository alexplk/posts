import type { FilterCatalog, FilterDefinition, FilterValue } from "./types";

/* Helpers that build definitions, so the per-asset catalogue reads as a plain list. */

type Labelled = string | [value: string, label: string, description?: string];

const toValues = (list: Labelled[]): FilterValue[] =>
  list.map((v) =>
    typeof v === "string" ? { value: v, label: v } : { value: v[0], label: v[1], description: v[2] },
  );

/** A filter on one stored field: `asset[field] === value`. */
export function fieldFilter<A, K extends keyof A>(spec: {
  key?: string;
  field: K;
  displayName: string;
  description?: string;
  /** "PROD" or ["prod", "Production", "…"] */
  values?: Labelled[];
  exclusive?: boolean;
}): FilterDefinition<A> {
  return {
    key: spec.key ?? String(spec.field),
    displayName: spec.displayName,
    description: spec.description,
    values: spec.values && toValues(spec.values),
    exclusive: spec.exclusive,
    matches: (asset, value) => String(asset[spec.field]) === value,
  };
}

/**
 * A composite / calculated filter: each value is a named condition, not a stored
 * field — e.g. quality = "no-octo-id" → `!asset.octoId`.
 */
export function computedFilter<A>(spec: {
  key: string;
  displayName: string;
  description?: string;
  values: { value: string; label: string; description?: string; test: (asset: A) => boolean }[];
  exclusive?: boolean;
}): FilterDefinition<A> {
  const tests = new Map(spec.values.map((v) => [v.value, v.test]));
  return {
    key: spec.key,
    displayName: spec.displayName,
    description: spec.description,
    values: spec.values.map(({ value, label, description }) => ({ value, label, description })),
    exclusive: spec.exclusive,
    matches: (asset, value) => tests.get(value)?.(asset) ?? false,
  };
}

export function defineCatalog<A>(catalog: FilterCatalog<A>): FilterCatalog<A> {
  return catalog;
}
