import type { FilterPatch } from "./types";

/* Pure operations on the applied filter set (a FilterPatch[]). */

export const patchId = (f: FilterPatch) => `${f.field}:${f.value}`;

const sameAs = (a: FilterPatch) => (b: FilterPatch) => a.field === b.field && a.value === b.value;

export const isApplied = (filters: FilterPatch[], patch: FilterPatch): boolean =>
  filters.some(sameAs(patch));

/** every filter in `patch` is active */
export const allApplied = (filters: FilterPatch[], patch: FilterPatch[]): boolean =>
  patch.length > 0 && patch.every((p) => isApplied(filters, p));

export const valuesOf = (filters: FilterPatch[], field: string): string[] =>
  filters.filter((f) => f.field === field).map((f) => f.value);

export const hasField = (filters: FilterPatch[], field: string): boolean =>
  filters.some((f) => f.field === field);

/** the value when exactly one filter is set on the field, otherwise null */
export const singleValueOf = (filters: FilterPatch[], field: string): string | null => {
  const values = valuesOf(filters, field);
  return values.length === 1 ? values[0] : null;
};

export const withoutFields = (filters: FilterPatch[], fields: string[]): FilterPatch[] =>
  filters.filter((f) => !fields.includes(f.field));

/** current filters with every field touched by `patch` replaced by the patch's values */
export const replaceFields = (filters: FilterPatch[], patch: FilterPatch[]): FilterPatch[] =>
  [...withoutFields(filters, patch.map((f) => f.field)), ...patch];

/** add `patch`; fields listed in `exclusiveFields` are replaced instead of stacked */
export function add(filters: FilterPatch[], patch: FilterPatch[], exclusiveFields: string[] = []): FilterPatch[] {
  const kept = withoutFields(filters, exclusiveFields);
  return [...kept, ...patch.filter((p) => !isApplied(kept, p))];
}

export const remove = (filters: FilterPatch[], patch: FilterPatch[]): FilterPatch[] =>
  filters.filter((f) => !patch.some(sameAs(f)));

/** add — or, when the whole patch is already active, remove it (chips, tabs, rows act as toggles) */
export const toggle = (filters: FilterPatch[], patch: FilterPatch[], exclusiveFields: string[] = []): FilterPatch[] =>
  allApplied(filters, patch) ? remove(filters, patch) : add(filters, patch, exclusiveFields);
