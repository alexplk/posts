/* Filter definitions — the single source of truth (see filters-insights-architecture.md §1).
 * No React, no UI. Everything that shows, sets, explains or executes a filter derives from these. */

/** One applied filter: plain, serialisable data (URL, agent tool calls, widget clicks all produce it). */
export type FilterPatch = { field: string; value: string };

/** A value a filter can take, with its user/agent-facing label. */
export type FilterValue = {
  value: string;
  label: string;
  description?: string;
};

/**
 * One filter, both facets:
 * - user / agent facing: displayName, description, values (with labels)
 * - code facing: key (the FilterPatch field), matches (in-memory predicate), exclusive
 */
export type FilterDefinition<A> = {
  key: string;
  displayName: string;
  description?: string;
  /** known values; omit when values are open-ended (labels then fall back to the raw value) */
  values?: FilterValue[];
  /** true = single-valued axis (choosing one replaces the previous), false = values OR together */
  exclusive?: boolean;
  /** does this asset satisfy the filter at this value? */
  matches: (asset: A, value: string) => boolean;
};

/** The full set of filters for one asset type, plus how keywords search it. */
export type FilterCatalog<A> = {
  definitions: FilterDefinition<A>[];
  /** text keywords are matched against (name, description, …) */
  searchText: (asset: A) => string;
};
