import type { FilterCatalog, FilterPatch } from "./types";

/* In-memory evaluator: the same filter set the UI holds, applied to a list of
 * assets. Semantics: OR within a field, AND across fields, keywords AND-ed on top. */

export function matchAssets<A>(
  catalog: FilterCatalog<A>,
  assets: A[],
  filters: FilterPatch[],
  keywords = "",
): A[] {
  const byField = new Map<string, string[]>();
  for (const f of filters) byField.set(f.field, [...(byField.get(f.field) ?? []), f.value]);
  const defs = new Map(catalog.definitions.map((d) => [d.key, d]));
  const words = keywords.toLowerCase().split(/\s+/).filter(Boolean);

  return assets.filter((asset) => {
    for (const [field, values] of byField) {
      const def = defs.get(field);
      if (def && !values.some((v) => def.matches(asset, v))) return false;
    }
    if (words.length === 0) return true;
    const text = catalog.searchText(asset).toLowerCase();
    return words.every((w) => text.includes(w));
  });
}
