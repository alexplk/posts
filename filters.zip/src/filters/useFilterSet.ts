import { useCallback, useState } from "react";
import * as set from "./filterSet";
import type { FilterPatch } from "./types";

/** React state for the applied filter set, with the filterSet operations bound to it. */
export function useFilterSet(initial: FilterPatch[] = []) {
  const [filters, setFilters] = useState<FilterPatch[]>(initial);

  const add = useCallback(
    (patch: FilterPatch[], exclusiveFields: string[] = []) =>
      setFilters((current) => set.add(current, patch, exclusiveFields)),
    [],
  );
  const toggle = useCallback(
    (patch: FilterPatch[], exclusiveFields: string[] = []) =>
      setFilters((current) => set.toggle(current, patch, exclusiveFields)),
    [],
  );
  const remove = useCallback((patch: FilterPatch[]) => setFilters((current) => set.remove(current, patch)), []);
  const clear = useCallback(() => setFilters([]), []);

  return { filters, add, toggle, remove, clear };
}
