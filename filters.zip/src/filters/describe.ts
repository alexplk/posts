import type { FilterCatalog, FilterPatch } from "./types";

/* User-facing text for an applied filter, read off the definitions — chips,
 * banners and the agent skill all use this, never their own copy. */

export function definitionOf<A>(catalog: FilterCatalog<A>, key: string) {
  return catalog.definitions.find((d) => d.key === key);
}

export function labelOf<A>(catalog: FilterCatalog<A>, field: string, value: string): string {
  return definitionOf(catalog, field)?.values?.find((v) => v.value === value)?.label ?? value;
}

/** kind = the filter's display name, label = the value's label */
export function describe<A>(catalog: FilterCatalog<A>, f: FilterPatch): { kind: string; label: string } {
  return { kind: definitionOf(catalog, f.field)?.displayName ?? f.field, label: labelOf(catalog, f.field, f.value) };
}
