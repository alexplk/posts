import { useMemo } from "react";
import { matchAssets, type FilterPatch } from "@/filters";
import { InsightShelf, createInsightCtx, resolveInsights, type ApplyFilters } from "@/components/insights";
import { agentFilters } from "./agents.filters";
import { agentWidgets } from "./agents.widgets";
import type { Agent } from "./agents.mock";

type Props = { agents: Agent[]; filters: FilterPatch[]; keywords: string; onApply: ApplyFilters };

/** Insight widgets for the agents list, computed over the current result set; clicking one narrows the search. */
export function AgentInsights({ agents, filters, keywords, onApply }: Props) {
  const widgets = useMemo(() => {
    const ctx = createInsightCtx(filters, (f) => matchAssets(agentFilters, agents, f, keywords));
    return resolveInsights(agentWidgets, filters, ctx);
  }, [agents, filters, keywords]);
  return <InsightShelf widgets={widgets} onApply={onApply} />;
}
