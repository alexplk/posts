import { useMemo, useState } from "react";
import { describe, matchAssets, patchId, useFilterSet } from "@/filters";
import { Button } from "@/components/Button";
import { FilterBar } from "@/components/FilterBar/FilterBar";
import { Stack } from "@/components/layout/Stack";
import { AgentInsights } from "./AgentInsights";
import { AgentResults, PAGE_SIZE } from "./AgentResults";
import { ResultsSummaryWidget } from "./ResultsSummaryWidget";
import { agentFilters } from "./agents.filters";
import { agents } from "./agents.mock";

/**
 * Agents search: keywords + applied filters in one bar, insight widgets that
 * add filters on click, and the matching results. One filter set drives all three.
 */
export function AssetSearch() {
  const { filters, toggle, remove } = useFilterSet();
  const [keywords, setKeywords] = useState("");

  const chips = filters.map((f) => ({ id: patchId(f), ...describe(agentFilters, f) }));
  const results = useMemo(() => matchAssets(agentFilters, agents, filters, keywords), [filters, keywords]);

  return (
    <Stack gap={9}>
      <Stack gap={7}>
        <FilterBar
          chips={chips}
          onRemoveChip={(id) => remove(filters.filter((f) => patchId(f) === id))}
          keywords={keywords}
          onKeywordsChange={setKeywords}
          actions={
            <>
              <Button>Filters ▾</Button>
              <Button variant="primary" type="submit">
                Search
              </Button>
            </>
          }
        />
        <AgentInsights agents={agents} filters={filters} keywords={keywords} onApply={toggle} />
      </Stack>
      <Stack gap={7}>
        <ResultsSummaryWidget
          filters={filters}
          fields={["organization", "registry", "stage"]}
          shown={Math.min(results.length, PAGE_SIZE)}
          total={results.length}
        />
        <AgentResults agents={results} />
      </Stack>
    </Stack>
  );
}
