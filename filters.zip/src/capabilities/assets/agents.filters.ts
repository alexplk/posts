import { computedFilter, defineCatalog, fieldFilter } from "@/filters";
import type { Agent } from "./agents.mock";

/**
 * THE filter definitions for agents. Edit here and only here: display names,
 * value labels, descriptions, new fields. The search bar, the widgets, the
 * results banner, query translation and the agent skill all read this list.
 */
export const agentFilters = defineCatalog<Agent>({
  definitions: [
    fieldFilter<Agent, "registry">({
      field: "registry",
      displayName: "Registry",
      description: "Where the agent is registered and served from.",
    }),

    fieldFilter<Agent, "stage">({
      key: "stage",
      field: "stage",
      displayName: "Environment",
      description: "SDLC stage the agent is deployed to.",
      values: ["PROD", "TEST", "DEV"],
      exclusive: true,
    }),

    fieldFilter<Agent, "lifecycle">({
      field: "lifecycle",
      displayName: "Lifecycle",
      values: [
        ["active", "Active"],
        ["experimental", "Experimental"],
      ],
    }),

    fieldFilter<Agent, "visibility">({
      field: "visibility",
      displayName: "Visibility",
      values: [
        ["public", "Public", "Visible to every business unit."],
        ["private", "Private", "Visible only to the owning organization."],
      ],
    }),

    fieldFilter<Agent, "organization">({
      field: "organization",
      displayName: "Organization",
      description: "Owning division. MOCK — not in the real model yet.",
    }),

    // composite: each value is a calculated condition, not a stored field
    computedFilter<Agent>({
      key: "quality",
      displayName: "Quality",
      description: "Data quality gaps on the agent record.",
      values: [
        { value: "no-octo-id", label: "No OCTO ID", description: "No use-case id assigned.", test: (a) => !a.octoId },
        { value: "no-owner", label: "No owner", test: (a) => !a.owner },
      ],
    }),
  ],

  searchText: (a) => `${a.name} ${a.description} ${a.registry} ${a.organization}`,
});

export type AgentFilterKey = "registry" | "stage" | "lifecycle" | "visibility" | "organization" | "quality";
