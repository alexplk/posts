export type Stage = "PROD" | "TEST" | "DEV";

export type Agent = {
  name: string;
  description: string;
  registry: string;
  stage: Stage;
  lifecycle: "active" | "experimental";
  visibility: "public" | "private";
  /** MOCK FIELD — not in the real model yet. Owning organization / division. */
  organization: string;
  /** use-case id; missing = data quality gap */
  octoId?: string;
  owner?: string;
  version: string;
};

/* ---- deterministic generator, so counts are stable between reloads ---- */

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Weighted<T> = [T, number][];

const pick = <T,>(rand: () => number, options: Weighted<T>): T => {
  const total = options.reduce((a, [, w]) => a + w, 0);
  let r = rand() * total;
  for (const [value, w] of options) {
    r -= w;
    if (r <= 0) return value;
  }
  return options[options.length - 1][0];
};

// registry → share of agents, chance an agent has no OCTO ID
const registries: [string, number, number][] = [
  ["Agent Builder", 62, 0.06],
  ["Helix", 20, 0.12],
  ["Copilot Studio", 10, 0.17],
  ["Ember", 6, 0.2],
  ["Cipher Harness", 2, 0.3],
];

export const organizations: Weighted<string> = [
  ["Private Banking", 30],
  ["Markets & Trading", 22],
  ["Fund Services", 15],
  ["Retail Banking", 12],
  ["Corporate Services", 10],
  ["Technology & Infrastructure", 7],
  ["Runoff Portfolio", 4],
];

const subjects = ["Onboarding", "KYC Review", "Trade Break", "Policy", "Incident", "Invoice", "Mandate", "Pricing", "Client Report", "Access Request", "Audit Evidence", "Release Notes", "Collateral", "Suitability", "Vendor Risk", "Meeting Notes"];
const roles = ["Assistant", "Summarizer", "Triage", "Q&A", "Drafter", "Router", "Checker", "Monitor"];
const owners = ["Payments Ops", "APAC Compliance", "Platform Eng", "Sourcing", "LATAM COO", "Client Reporting", "Risk Control", "HR Services"];

function generate(count: number): Agent[] {
  const rand = mulberry32(20260917);
  const out: Agent[] = [];
  for (let i = 0; i < count; i += 1) {
    const [registry, , noOctoChance] = pick(
      rand,
      registries.map((r) => [r, r[1]] as [typeof r, number]),
    );
    const subject = subjects[Math.floor(rand() * subjects.length)];
    const role = roles[Math.floor(rand() * roles.length)];
    out.push({
      name: `${subject} ${role} ${String(i + 1).padStart(4, "0")}`,
      description: `${role} agent for ${subject.toLowerCase()} work, registered in ${registry}.`,
      registry,
      stage: pick(rand, [["PROD", 55], ["DEV", 28], ["TEST", 17]] as Weighted<Stage>),
      lifecycle: pick(rand, [["active", 78], ["experimental", 22]] as Weighted<Agent["lifecycle"]>),
      visibility: pick(rand, [["public", 68], ["private", 32]] as Weighted<Agent["visibility"]>),
      organization: pick(rand, organizations),
      octoId: rand() < noOctoChance ? undefined : `OCT-${30000 + Math.floor(rand() * 30000)}`,
      owner: rand() < 0.15 ? undefined : owners[Math.floor(rand() * owners.length)],
      version: `${1 + Math.floor(rand() * 3)}.${Math.floor(rand() * 10)}.${Math.floor(rand() * 10)}`,
    });
  }
  return out;
}

/** Hand-written rows from the design, shown first. */
const samples: Agent[] = [
  { name: "SNOW query", stage: "PROD", lifecycle: "active", visibility: "public", organization: "Technology & Infrastructure", description: "Auto-generated A2A card for Copilot agent SNOW query.", registry: "Copilot Studio", version: "1.0.0" },
  { name: "EMIR UTI Population", stage: "PROD", lifecycle: "active", visibility: "private", organization: "Markets & Trading", description: "Populates UTI fields for EMIR reporting from trade records.", registry: "Copilot Studio", octoId: "OCT-40218", owner: "M. Brenner", version: "1.2.0" },
  { name: "Dispute Mailbox Attachment Finder", stage: "PROD", lifecycle: "active", visibility: "private", organization: "Retail Banking", description: "Finds and classifies attachments in the card-dispute mailbox.", registry: "Agent Builder", octoId: "OCT-38871", owner: "Payments Ops", version: "2.0.1" },
  { name: "New Joiner Onboarding", stage: "TEST", lifecycle: "experimental", visibility: "public", organization: "Corporate Services", description: "Guides new joiners through access requests and mandatory training.", registry: "Agent Builder", version: "0.9.4" },
  { name: "Regulatory & Audit Response", stage: "PROD", lifecycle: "active", visibility: "private", organization: "Private Banking", description: "Drafts responses for APAC regulatory and audit engagements.", registry: "Helix", octoId: "OCT-51002", owner: "APAC Compliance", version: "1.4.0" },
  { name: "UpliftSWC_2.1", stage: "DEV", lifecycle: "experimental", visibility: "private", organization: "Technology & Infrastructure", description: "Migrates legacy SWC definitions to the 2.1 schema.", registry: "Helix", owner: "Platform Eng", version: "2.1.0" },
  { name: "Chain IQ · Virtual Assistant", stage: "PROD", lifecycle: "active", visibility: "public", organization: "Corporate Services", description: "Guidance on Chain IQ SOPs for sourcing and supply-chain teams.", registry: "Helix", octoId: "OCT-49110", owner: "Sourcing", version: "1.1.0" },
  { name: "Event Guideline Update Q&A", stage: "PROD", lifecycle: "active", visibility: "public", organization: "Fund Services", description: "Compares current and previous NFR event guidelines and answers questions.", registry: "Helix", version: "1.0.0" },
  { name: "Talk2LATAM Corporate Services", stage: "PROD", lifecycle: "active", visibility: "public", organization: "Private Banking", description: "Routes LATAM corporate-services queries to the right policy owner.", registry: "Helix", octoId: "OCT-49330", owner: "LATAM COO", version: "1.0.2" },
];

export const agents: Agent[] = [...samples, ...generate(4200)];
