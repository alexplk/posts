import { Card } from "@/components/Card";
import { Tag } from "@/components/Tag";
import { KeyValue, KeyValueGrid } from "@/components/KeyValue";
import { Heading } from "@/components/Heading";
import { Grid } from "@/components/layout/Grid";
import { Row } from "@/components/layout/Row";
import u from "@/styles/utils.module.css";
import { labelOf } from "@/filters";
import { agentFilters } from "./agents.filters";
import type { Agent } from "./agents.mock";

export const PAGE_SIZE = 9;

/** The first page of agent cards. The count lives in ResultsSummaryWidget above. */
export function AgentResults({ agents }: { agents: Agent[] }) {
  const page = agents.slice(0, PAGE_SIZE);
  return (
    <section>
      <Grid columns={3}>
        {page.map((a) => (
          <Card key={a.name}>
            <Row gap={3} wrap>
              <Tag tone="accent">Agent</Tag>
              <Tag>{a.stage}</Tag>
              <Tag>{labelOf(agentFilters, "lifecycle", a.lifecycle)}</Tag>
              <Tag>{labelOf(agentFilters, "visibility", a.visibility)}</Tag>
            </Row>
            <Heading level={3}>{a.name}</Heading>
            <p className={u.bodyMuted}>{a.description}</p>
            <KeyValueGrid>
              <KeyValue label="Registry">{a.registry}</KeyValue>
              <KeyValue label="OCTO ID">{a.octoId ?? "Not assigned"}</KeyValue>
              <KeyValue label="Organization">{a.organization}</KeyValue>
              <KeyValue label="Owner">{a.owner ?? "Unknown owner"}</KeyValue>
            </KeyValueGrid>
          </Card>
        ))}
      </Grid>
    </section>
  );
}
