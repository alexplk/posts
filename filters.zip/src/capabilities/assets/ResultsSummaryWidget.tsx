import { labelOf, singleValueOf, type FilterPatch } from "@/filters";
import { ResultsSummary } from "@/components/ResultsSummary/ResultsSummary";
import { agentFilters, type AgentFilterKey } from "./agents.filters";

type Props = {
  filters: FilterPatch[];
  /** identity fields to headline, in display order; shown only while pinned to a single value */
  fields: AgentFilterKey[];
  shown: number;
  total: number;
};

/**
 * Results banner (design 9a): always the "N of M" line; when the filter set pins
 * an identity field to one value, that value joins the headline in `fields` order.
 * Read-only; the search-bar chips do the editing.
 */
export function ResultsSummaryWidget({ filters, fields, shown, total }: Props) {
  const identity = fields.flatMap((field) => {
    const value = singleValueOf(filters, field);
    return value === null ? [] : [labelOf(agentFilters, field, value)];
  });
  return <ResultsSummary shown={shown} total={total} noun="results" identity={identity} />;
}
