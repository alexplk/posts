import { hasField, singleValueOf, type FilterPatch } from "@/filters";
import { rankBy, seriesColor, type InsightCtx, type InsightDefinition, type SeriesPoint } from "@/components/insights";
import { labelOf } from "@/filters";
import { agentFilters } from "./agents.filters";
import type { Agent } from "./agents.mock";

/**
 * THE insight widgets for the agents list — one list, one rule per widget.
 *
 *   isEnabled(filters)  when the widget shows (variants pair up: 1↔6, 3↔7, 2↔8)
 *   build(ctx)          what it shows, computed over the current result set
 *
 * Counting: a breakdown by X ignores the active X filter (ctx.matchIgnoring),
 * clickable points count "the result set if clicked" (ctx.countIfClicked);
 * suggestion chips count inside the current result set.
 */

type Ctx = InsightCtx<Agent>;

const f = (field: string, value: string): FilterPatch => ({ field, value });
const NO_OCTO = f("quality", "no-octo-id");
const STAGES = ["PROD", "TEST", "DEV"];

const envPinned = (filters: FilterPatch[]) => hasField(filters, "stage");
const registryPinned = (filters: FilterPatch[]) => singleValueOf(filters, "registry") !== null;
const orgPinned = (filters: FilterPatch[]) => singleValueOf(filters, "organization") !== null;

/** share-bar series: agents per registry, optionally pinned to extra filters (e.g. PROD) */
const registryShare = (ctx: Ctx, pinned: FilterPatch[]) => {
  const base = ctx.match([...ctx.filters.filter((x) => x.field !== "registry"), ...pinned]);
  const data: SeriesPoint[] = rankBy(base, "registry").map(([name, value], i) => ({
    name,
    value,
    secondary: base.length ? value / base.length : 0,
    color: seriesColor(i),
    filters: [f("registry", name), ...pinned],
  }));
  return { total: base.length, data };
};

const stagePoints = (ctx: Ctx): SeriesPoint[] =>
  STAGES.map((name) => ({ name, value: ctx.countIfClicked([f("stage", name)]), filters: [f("stage", name)] }));

export const agentWidgets: InsightDefinition<Ctx>[] = [
  // 1 · In production by registry — top level
  {
    id: "in-prod-by-registry",
    isEnabled: (filters) => !envPinned(filters) && !registryPinned(filters),
    build: (ctx) => {
      const { total, data } = registryShare(ctx, [f("stage", "PROD")]);
      return {
        id: "in-prod-by-registry",
        type: "share-bar",
        title: "In production by registry",
        layout: { minSpan: 5, maxSpan: 7 },
        total: { value: total, label: "Total" },
        series: [{ data }],
      };
    },
  },

  // 6 · By registry — variant of 1 once an environment is chosen
  {
    id: "by-registry",
    isEnabled: (filters) => envPinned(filters) && !registryPinned(filters),
    build: (ctx) => {
      const { total, data } = registryShare(ctx, []);
      return {
        id: "by-registry",
        type: "share-bar",
        title: "By registry",
        layout: { minSpan: 5, maxSpan: 7 },
        total: { value: total, label: "Total" },
        series: [{ data }],
      };
    },
  },

  // 2 · Data quality gaps — top level
  {
    id: "quality-gaps",
    isEnabled: (filters) => !registryPinned(filters),
    build: (ctx) => {
      const base = ctx.matchIgnoring(["quality"]);
      return {
        id: "quality-gaps",
        type: "focus-number",
        title: "Data quality gaps",
        layout: { minSpan: 4 },
        focus: {
          name: "Agents without use-cases (OCTO ID)",
          value: base.filter((a) => !a.octoId).length,
          renderer: "unwanted-count",
          filters: [NO_OCTO],
        },
        series: [
          {
            // top 3 registries by agent count; value = no OCTO ID, secondary = share within the registry
            data: rankBy(base, "registry")
              .slice(0, 3)
              .map(([name, inRegistry]) => {
                const missing = base.filter((a) => a.registry === name && !a.octoId).length;
                return {
                  name,
                  value: missing,
                  secondary: inRegistry ? missing / inRegistry : 0,
                  filters: [f("registry", name), NO_OCTO],
                };
              }),
          },
        ],
      };
    },
  },

  // 8 · Agents without a use-case — variant of 2 once a single registry is chosen
  {
    id: "no-use-case",
    isEnabled: registryPinned,
    build: (ctx) => {
      const base = ctx.matchIgnoring(["quality"]);
      return {
        id: "no-use-case",
        type: "focus-ratio",
        title: "Agents without a use-case",
        layout: { minSpan: 4 },
        focus: { name: "no OCTO ID", value: base.filter((a) => !a.octoId).length, renderer: "unwanted-count", filters: [NO_OCTO] },
        total: { value: base.length },
        series: [{ data: [] }],
      };
    },
  },

  // 5 · By organization — top 5 + Other
  {
    id: "by-organization",
    isEnabled: (filters) => !orgPinned(filters),
    build: (ctx) => {
      const ranked = rankBy(ctx.matchIgnoring(["organization"]), "organization");
      const top = ranked.slice(0, 5);
      const rest = ranked.slice(5);
      const data: SeriesPoint[] = top.map(([name, value]) => ({ name, value, filters: [f("organization", name)] }));
      if (rest.length > 0) {
        // remainder: muted and NOT clickable — could be hundreds of orgs, an OR over all of them is meaningless
        data.push({
          name: `Other (${rest.length})`,
          value: rest.reduce((a, [, n]) => a + n, 0),
          tone: "secondary",
        });
      }
      return {
        id: "by-organization",
        type: "numbers",
        title: "By organization",
        description: rest.length > 0 ? `${top.length} of ${ranked.length} shown` : undefined,
        layout: { minSpan: 8 },
        series: [{ data }],
      };
    },
  },

  // 4 · Narrow by availability — suggestion chips across lifecycle + visibility
  {
    id: "suggested-filters",
    build: (ctx) => {
      const current = ctx.match();
      const chip = (field: "lifecycle" | "visibility", value: string): SeriesPoint => ({
        name: labelOf(agentFilters, field, value),
        value: current.filter((a) => a[field] === value).length,
        filters: [f(field, value)],
      });
      const applied = (p: SeriesPoint) => p.filters!.every((x) => ctx.filters.some((y) => y.field === x.field && y.value === x.value));
      const data = [chip("lifecycle", "active"), chip("lifecycle", "experimental"), chip("visibility", "public"), chip("visibility", "private")]
        .filter((p) => p.value > 0 || applied(p)); // a 0 suggestion can only empty the list
      if (data.length === 0) return null;
      return {
        id: "suggested-filters",
        type: "filter-chips",
        title: "Narrow by availability",
        layout: { minSpan: 4 },
        series: [{ data }],
      };
    },
  },

  // 3 · Environment — full width, with counts (listed last so the tiles above pack into shared rows)
  {
    id: "environment",
    isEnabled: (filters) => !envPinned(filters),
    build: (ctx) => ({
      id: "environment",
      type: "filter-tabs",
      title: "Environment",
      exclusive: true,
      layout: { minSpan: 12 },
      series: [{ data: stagePoints(ctx) }],
    }),
  },

  // 7 · Environment switch — variant of 3 once an environment is chosen: no counts
  {
    id: "environment-switch",
    isEnabled: envPinned,
    build: (ctx) => ({
      id: "environment-switch",
      type: "filter-tabs",
      title: "Environment",
      exclusive: true,
      tabs: { hideValues: true },
      layout: { minSpan: 12 },
      series: [{ data: stagePoints(ctx) }],
    }),
  },
];
