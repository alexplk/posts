/* Typed keys for utils.module.css — hand-maintained; keep in sync. */
declare const styles: {
  readonly mutedLink: string;
  readonly caption: string;
  readonly bodyMuted: string;
  readonly resultCount: string;
};
export default styles;
