// Styling lives in .module.css only. The single allowed use of the style
// attribute is style={cssVars({...})} — runtime values handed to a stylesheet
// as CSS custom properties (see src/components/cssVars.ts).
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

const hits = [];
const walk = (dir) => {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (p.endsWith(".tsx")) {
      readFileSync(p, "utf8").split("\n").forEach((line, i) => {
        if (/\bstyle\s*=/.test(line) && !/\bstyle=\{cssVars\(/.test(line)) {
          hits.push(`${p}:${i + 1}: ${line.trim()}`);
        }
      });
    }
  }
};
walk("src");
if (hits.length) {
  console.error("Inline styles found (use a .module.css class, or cssVars for runtime values):\n" + hits.join("\n"));
  process.exit(1);
}
console.log("no inline styles");
