# filters — POC

Vite + React + TS. Scope and draft schema: `./README.md`.

Read before touching filters or widgets, and keep updated:
- `./filters-insights-architecture.md` — how filters, chips, widgets, banner and agent relate; code layout; behaviour rules.
- `./agents-filters-widgets.md` — the agents page: every filter and widget, when widgets hide and why, how counts are computed.
- `./src/components/insights/README.md` — the widget kit: which chart/primitive to use, how each looks. Each component file also carries a header comment with looks + use-for.

**Before building any UI here, read and follow** `../../platform/ARCHITECTURE.md` (components → capabilities → pages, downward-only deps; component vs. semantic HTML; utils; design tokens).

Stricter rules for this project:
- All styles in `.module.css`. **No `style={}`**, including layout primitives — map props to classes. Only exception: `style={cssVars({...})}` to pass runtime values as CSS custom properties. `npm run lint:styles` checks this.
- `src/components/insights/` mirrors the Claude Design project's `insights/` folder (see README "Design import"). Keep its file layout; its `tokens.css` stays verbatim.
- Consume tokens from `src/global-design.css`; never hardcode raw values. No Tailwind.
- Layout of the domain code: `src/filters/` = domain-blind filter library (no UI); `capabilities/assets/agents.filters.ts` = the agents filter catalogue (the only place to edit filter names/values); `agents.widgets.ts` = the widget list with `isEnabled` rules; the other capability files are wiring only. Keep definitions and wiring apart.
- Widget kit layout: `primitives/` = small reusable pieces, `renderers/` = value → node formatters (format + colour only), `charts/` = visuals assembled from primitives.
- Import via `@/` (= `src/`).
