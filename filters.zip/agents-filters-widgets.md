# Agents page — filters and insight widgets

Maintainer notes for the Agents list (`src/capabilities/assets/`): which filters exist, which widgets exist, when each widget shows or hides, and why. Read this before changing `agents.filters.ts` or `agents.widgets.ts`; the kit itself is documented in [`src/components/insights/README.md`](./src/components/insights/README.md).

## Files

| File | Edit it to… |
|---|---|
| `agents.filters.ts` | add or rename a filter, change a display name, add value labels/descriptions, add a composite condition, change what keywords search |
| `agents.widgets.ts` | add a widget, change what it shows, change when it shows (`isEnabled`) |
| `agents.mock.ts` | change the sample data (deterministic generator; counts stay stable between reloads) |
| `AssetSearch.tsx` | change how bar, shelf, banner and cards are stacked |
| `AgentInsights.tsx`, `ResultsSummaryWidget.tsx`, `AgentResults.tsx` | wiring only — normally untouched |

## Data model

| Field | Values | Notes |
|---|---|---|
| `registry` | Agent Builder · Helix · Copilot Studio · Ember · Cipher Harness | open-ended (no value list in the catalogue) |
| `stage` | PROD · TEST · DEV | shown as **Environment**; exclusive |
| `lifecycle` | active → "Active" · experimental → "Experimental" | |
| `visibility` | public → "Public" · private → "Private" | |
| `organization` | Private Banking · Markets & Trading · Fund Services · Retail Banking · Corporate Services · Technology & Infrastructure · Runoff Portfolio | **mock field** — not in the real model yet |
| `octoId` | use-case id, optional | missing = "no OCTO ID" |
| `owner` | optional | missing = "no owner" |

Keywords search `name`, `description`, `registry`, `organization`.

## Filters (`agentFilters`)

| Key | Display name | Values (label) | Kind |
|---|---|---|---|
| `registry` | Registry | any registry name | field |
| `stage` | Environment | PROD · TEST · DEV | field, **exclusive** |
| `lifecycle` | Lifecycle | Active · Experimental | field |
| `visibility` | Visibility | Public · Private | field |
| `organization` | Organization | any org name | field (mock) |
| `quality` | Quality | No OCTO ID · No owner | **composite** — each value is a calculated condition (`!octoId`, `!owner`), not a stored field |

Semantics everywhere (bar, widgets, results): **OR within a field, AND across fields**, keywords AND-ed on top. Setting `exclusive` on a definition documents that a field is single-valued; the environment widget enforces it by replacing the field's filter on click.

Adding a filter = one entry in `agentFilters.definitions`. Chips in the search bar, the results banner and widget counts pick it up with no other change.

## Widgets (`agentWidgets`)

Widgets are computed over the current result set (filters + keywords). Clicking a point toggles its filters; a point is drawn as selected when all of its filters are active.

| # | id | Chart | Shows when | Content | Click |
|---|---|---|---|---|---|
| 1 | `in-prod-by-registry` | share-bar (5–7 cols) | no environment filter **and** no single registry | PROD agents split by registry: rail, then rows with count and share | registry + `stage=PROD` |
| 6 | `by-registry` | share-bar (5–7) | an environment filter is set **and** no single registry | same, over the current set; title "By registry" | registry |
| 2 | `quality-gaps` | focus-number (4) | no single registry | red count of agents without an OCTO ID (corner check when applied); table of the **top 3 registries by agent count** — value = missing, share = missing ÷ registry total | number: `quality=no-octo-id` · row: registry + `quality=no-octo-id` |
| 8 | `no-use-case` | focus-ratio (4) | a single registry is set | "61 / 446 14%": missing / total in that registry / share; corner check when applied | `quality=no-octo-id` |
| 5 | `by-organization` | numbers (8) | no single organization | top 5 organizations as count + name, plus a muted, non-clickable "Other (n)" remainder; "5 of 7 shown" beside the title | org (the remainder is static — it could stand for hundreds) |
| 4 | `suggested-filters` | filter-chips (4) | at least one chip left | "Narrow by availability": Active · Experimental · Public · Private with counts **inside the current result set**; a 0-count chip disappears; an applied chip stays so it can be toggled off | that value |
| 3 | `environment` | filter-tabs (12) | no environment filter | "Environment" label + PROD / TEST / DEV tabs with counts | `stage=X` (replaces) |
| 7 | `environment-switch` | filter-tabs (12) | an environment filter is set | same tabs, no counts, selection shown | `stage=X` (replaces); clicking the selected tab clears it |

List order is layout order (the shelf packs greedily): registry (7) + quality (5) · organization (8) + availability (4) · environment (12). Environment is listed last on purpose — when widget 1/6 hides, widget 2/8 pairs with the organization tile instead of being stranded alone on a full-width row.

### Why widgets hide

- **A breakdown by X hides when X is pinned to one value.** Under `registry = Helix`, "In production by registry" and "By registry" would show a single row; under `organization = Markets & Trading`, the organization numbers would show one cell. They step aside (`registryPinned`, `orgPinned` in `agents.widgets.ts`). The quality widget swaps to its no-table variant (#8) for the same reason.
- **"In production by registry" is only meaningful without an environment filter.** Once one is set, "by registry in PROD" either repeats the filter or contradicts it, so #6 "By registry" (no PROD pin) takes its place.
- **Environment tabs drop their counts once an environment is chosen** (#3 → #7). With the filter applied, every other tab's count would be 0 or misleading; the switch just shows where you are.
- **Suggestion chips count inside the current result set and hide at 0.** With Public applied, "Private 0" could only empty the list, so it goes; Public stays (applied) so it can be toggled off. If nothing is left, the whole widget goes.

### How the numbers are computed

- **Breakdowns and tabs** count "the result set you'd get by clicking": current filters with the point's own field(s) replaced by the point's values (`ctx.countIfClicked`). A breakdown by X therefore ignores an active X filter (`ctx.matchIgnoring(["X"])`) — otherwise the unselected rows would all read 0 — and every other filter narrows it. With a real search index this maps to facet counts with the facet's own filter excluded.
- **Suggestion chips** count inside the current result set (no replacement), see above.
- **Quality counts** ignore an active `quality` filter (its own axis), so the red number never reads 100 % just because the filter is on.
- Widget #1 pins `stage=PROD` into its base set; its rows add both `registry` and `stage=PROD` on click.

## Results banner (`ResultsSummaryWidget`)

Sits directly above the cards and replaces the plain result count. Always shows "**N** of M results" (N = page size, 9). The identity line beneath it lists, in the order given (`organization → registry → stage`), each field that is currently pinned to **exactly one** value, as a 21px line split by grey dots — e.g. "Markets & Trading · Helix · PROD". Fields with no or several values are simply absent. Nothing in the banner is clickable; the search-bar chips do the editing.

## Search bar (`FilterBar`)

Applied filters render as chips — display name in small olive caps, then the value label — followed by the keyword input. × removes a chip; Backspace on an empty input removes the last one. The "Filters ▾" button is a placeholder for the generated filter list (not built). Labels come from `agentFilters` via `describe()`.

## Page rhythm

Search bar → shelf 20px · shelf rows 12px apart · shelf → results banner 32px · banner → cards 20px (`Stack gap={7}` inside each block, `gap={9}` between the widget block and the results block).

## Adding a widget

1. Add an entry to `agentWidgets`: `id`, `isEnabled(filters)` if conditional, `build(ctx)` returning an `InsightConfig` (or `null` to bow out).
2. Pick the chart by what the numbers mean (see the kit README's "Choosing a chart") and give it a realistic `layout.minSpan`.
3. Count with `ctx.match`, `ctx.matchIgnoring`, `ctx.countIfClicked`, `rankBy` — never with a hand-rolled filter, so the widget agrees with the result list.
4. Put full-width widgets at the end of the list.
5. Every clickable point needs `filters: FilterPatch[]` using keys from `agentFilters`.
